-- ============================================
-- SISTEMA DE MÉTODO PRE-REAL COMPLETO
-- ============================================

-- 1. CATÁLOGO DE MATERIALES BASE
CREATE TABLE IF NOT EXISTS public.materials_catalog (
  id BIGSERIAL PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  name TEXT NOT NULL,
  category VARCHAR(100) NOT NULL,
  unit VARCHAR(20) NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  description TEXT,
  specifications JSONB,
  region VARCHAR(100) DEFAULT 'Nacional',
  last_updated TIMESTAMPTZ DEFAULT NOW(),
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. CATÁLOGO DE CONCEPTOS DE CONSTRUCCIÓN (Partidas)
CREATE TABLE IF NOT EXISTS public.construction_concepts (
  id BIGSERIAL PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  name TEXT NOT NULL,
  main_category VARCHAR(100) NOT NULL,
  sub_category VARCHAR(100),
  unit VARCHAR(20) NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  description TEXT,
  quality_level VARCHAR(50),
  useful_life INTEGER,
  maintenance_level VARCHAR(50),
  materials_breakdown JSONB,
  labor_cost DECIMAL(10,2),
  material_cost DECIMAL(10,2),
  equipment_cost DECIMAL(10,2),
  indirect_costs_percentage DECIMAL(5,2) DEFAULT 15.00,
  profit_percentage DECIMAL(5,2) DEFAULT 10.00,
  region VARCHAR(100) DEFAULT 'Nacional',
  last_updated TIMESTAMPTZ DEFAULT NOW(),
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. PRESUPUESTO DE AVALÚO
CREATE TABLE IF NOT EXISTS public.appraisal_budgets (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  appraisal_id UUID REFERENCES public.appraisals(id) ON DELETE CASCADE,
  total_construction_area DECIMAL(10,2),
  total_budget_amount DECIMAL(12,2),
  cost_per_sqm DECIMAL(10,2),
  depreciated_value DECIMAL(12,2),
  final_cost_per_sqm DECIMAL(10,2),
  calculation_date TIMESTAMPTZ DEFAULT NOW(),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. PARTIDAS DEL PRESUPUESTO
CREATE TABLE IF NOT EXISTS public.budget_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  budget_id UUID REFERENCES public.appraisal_budgets(id) ON DELETE CASCADE,
  concept_id BIGINT REFERENCES public.construction_concepts(id),
  code VARCHAR(50),
  description TEXT NOT NULL,
  main_category VARCHAR(100) NOT NULL,
  sub_category VARCHAR(100),
  unit VARCHAR(20) NOT NULL,
  quantity DECIMAL(10,3) NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL,
  damage_deduction_percentage DECIMAL(5,2) DEFAULT 0,
  damage_deduction_amount DECIMAL(12,2) DEFAULT 0,
  final_value DECIMAL(12,2) NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. SISTEMA INTEGRAL DE EVALUACIÓN DE DAÑOS (SIED)
CREATE TABLE IF NOT EXISTS public.damage_types_catalog (
  id BIGSERIAL PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  system_category VARCHAR(100) NOT NULL,
  damage_name TEXT NOT NULL,
  damage_description TEXT,
  severity_levels JSONB,
  extension_types JSONB,
  progression_types JSONB,
  structural_impact JSONB,
  reparability JSONB,
  importance_factor DECIMAL(3,2) DEFAULT 1.00,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. EVALUACIÓN DE DAÑOS POR AVALÚO
CREATE TABLE IF NOT EXISTS public.appraisal_damages (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  appraisal_id UUID REFERENCES public.appraisals(id) ON DELETE CASCADE,
  budget_item_id UUID REFERENCES public.budget_items(id) ON DELETE CASCADE,
  damage_type_id BIGINT REFERENCES public.damage_types_catalog(id),
  system_category VARCHAR(100) NOT NULL,
  damage_name TEXT NOT NULL,
  severity VARCHAR(50) NOT NULL,
  severity_coefficient DECIMAL(3,2),
  extension VARCHAR(50) NOT NULL,
  extension_percentage DECIMAL(5,2),
  progression VARCHAR(50),
  progression_factor DECIMAL(3,2),
  structural_impact VARCHAR(50),
  impact_factor DECIMAL(3,2),
  reparability VARCHAR(50),
  reparability_factor DECIMAL(3,2),
  affected_area DECIMAL(10,2),
  repair_cost_estimate DECIMAL(12,2),
  calculated_deduction_percentage DECIMAL(5,2),
  photos JSONB,
  notes TEXT,
  evaluator_name VARCHAR(255),
  evaluation_date TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. FACTORES DE COMPENSACIÓN
CREATE TABLE IF NOT EXISTS public.compensation_factors (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  appraisal_id UUID REFERENCES public.appraisals(id) ON DELETE CASCADE,
  system_category VARCHAR(100) NOT NULL,
  element_name TEXT NOT NULL,
  condition_rating VARCHAR(50),
  compensation_percentage DECIMAL(5,2),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. BASE DE CONOCIMIENTO PARA CHATBOT
CREATE TABLE IF NOT EXISTS public.valuation_knowledge_base (
  id BIGSERIAL PRIMARY KEY,
  topic_category VARCHAR(100) NOT NULL,
  source VARCHAR(255),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  keywords TEXT[],
  region VARCHAR(100),
  url TEXT,
  last_updated TIMESTAMPTZ DEFAULT NOW(),
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. HISTORIAL DE CONVERSACIONES DEL CHATBOT
CREATE TABLE IF NOT EXISTS public.ai_chat_history (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES public.users(id),
  appraisal_id UUID REFERENCES public.appraisals(id),
  conversation_id UUID DEFAULT gen_random_uuid(),
  role VARCHAR(20) NOT NULL,
  message TEXT NOT NULL,
  context JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Crear índices
CREATE INDEX IF NOT EXISTS idx_materials_catalog_category ON public.materials_catalog(category);
CREATE INDEX IF NOT EXISTS idx_materials_catalog_code ON public.materials_catalog(code);
CREATE INDEX IF NOT EXISTS idx_construction_concepts_category ON public.construction_concepts(main_category, sub_category);
CREATE INDEX IF NOT EXISTS idx_construction_concepts_code ON public.construction_concepts(code);
CREATE INDEX IF NOT EXISTS idx_budget_items_budget_id ON public.budget_items(budget_id);
CREATE INDEX IF NOT EXISTS idx_damage_types_system ON public.damage_types_catalog(system_category);
CREATE INDEX IF NOT EXISTS idx_appraisal_damages_appraisal ON public.appraisal_damages(appraisal_id);
CREATE INDEX IF NOT EXISTS idx_knowledge_base_category ON public.valuation_knowledge_base(topic_category);
CREATE INDEX IF NOT EXISTS idx_knowledge_base_keywords ON public.valuation_knowledge_base USING GIN(keywords);
CREATE INDEX IF NOT EXISTS idx_chat_history_conversation ON public.ai_chat_history(conversation_id);
