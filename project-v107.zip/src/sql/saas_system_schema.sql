-- ====================================
-- SISTEMA SAAS CON STRIPE - AVALÚOTECH
-- ====================================

-- Actualizar tabla de usuarios para el sistema SaaS
DROP TABLE IF EXISTS users CASCADE;

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin', 'valuador')),
  email_verified BOOLEAN DEFAULT false,
  subscription_status TEXT DEFAULT 'free' CHECK (subscription_status IN ('free', 'pro', 'enterprise', 'canceled')),
  subscription_id TEXT,
  stripe_customer_id TEXT,
  appraisals_count INTEGER DEFAULT 0,
  appraisals_limit INTEGER DEFAULT 3,
  monthly_appraisals_count INTEGER DEFAULT 0,
  last_reset_date TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Desactivar RLS para permitir registro desde la UI
ALTER TABLE users DISABLE ROW LEVEL SECURITY;

-- Tabla de planes de suscripción
CREATE TABLE IF NOT EXISTS subscription_plans (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'MXN',
  appraisals_limit INTEGER,
  features JSONB DEFAULT '[]'::jsonb,
  stripe_price_id TEXT,
  stripe_product_id TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Agregar columnas para Stripe si no existen
ALTER TABLE subscription_plans 
ADD COLUMN IF NOT EXISTS stripe_product_id TEXT,
ADD COLUMN IF NOT EXISTS stripe_price_id TEXT;

-- Insertar los 3 planes
INSERT INTO subscription_plans (id, name, description, price, appraisals_limit, features, stripe_price_id) VALUES
('free', 'Plan Gratuito', 'Perfecto para empezar', 0, 3, 
  '["3 avalúos por mes", "Acceso básico al asistente IA", "1 usuario", "Plantillas básicas"]'::jsonb, 
  null),
('pro', 'Plan Profesional', 'Para valuadores profesionales', 499, -1, 
  '["Avalúos ilimitados", "Asistente IA completo", "5 usuarios", "Exportación a PDF profesional", "Soporte prioritario", "Dashboard de estadísticas"]'::jsonb, 
  'price_pro_monthly'),
('enterprise', 'Plan Empresarial', 'Para empresas de valuación', 1499, -1, 
  '["Avalúos ilimitados", "Asistente IA avanzado", "Usuarios ilimitados", "Exportación PDF personalizada", "Soporte 24/7", "Dashboard avanzado", "API de integración", "Capacitación personalizada"]'::jsonb, 
  'price_enterprise_monthly')
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  price = EXCLUDED.price,
  features = EXCLUDED.features;

-- Tabla de historial de suscripciones
CREATE TABLE IF NOT EXISTS subscription_history (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  plan_id TEXT REFERENCES subscription_plans(id),
  stripe_subscription_id TEXT,
  status TEXT CHECK (status IN ('active', 'canceled', 'expired', 'past_due')),
  started_at TIMESTAMPTZ DEFAULT NOW(),
  ended_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Función para actualizar appraisals_count cuando se crea un avalúo (ACTUALIZADO)
CREATE OR REPLACE FUNCTION increment_monthly_appraisals()
RETURNS TRIGGER AS $
BEGIN
  -- Resetear si es nuevo mes
  UPDATE users 
  SET monthly_appraisals_count = 0,
      last_reset_date = NOW()
  WHERE id = NEW.valuator_id 
    AND last_reset_date < DATE_TRUNC('month', NOW());
  
  -- Incrementar contador mensual y total
  UPDATE users 
  SET monthly_appraisals_count = monthly_appraisals_count + 1,
      appraisals_count = appraisals_count + 1
  WHERE id = NEW.valuator_id;
  
  RETURN NEW;
END;
$ LANGUAGE plpgsql;

-- Trigger para contar avalúos
DROP TRIGGER IF EXISTS trigger_increment_appraisals ON appraisals;
CREATE TRIGGER trigger_increment_appraisals
AFTER INSERT ON appraisals
FOR EACH ROW
EXECUTE FUNCTION increment_monthly_appraisals();

-- Función para verificar límite de avalúos
CREATE OR REPLACE FUNCTION check_appraisal_limit(user_id_param UUID)
RETURNS BOOLEAN AS $
DECLARE
  user_count INTEGER;
  user_status TEXT;
BEGIN
  -- Obtener contador y status del usuario
  SELECT monthly_appraisals_count, subscription_status
  INTO user_count, user_status
  FROM users
  WHERE id = user_id_param;
  
  -- Plan gratuito: 3 avalúos
  IF user_status = 'free' THEN
    RETURN user_count < 3;
  END IF;
  
  -- Plan Pro: 100 avalúos
  IF user_status = 'pro' THEN
    RETURN user_count < 100;
  END IF;
  
  -- Plan Enterprise: 200 avalúos
  IF user_status = 'enterprise' THEN
    RETURN user_count < 200;
  END IF;
  
  RETURN FALSE;
END;
$ LANGUAGE plpgsql;

-- Función para resetear contador mensual
CREATE OR REPLACE FUNCTION reset_monthly_appraisals()
RETURNS void AS $
BEGIN
  UPDATE users
  SET monthly_appraisals_count = 0,
      last_reset_date = NOW()
  WHERE last_reset_date < DATE_TRUNC('month', NOW());
END;
$ LANGUAGE plpgsql;

-- Deshabilitar RLS en tablas SaaS
ALTER TABLE subscription_plans DISABLE ROW LEVEL SECURITY;
ALTER TABLE subscription_history DISABLE ROW LEVEL SECURITY;