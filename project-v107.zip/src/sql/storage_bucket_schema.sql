-- ============================================
-- CONFIGURACIÓN DE SUPABASE STORAGE
-- Bucket para fotos de avalúos
-- ============================================

-- 1. Crear bucket (si no existe)
INSERT INTO storage.buckets (id, name, public)
VALUES ('appraisal-photos', 'appraisal-photos', false)
ON CONFLICT (id) DO NOTHING;

-- 2. Política para listar buckets (necesaria para evitar "bucket not found")
DROP POLICY IF EXISTS "list_all_buckets" ON storage.buckets;
CREATE POLICY "list_all_buckets" 
ON storage.buckets 
FOR SELECT 
USING (true);

-- 3. Políticas RLS para storage.objects del bucket appraisal-photos

-- Política para SUBIR fotos (INSERT)
DROP POLICY IF EXISTS "Allow authenticated users to upload photos" ON storage.objects;
CREATE POLICY "Allow authenticated users to upload photos"
ON storage.objects 
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'appraisal-photos' AND
  auth.role() = 'authenticated'
);

-- Política para VER fotos (SELECT)
DROP POLICY IF EXISTS "Allow authenticated users to view photos" ON storage.objects;
CREATE POLICY "Allow authenticated users to view photos"
ON storage.objects 
FOR SELECT
TO authenticated
USING (
  bucket_id = 'appraisal-photos' AND
  auth.role() = 'authenticated'
);

-- Política para ELIMINAR fotos (DELETE)
DROP POLICY IF EXISTS "Allow authenticated users to delete photos" ON storage.objects;
CREATE POLICY "Allow authenticated users to delete photos"
ON storage.objects 
FOR DELETE
TO authenticated
USING (
  bucket_id = 'appraisal-photos' AND
  auth.role() = 'authenticated'
);

-- Política para ACTUALIZAR fotos (UPDATE)
DROP POLICY IF EXISTS "Allow authenticated users to update photos" ON storage.objects;
CREATE POLICY "Allow authenticated users to update photos"
ON storage.objects 
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'appraisal-photos' AND
  auth.role() = 'authenticated'
);