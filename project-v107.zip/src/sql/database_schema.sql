-- Tabla de usuarios con roles
DROP TABLE IF EXISTS public.users CASCADE;
CREATE TABLE public.users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin', 'valuador_senior', 'valuador_junior')),
  phone TEXT,
  license_number TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de propiedades
DROP TABLE IF EXISTS public.properties CASCADE;
CREATE TABLE public.properties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_type TEXT NOT NULL CHECK (property_type IN ('casa_popular', 'casa_interes_social', 'casa_media', 'casa_residencial', 'casa_residencial_plus', 'local_comercial', 'oficina', 'bodega', 'edificio')),
  address TEXT NOT NULL,
  city TEXT NOT NULL DEFAULT 'Ciudad de México',
  state TEXT NOT NULL DEFAULT 'CDMX',
  zip_code TEXT,
  total_area_m2 DECIMAL(10,2) NOT NULL,
  built_area_m2 DECIMAL(10,2),
  land_value_per_m2 DECIMAL(10,2),
  construction_value_per_m2 DECIMAL(10,2),
  owner_name TEXT,
  owner_contact TEXT,
  cadastral_key TEXT,
  created_by UUID REFERENCES public.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de avalúos profesionales completa con 12 secciones
DROP TABLE IF EXISTS public.appraisals CASCADE;
CREATE TABLE public.appraisals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- I. Identificación del Avalúo
  appraisal_number TEXT UNIQUE NOT NULL,
  property_id UUID REFERENCES public.properties(id) ON DELETE SET NULL,
  client_name TEXT NOT NULL,
  client_rfc TEXT,
  request_date DATE NOT NULL,
  appraisal_date DATE NOT NULL,
  purpose TEXT NOT NULL,
  
  -- Valuador
  valuator_id UUID REFERENCES public.users(id),
  valuator_name TEXT NOT NULL,
  valuator_license TEXT NOT NULL,
  valuator_email TEXT NOT NULL,
  valuator_phone TEXT NOT NULL,
  
  -- II. Bien Inmueble
  property_type TEXT NOT NULL,
  property_address TEXT NOT NULL,
  property_colony TEXT NOT NULL,
  property_municipality TEXT NOT NULL,
  property_state TEXT NOT NULL,
  property_zip TEXT NOT NULL,
  land_area DECIMAL(10,2) NOT NULL,
  construction_area DECIMAL(10,2) NOT NULL,
  
  -- III. Descripción Urbana
  urban_zone_type TEXT NOT NULL,
  street_type TEXT NOT NULL,
  public_transport TEXT NOT NULL,
  water_service TEXT NOT NULL,
  drainage_service TEXT NOT NULL,
  electricity_service TEXT NOT NULL,
  street_lighting TEXT NOT NULL,
  nearby_services TEXT,
  
  -- IV. Características del Terreno
  land_shape TEXT NOT NULL,
  land_topography TEXT NOT NULL,
  front_meters DECIMAL(10,2) NOT NULL,
  depth_meters DECIMAL(10,2) NOT NULL,
  soil_type TEXT NOT NULL,
  
  -- V. Construcción Básica
  construction_type TEXT NOT NULL,
  construction_age INTEGER NOT NULL,
  conservation_state TEXT NOT NULL,
  number_of_levels TEXT NOT NULL,
  bedrooms INTEGER NOT NULL,
  bathrooms DECIMAL(3,1) NOT NULL,
  parking_spaces INTEGER NOT NULL,
  
  -- V. ELEMENTOS DE LA CONSTRUCCIÓN DETALLADOS
  -- a) Obra Negra o Gruesa
  cimentacion TEXT,
  cimentacion_otro TEXT,
  estructura TEXT,
  estructura_otro TEXT,
  muros TEXT,
  muros_otro TEXT,
  entrepisos TEXT,
  entrepisos_otro TEXT,
  techos TEXT,
  techos_otro TEXT,
  azoteas TEXT,
  azoteas_otro TEXT,
  bardas_cercas TEXT,
  bardas_cercas_otro TEXT,
  
  -- b) Revestimientos y Acabados
  aplanados TEXT,
  aplanados_otro TEXT,
  plafones TEXT,
  plafones_otro TEXT,
  lambrines TEXT,
  lambrines_otro TEXT,
  pisos TEXT,
  pisos_otro TEXT,
  pintura TEXT,
  pintura_otro TEXT,
  
  -- c) Carpintería
  puertas TEXT,
  puertas_otro TEXT,
  ventanas TEXT,
  ventanas_otro TEXT,
  guardamoyas TEXT,
  guardamoyas_otro TEXT,
  
  -- d) Estructuras Metálicas y/o Madera
  estructuras_metalicas TEXT,
  estructuras_metalicas_otro TEXT,
  
  -- e) Otros Elementos
  elementos_otros TEXT,
  
  -- VI. INSTALACIONES DETALLADAS
  -- e) Instalación Hidráulica y Sanitaria
  tuberia_equipo TEXT,
  tuberia_equipo_otro TEXT,
  muebles_sanitarios TEXT,
  muebles_sanitarios_otro TEXT,
  muebles_cocina TEXT,
  muebles_cocina_otro TEXT,
  sanitaria_tuberia TEXT,
  sanitaria_tuberia_otro TEXT,
  sanitaria_registro TEXT,
  sanitaria_registro_otro TEXT,
  
  -- f) Instalaciones Eléctricas
  instalaciones_electricas TEXT,
  instalaciones_electricas_otro TEXT,
  electrica_estado TEXT,
  
  -- g) Puertas y Ventanería Metálica
  puertas_ventaneria_metalica TEXT,
  puertas_ventaneria_metalica_otro TEXT,
  
  -- h) Vidriería
  vidrieria TEXT,
  vidrieria_otro TEXT,
  
  -- i) Instalaciones Especiales y Elementos Accesorios
  instalaciones_especiales TEXT,
  instalaciones_especiales_otro TEXT,
  
  -- j) Obras Complementarias
  obras_complementarias TEXT,
  obras_complementarias_otro TEXT,
  
  -- Observaciones generales de instalaciones
  instalaciones_observaciones TEXT,
  
  -- Reporte fotográfico
  photos JSONB DEFAULT '[]'::jsonb,
  
  -- VI. Instalaciones Básicas (mantener compatibilidad)
  water_installation TEXT NOT NULL,
  drainage_installation TEXT NOT NULL,
  electricity_installation TEXT NOT NULL,
  gas_tipo TEXT NOT NULL DEFAULT 'No',
  gas_tipo_otro TEXT,
  gas_estado TEXT,
  
  -- VII. Mercado
  market_demand TEXT NOT NULL,
  area_growth TEXT NOT NULL,
  comparable_properties TEXT,
  
  -- VIII. Físico Directo
  land_unit_value DECIMAL(15,2),
  land_value_total DECIMAL(15,2),
  construction_unit_value DECIMAL(15,2),
  construction_value_total DECIMAL(15,2),
  depreciation_percentage DECIMAL(5,2),
  physical_total_value DECIMAL(15,2),
  
  -- IX. PRE-REAL
  pre_real_value DECIMAL(15,2),
  pre_real_observations TEXT,
  
  -- X. Capitalización
  monthly_rent DECIMAL(15,2),
  annual_rent DECIMAL(15,2),
  capitalization_rate DECIMAL(5,2),
  capitalization_value DECIMAL(15,2),
  
  -- XI. Homologación
  comparable_1_price DECIMAL(15,2),
  comparable_1_address TEXT,
  comparable_2_price DECIMAL(15,2),
  comparable_2_address TEXT,
  comparable_3_price DECIMAL(15,2),
  comparable_3_address TEXT,
  homologation_average DECIMAL(15,2),
  
  -- XII. Conclusión
  final_method TEXT NOT NULL,
  final_value DECIMAL(15,2) NOT NULL,
  observations TEXT NOT NULL,
  
  -- Status y metadata
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'in_progress', 'completed', 'approved', 'rejected')),
  pdf_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de materiales y precios de construcción
DROP TABLE IF EXISTS public.construction_materials CASCADE;
CREATE TABLE public.construction_materials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category TEXT NOT NULL CHECK (category IN ('estructural', 'acabados', 'instalaciones', 'equipamiento')),
  material_name TEXT NOT NULL,
  unit TEXT NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  description TEXT,
  quality_level TEXT CHECK (quality_level IN ('economica', 'media', 'alta', 'premium')),
  last_updated TIMESTAMPTZ DEFAULT NOW(),
  source TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de costos de construcción por tipo
DROP TABLE IF EXISTS public.construction_costs CASCADE;
CREATE TABLE public.construction_costs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_type TEXT NOT NULL,
  quality_level TEXT NOT NULL CHECK (quality_level IN ('economica', 'media', 'alta', 'premium')),
  cost_per_m2 DECIMAL(10,2) NOT NULL,
  description TEXT,
  includes TEXT,
  last_updated TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de comparables para método de homologación
DROP TABLE IF EXISTS public.comparables CASCADE;
CREATE TABLE public.comparables (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appraisal_id UUID REFERENCES public.appraisals(id) ON DELETE CASCADE,
  property_type TEXT NOT NULL,
  address TEXT NOT NULL,
  total_area_m2 DECIMAL(10,2) NOT NULL,
  sale_price DECIMAL(15,2) NOT NULL,
  price_per_m2 DECIMAL(10,2) NOT NULL,
  sale_date DATE,
  condition_factor DECIMAL(5,2) DEFAULT 1.0,
  location_factor DECIMAL(5,2) DEFAULT 1.0,
  age_factor DECIMAL(5,2) DEFAULT 1.0,
  adjusted_price_per_m2 DECIMAL(10,2),
  source TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de rentas para método de capitalización
DROP TABLE IF EXISTS public.rental_income CASCADE;
CREATE TABLE public.rental_income (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appraisal_id UUID REFERENCES public.appraisals(id) ON DELETE CASCADE,
  monthly_rent DECIMAL(10,2) NOT NULL,
  occupancy_rate DECIMAL(5,2) DEFAULT 100.0,
  annual_expenses DECIMAL(10,2),
  capitalization_rate DECIMAL(5,2) NOT NULL,
  calculated_value DECIMAL(15,2),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de consultas IA
DROP TABLE IF EXISTS public.ai_queries CASCADE;
CREATE TABLE public.ai_queries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.users(id),
  appraisal_id UUID REFERENCES public.appraisals(id),
  query_text TEXT NOT NULL,
  response_text TEXT,
  query_type TEXT CHECK (query_type IN ('material_price', 'valuation_method', 'market_research', 'calculation_help', 'report_generation')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insertar datos iniciales de usuarios
INSERT INTO public.users (email, full_name, role, phone, license_number) VALUES
('admin@avaluotech.com', 'Administrador General', 'admin', '5555555555', 'ADM-001'),
('valuador.senior@avaluotech.com', 'Ing. Carlos Méndez', 'valuador_senior', '5555555556', 'VS-001'),
('valuador.junior@avaluotech.com', 'Arq. Ana López', 'valuador_junior', '5555555557', 'VJ-001');

-- Insertar datos iniciales de materiales de construcción
INSERT INTO public.construction_materials (category, material_name, unit, unit_price, description, quality_level) VALUES
('estructural', 'Concreto premezclado f''c=250 kg/cm²', 'm³', 2850.00, 'Concreto para cimentación y estructura', 'media'),
('estructural', 'Varilla corrugada #3', 'kg', 18.50, 'Acero de refuerzo', 'media'),
('estructural', 'Block hueco 15x20x40 cm', 'pza', 12.50, 'Block para muros', 'economica'),
('acabados', 'Piso cerámico 40x40 cm', 'm²', 285.00, 'Piso para interiores', 'media'),
('acabados', 'Pintura vinílica', 'litro', 95.00, 'Pintura para muros interiores', 'media'),
('acabados', 'Cancelería de aluminio línea económica', 'm²', 850.00, 'Ventanas y puertas', 'economica'),
('instalaciones', 'Tubería PVC hidráulica 1/2"', 'm', 35.00, 'Instalación hidráulica', 'media'),
('instalaciones', 'Cable calibre 12 THW', 'm', 18.00, 'Instalación eléctrica', 'media'),
('estructural', 'Concreto premezclado f''c=350 kg/cm²', 'm³', 3250.00, 'Concreto alta resistencia', 'alta'),
('acabados', 'Piso porcelanato 60x60 cm', 'm²', 485.00, 'Piso premium', 'alta'),
('acabados', 'Cancelería de aluminio línea europea', 'm²', 1850.00, 'Ventanas europeas', 'premium'),
('equipamiento', 'Baño completo económico', 'lote', 4500.00, 'WC, lavabo, regadera', 'economica'),
('equipamiento', 'Baño completo premium', 'lote', 12500.00, 'WC, lavabo, regadera marca', 'premium');

-- Insertar costos de construcción por tipo
INSERT INTO public.construction_costs (property_type, quality_level, cost_per_m2, description, includes) VALUES
('casa_popular', 'economica', 6500.00, 'Vivienda popular', 'Estructura básica, acabados sencillos'),
('casa_interes_social', 'economica', 7800.00, 'Vivienda interés social', 'Estructura básica, acabados estándar'),
('casa_media', 'media', 11500.00, 'Vivienda media', 'Estructura reforzada, acabados de calidad'),
('casa_residencial', 'alta', 15800.00, 'Vivienda residencial', 'Estructura de calidad, acabados premium'),
('casa_residencial_plus', 'premium', 22000.00, 'Vivienda residencial plus', 'Estructura premium, acabados de lujo'),
('local_comercial', 'media', 9500.00, 'Local comercial', 'Estructura comercial, instalaciones básicas'),
('oficina', 'alta', 13500.00, 'Oficina corporativa', 'Acabados corporativos, sistemas avanzados'),
('bodega', 'economica', 5800.00, 'Bodega industrial', 'Estructura industrial, piso industrial'),
('edificio', 'alta', 16500.00, 'Edificio comercial/habitacional', 'Estructura múltiple, sistemas completos');

-- Insertar propiedades de ejemplo
INSERT INTO public.properties (property_type, address, city, total_area_m2, built_area_m2, land_value_per_m2, construction_value_per_m2, owner_name, created_by) VALUES
('casa_media', 'Av. Insurgentes Sur 1234, Col. Del Valle', 'Ciudad de México', 200.00, 180.00, 15000.00, 11500.00, 'Juan Pérez García', (SELECT id FROM public.users WHERE email = 'valuador.senior@avaluotech.com')),
('local_comercial', 'Calle Reforma 567, Col. Centro', 'Ciudad de México', 150.00, 150.00, 25000.00, 9500.00, 'Comercial López S.A.', (SELECT id FROM public.users WHERE email = 'valuador.senior@avaluotech.com')),
('oficina', 'Av. Paseo de la Reforma 890, Col. Polanco', 'Ciudad de México', 300.00, 280.00, 35000.00, 13500.00, 'TechCorp México', (SELECT id FROM public.users WHERE email = 'valuador.junior@avaluotech.com'));

-- Insertar un avalúo de ejemplo con formato profesional completo
INSERT INTO public.appraisals (
  appraisal_number, client_name, request_date, appraisal_date, purpose,
  valuator_name, valuator_license, valuator_email, valuator_phone,
  property_type, property_address, property_colony, property_municipality, property_state, property_zip,
  land_area, construction_area,
  urban_zone_type, street_type, public_transport, water_service, drainage_service, electricity_service, street_lighting,
  land_shape, land_topography, front_meters, depth_meters, soil_type,
  construction_type, construction_age, conservation_state, number_of_levels, bedrooms, bathrooms, parking_spaces,
  water_installation, drainage_installation, electricity_installation, gas_tipo,
  market_demand, area_growth,
  land_unit_value, land_value_total, construction_unit_value, construction_value_total, depreciation_percentage, physical_total_value,
  final_method, final_value, observations, status
) VALUES (
  'AV-20250118-001', 'Juan Pérez García', '2025-01-15', '2025-01-18', 'compraventa',
  'Ing. Carlos Méndez', '12345678', 'valuador@avaluotech.com', '5555555556',
  'casa_habitacion', 'Av. Insurgentes Sur 1234', 'Del Valle', 'Benito Juárez', 'Ciudad de México', '03100',
  200.00, 180.00,
  'residencial', 'pavimentada', 'si', 'si', 'si', 'si', 'si',
  'regular', 'plana', 10.00, 20.00, 'resistente',
  'media', 15, 'bueno', '2', 3, 2.0, 2,
  'si', 'si', 'si', 'si',
  'buena', 'positivo',
  15000.00, 3000000.00, 11500.00, 2070000.00, 10.00, 4863000.00,
  'fisico_directo', 4863000.00, 'Propiedad en excelente estado de conservación, ubicada en zona de alta plusvalía con todos los servicios urbanos disponibles. El inmueble cuenta con acabados de calidad media, instalaciones completas y funcionales. La zona presenta alta demanda y crecimiento positivo del mercado inmobiliario.', 'completed'
);

-- ====================================
-- CATÁLOGOS PARA ELEMENTOS DE CONSTRUCCIÓN E INSTALACIONES
-- ====================================

-- Catálogo de Cimentación
DROP TABLE IF EXISTS public.catalogo_cimentacion CASCADE;
CREATE TABLE public.catalogo_cimentacion (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_cimentacion (opcion) VALUES
('Concreto ciclópeo y mampostería'),
('Zapatas corridas de concreto armado'),
('Losa de cimentación'),
('Pilotes de concreto'),
('Mampostería de piedra'),
('Concreto simple'),
('No identificada'),
('Otra (especificar)');

-- Catálogo de Estructura
DROP TABLE IF EXISTS public.catalogo_estructura CASCADE;
CREATE TABLE public.catalogo_estructura (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_estructura (opcion) VALUES
('Postes de madera y castillos con dalas'),
('Concreto armado (marcos rígidos)'),
('Muros de carga'),
('Acero estructural'),
('Mixta (concreto y acero)'),
('Adobe o bajareque'),
('Madera'),
('Otra (especificar)');

-- Catálogo de Muros
DROP TABLE IF EXISTS public.catalogo_muros CASCADE;
CREATE TABLE public.catalogo_muros (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_muros (opcion) VALUES
('Postería de madera y parquet'),
('Block de concreto'),
('Tabique rojo recocido'),
('Tabicón'),
('Panel de yeso (tablaroca)'),
('Adobe'),
('Madera'),
('Concreto armado'),
('Otra (especificar)');

-- Catálogo de Techos
DROP TABLE IF EXISTS public.catalogo_techos CASCADE;
CREATE TABLE public.catalogo_techos (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_techos (opcion) VALUES
('Madera importada'),
('Losa de concreto armado'),
('Vigueta y bovedilla'),
('Lámina galvanizada'),
('Lámina de asbesto'),
('Teja de barro'),
('Palapa'),
('Lámina acanalada'),
('Otra (especificar)');

-- Catálogo de Azoteas
DROP TABLE IF EXISTS public.catalogo_azoteas CASCADE;
CREATE TABLE public.catalogo_azoteas (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_azoteas (opcion) VALUES
('Material termofusionado SBS de 5mm'),
('Impermeabilizante acrílico'),
('Enladrillado con mortero'),
('Membrana asfáltica'),
('Losa sin impermeabilizar'),
('No aplica'),
('Otra (especificar)');

-- Catálogo de Bardas y Cercas
DROP TABLE IF EXISTS public.catalogo_bardas CASCADE;
CREATE TABLE public.catalogo_bardas (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_bardas (opcion) VALUES
('Malla ciclónica con postes y alambre de púas'),
('Block con aplanado y pintura'),
('Tabique con acabado'),
('Madera'),
('Herrería'),
('Concreto armado'),
('No hay'),
('Otra (especificar)');

-- Catálogo de Aplanados
DROP TABLE IF EXISTS public.catalogo_aplanados CASCADE;
CREATE TABLE public.catalogo_aplanados (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_aplanados (opcion) VALUES
('Yeso y pasta fina con parquet'),
('Yeso pulido'),
('Mezcla cemento-arena'),
('Estuco'),
('Tirol planchado'),
('Sin aplanado'),
('Pasta texturizada'),
('Otra (especificar)');

-- Catálogo de Plafones
DROP TABLE IF EXISTS public.catalogo_plafones CASCADE;
CREATE TABLE public.catalogo_plafones (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_plafones (opcion) VALUES
('Madera importada'),
('Yeso liso'),
('Panel de yeso (tablaroca)'),
('Escayola'),
('Registrable tipo Armstrong'),
('Sin plafón'),
('Otra (especificar)');

-- Catálogo de Lambrines
DROP TABLE IF EXISTS public.catalogo_lambrines CASCADE;
CREATE TABLE public.catalogo_lambrines (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_lambrines (opcion) VALUES
('En áreas húmedas'),
('Azulejo en baños y cocina'),
('Loseta cerámica'),
('Mármol'),
('Madera'),
('Cantera'),
('No aplica'),
('Otra (especificar)');

-- Catálogo de Pisos
DROP TABLE IF EXISTS public.catalogo_pisos CASCADE;
CREATE TABLE public.catalogo_pisos (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_pisos (opcion) VALUES
('Duela de madera nacional'),
('Loseta cerámica'),
('Porcelanato'),
('Mármol'),
('Granito'),
('Concreto pulido'),
('Loseta vinílica'),
('Alfombra'),
('Madera laminada'),
('Firme de concreto simple'),
('Otra (especificar)');

-- Catálogo de Pintura
DROP TABLE IF EXISTS public.catalogo_pintura CASCADE;
CREATE TABLE public.catalogo_pintura (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_pintura (opcion) VALUES
('Barniz y vinílica'),
('Vinílica'),
('Esmalte'),
('Acrílica'),
('Texturizada'),
('Cal'),
('Sin pintura'),
('Otra (especificar)');

-- Catálogo de Puertas y Ventanas
DROP TABLE IF EXISTS public.catalogo_puertas_ventanas CASCADE;
CREATE TABLE public.catalogo_puertas_ventanas (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_puertas_ventanas (opcion) VALUES
('Puertas de madera maciza y de tambor, ventanas de aluminio'),
('Aluminio anodizado'),
('Aluminio blanco'),
('PVC'),
('Madera de pino'),
('Madera fina'),
('Herrería'),
('Mixtas'),
('Otra (especificar)');

-- Catálogo de Tubería
DROP TABLE IF EXISTS public.catalogo_tuberia CASCADE;
CREATE TABLE public.catalogo_tuberia (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_tuberia (opcion) VALUES
('PVC de 4" y 2", hidroneumático'),
('Cobre'),
('PVC hidráulico'),
('Galvanizada'),
('CPVC'),
('PEX'),
('Otra (especificar)');

-- Catálogo de Instalaciones Eléctricas
DROP TABLE IF EXISTS public.catalogo_instalaciones_electricas CASCADE;
CREATE TABLE public.catalogo_instalaciones_electricas (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_instalaciones_electricas (opcion) VALUES
('Ocultas en buen estado'),
('Ocultas en regular estado'),
('Ocultas en mal estado'),
('Visibles en buen estado'),
('Visibles en regular estado'),
('Deficientes'),
('Otra (especificar)');

-- Catálogo de Vidriería
DROP TABLE IF EXISTS public.catalogo_vidrieria CASCADE;
CREATE TABLE public.catalogo_vidrieria (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_vidrieria (opcion) VALUES
('6 mm'),
('4 mm'),
('8 mm'),
('Climalit (doble)'),
('Templado'),
('Laminado'),
('No aplica'),
('Otra (especificar)');

-- ====================================
-- TABLAS PARA MÉTODO FÍSICO DIRECTO PROFESIONAL (VII. APLICACIÓN DEL MÉTODO FÍSICO)
-- ====================================

-- a) TERRENO - Homologación de [tipo]
DROP TABLE IF EXISTS public.physical_method_land CASCADE;
CREATE TABLE public.physical_method_land (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appraisal_id UUID REFERENCES public.appraisals(id) ON DELETE CASCADE NOT NULL,
  classification TEXT NOT NULL DEFAULT 'Homogéneo',
  classification_other TEXT,
  surface_m2 DECIMAL(10,2) NOT NULL DEFAULT 0,
  unit_value DECIMAL(15,2) NOT NULL DEFAULT 0,
  total_value DECIMAL(15,2) GENERATED ALWAYS AS (surface_m2 * unit_value) STORED,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
COMMENT ON TABLE public.physical_method_land IS 'Detalle del cálculo del valor del terreno para el Método Físico Directo.';

-- b) CONSTRUCCIONES (con base en manuales de costos)
DROP TABLE IF EXISTS public.physical_method_constructions CASCADE;
CREATE TABLE public.physical_method_constructions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appraisal_id UUID REFERENCES public.appraisals(id) ON DELETE CASCADE NOT NULL,
  concept TEXT NOT NULL DEFAULT 'Nueva Construcción',
  concept_other TEXT,
  area_type TEXT DEFAULT 'Techada',
  area_type_other TEXT,
  m2 DECIMAL(10,2) NOT NULL DEFAULT 0,
  pu_reposicion DECIMAL(15,2) NOT NULL DEFAULT 0,
  valor_neto DECIMAL(15,2) GENERATED ALWAYS AS (m2 * pu_reposicion) STORED,
  depreciation_percentage DECIMAL(5,2) NOT NULL DEFAULT 0.0,
  factor_resultante DECIMAL(5,2) GENERATED ALWAYS AS (1.0 - depreciation_percentage) STORED,
  valor_parcial DECIMAL(15,2) GENERATED ALWAYS AS (m2 * pu_reposicion * (1.0 - depreciation_percentage)) STORED,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
COMMENT ON TABLE public.physical_method_constructions IS 'Detalle de cálculos de construcciones para el Método Físico Directo.';

-- c) INSTALACIONES ESPECIALIZADAS
DROP TABLE IF EXISTS public.physical_method_installations CASCADE;
CREATE TABLE public.physical_method_installations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appraisal_id UUID REFERENCES public.appraisals(id) ON DELETE CASCADE NOT NULL,
  concept TEXT NOT NULL DEFAULT 'Nueva Instalación',
  concept_other TEXT,
  lote_or_quantity DECIMAL(10,2) NOT NULL DEFAULT 1.0,
  pu_reposicion DECIMAL(15,2) NOT NULL DEFAULT 0,
  factor_obsolescencia_percentage DECIMAL(5,2) NOT NULL DEFAULT 0.0,
  factor_edad_conservacion_percentage DECIMAL(5,2) NOT NULL DEFAULT 0.0,
  depreciation_multiplier DECIMAL(5,2) GENERATED ALWAYS AS ((1.0 - factor_obsolescencia_percentage) * (1.0 - factor_edad_conservacion_percentage)) STORED,
  valor_neto_reposicion DECIMAL(15,2) GENERATED ALWAYS AS (lote_or_quantity * pu_reposicion) STORED,
  valor_parcial DECIMAL(15,2) GENERATED ALWAYS AS (lote_or_quantity * pu_reposicion * (1.0 - factor_obsolescencia_percentage) * (1.0 - factor_edad_conservacion_percentage)) STORED,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
COMMENT ON TABLE public.physical_method_installations IS 'Detalle de instalaciones especializadas para el Método Físico Directo.';

-- d) OTROS BIENES DISTINTOS A LA TIERRA
DROP TABLE IF EXISTS public.physical_method_other_assets CASCADE;
CREATE TABLE public.physical_method_other_assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appraisal_id UUID REFERENCES public.appraisals(id) ON DELETE CASCADE NOT NULL,
  concept TEXT NOT NULL DEFAULT 'Nuevo Bien',
  concept_other TEXT,
  quantity INTEGER NOT NULL DEFAULT 1,
  pu_reposicion_nuevo DECIMAL(15,2) NOT NULL DEFAULT 0,
  factor_obsolescencia_percentage DECIMAL(5,2) NOT NULL DEFAULT 0.0,
  factor_edad_conservacion_percentage DECIMAL(5,2) NOT NULL DEFAULT 0.0,
  depreciation_multiplier DECIMAL(5,2) GENERATED ALWAYS AS ((1.0 - factor_obsolescencia_percentage) * (1.0 - factor_edad_conservacion_percentage)) STORED,
  valor_neto_reposicion DECIMAL(15,2) GENERATED ALWAYS AS (quantity * pu_reposicion_nuevo) STORED,
  valor_parcial DECIMAL(15,2) GENERATED ALWAYS AS (quantity * pu_reposicion_nuevo * (1.0 - factor_obsolescencia_percentage) * (1.0 - factor_edad_conservacion_percentage)) STORED,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
COMMENT ON TABLE public.physical_method_other_assets IS 'Detalle de otros bienes distintos a la tierra para el Método Físico Directo.';

-- Deshabilitar RLS en todas las tablas para permitir acceso
ALTER TABLE public.users DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.properties DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.appraisals DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.construction_materials DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.construction_costs DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.comparables DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.rental_income DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_queries DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_cimentacion DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_estructura DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_muros DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_techos DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_azoteas DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_bardas DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_aplanados DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_plafones DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_lambrines DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_pisos DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_pintura DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_puertas_ventanas DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_tuberia DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_instalaciones_electricas DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_vidrieria DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.physical_method_land DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.physical_method_constructions DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.physical_method_installations DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.physical_method_other_assets DISABLE ROW LEVEL SECURITY;

-- ====================================
-- CATÁLOGOS PARA MÉTODO FÍSICO DIRECTO PROFESIONAL
-- ====================================

-- Catálogo para Clasificación de Terreno
DROP TABLE IF EXISTS public.catalogo_clasificacion_terreno CASCADE;
CREATE TABLE public.catalogo_clasificacion_terreno (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_clasificacion_terreno (opcion) VALUES
('Homogéneo'),
('Esquina'),
('Intermedio'),
('Cabecera'),
('Interior'),
('Irregular'),
('Con pendiente'),
('Plano'),
('Otra (especificar)');

-- Catálogo para Tipo de Área (Construcciones)
DROP TABLE IF EXISTS public.catalogo_tipo_area CASCADE;
CREATE TABLE public.catalogo_tipo_area (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_tipo_area (opcion) VALUES
('Techada'),
('Descubierta'),
('Semi-cubierta'),
('Azotea'),
('Terraza'),
('Balcón'),
('Patio'),
('Estacionamiento techado'),
('Estacionamiento descubierto'),
('Otra (especificar)');

-- Catálogo para Conceptos de Construcción
DROP TABLE IF EXISTS public.catalogo_concepto_construccion CASCADE;
CREATE TABLE public.catalogo_concepto_construccion (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_concepto_construccion (opcion) VALUES
('Planta baja - habitación'),
('Planta alta - habitación'),
('Cocina'),
('Baño completo'),
('Medio baño'),
('Sala-comedor'),
('Estudio'),
('Cuarto de servicio'),
('Bodega'),
('Cochera techada'),
('Cochera descubierta'),
('Terraza'),
('Azotea'),
('Escaleras'),
('Otra (especificar)');

-- Catálogo para Conceptos de Instalaciones Especializadas
DROP TABLE IF EXISTS public.catalogo_concepto_instalacion CASCADE;
CREATE TABLE public.catalogo_concepto_instalacion (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_concepto_instalacion (opcion) VALUES
('Aire acondicionado central'),
('Calefacción'),
('Sistema contra incendios'),
('Elevador'),
('Cisterna'),
('Hidroneumático'),
('Planta de emergencia'),
('Paneles solares'),
('Sistema de seguridad'),
('Alberca'),
('Jardín con riego automático'),
('Bodega refrigerada'),
('Sistema de bombeo'),
('Otra (especificar)');

-- Catálogo para Otros Bienes
DROP TABLE IF EXISTS public.catalogo_otros_bienes CASCADE;
CREATE TABLE public.catalogo_otros_bienes (
  id BIGSERIAL PRIMARY KEY,
  opcion TEXT NOT NULL,
  activo BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.catalogo_otros_bienes (opcion) VALUES
('Muebles de cocina empotrados'),
('Closets empotrados'),
('Aire acondicionado mini-split'),
('Calentador solar'),
('Calentador de gas'),
('Tinaco'),
('Bomba de agua'),
('Portón eléctrico'),
('Ventiladores de techo'),
('Campana extractora'),
('Horno empotrado'),
('Lavadora'),
('Secadora'),
('Refrigerador'),
('Otra (especificar)');

-- Deshabilitar RLS en catálogos del Método Físico Directo
ALTER TABLE public.catalogo_clasificacion_terreno DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_tipo_area DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_concepto_construccion DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_concepto_instalacion DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.catalogo_otros_bienes DISABLE ROW LEVEL SECURITY;