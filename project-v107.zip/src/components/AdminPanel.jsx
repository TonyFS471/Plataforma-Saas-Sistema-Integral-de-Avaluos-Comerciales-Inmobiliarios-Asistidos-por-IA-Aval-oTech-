import React, { useState } from 'react';
import { 
  Settings, 
  Package, 
  Hammer, 
  AlertTriangle, 
  BookOpen,
  ChevronRight,
  Home
} from 'lucide-react';
import MaterialsCatalog from './admin/MaterialsCatalog';
import ConstructionConcepts from './admin/ConstructionConcepts';
import DamageTypes from './admin/DamageTypes';
import KnowledgeBase from './admin/KnowledgeBase';

export default function AdminPanel({ onBack }) {
  const [activeSection, setActiveSection] = useState('materials');

  const sections = [
    {
      id: 'materials',
      name: 'Catálogo de Materiales',
      icon: Package,
      description: 'Gestiona materiales base (cemento, arena, varillas, etc.)',
      component: MaterialsCatalog
    },
    {
      id: 'concepts',
      name: 'Conceptos de Construcción',
      icon: Hammer,
      description: 'Define conceptos por partidas con precios unitarios',
      component: ConstructionConcepts
    },
    {
      id: 'damages',
      name: 'Tipos de Daños (SIED)',
      icon: AlertTriangle,
      description: 'Catálogo de daños estructurales y no estructurales',
      component: DamageTypes
    },
    {
      id: 'knowledge',
      name: 'Base de Conocimiento IA',
      icon: BookOpen,
      description: 'Conocimiento para el chatbot de valuación',
      component: KnowledgeBase
    }
  ];

  const ActiveComponent = sections.find(s => s.id === activeSection)?.component;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={onBack}
                className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
              >
                <Home className="w-5 h-5" />
                <span className="font-medium">Volver al Dashboard</span>
              </button>
              <div className="w-px h-6 bg-slate-300" />
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Settings className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-slate-900">Panel de Administración</h1>
                  <p className="text-sm text-slate-500">Gestión de catálogos y configuración</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4 sticky top-24">
              <h2 className="text-sm font-semibold text-slate-900 mb-3 px-2">Secciones</h2>
              <nav className="space-y-1">
                {sections.map((section) => {
                  const Icon = section.icon;
                  const isActive = activeSection === section.id;
                  
                  return (
                    <button
                      key={section.id}
                      onClick={() => setActiveSection(section.id)}
                      className={`w-full flex items-center justify-between p-3 rounded-xl transition-all ${
                        isActive
                          ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-200'
                          : 'text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className="w-5 h-5" />
                        <span className="font-medium text-sm">{section.name}</span>
                      </div>
                      {isActive && <ChevronRight className="w-4 h-4" />}
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
              {ActiveComponent && <ActiveComponent />}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}