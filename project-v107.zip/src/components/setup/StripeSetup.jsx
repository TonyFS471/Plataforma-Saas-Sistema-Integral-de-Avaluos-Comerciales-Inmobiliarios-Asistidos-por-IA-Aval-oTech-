import React, { useState } from 'react';
import { Zap, CheckCircle, XCircle, Loader } from 'lucide-react';
import { supabase } from '../../lib/supabase';

const StripeSetup = ({ onComplete }) => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const setupStripeProducts = async () => {
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      // Llamar a la Edge Function para actualizar productos en Stripe
      const { data, error: invokeError } = await supabase.functions.invoke('update-stripe-products', {
        method: 'POST'
      });

      if (invokeError) {
        console.error('Error al invocar stripe-create-products:', invokeError);
        setError(invokeError.message || 'Error al comunicarse con Stripe');
        return;
      }

      if (data && data.success) {
        // Guardar los Price IDs en la tabla pricing_plans
        const { profesional, empresarial } = data.products;

        setResult([
          {
            plan_id: 'profesional',
            plan_name: 'Plan Profesional',
            stripe_product_id: profesional.product_id,
            stripe_price_id: profesional.price_id
          },
          {
            plan_id: 'empresarial',
            plan_name: 'Plan Empresarial',
            stripe_product_id: empresarial.product_id,
            stripe_price_id: empresarial.price_id
          }
        ]);

        if (onComplete) {
          setTimeout(() => onComplete(data.products), 2000);
        }
      } else {
        setError(data?.error || 'Error desconocido al crear productos');
      }
    } catch (err) {
      console.error('Error en setupStripeProducts:', err);
      setError(err.message || 'Error de conexión con Stripe');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-200">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full mb-4">
              <Zap className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Configuración de Stripe
            </h1>
            <p className="text-gray-600">
              Crea automáticamente los productos de suscripción en tu cuenta de Stripe
            </p>
          </div>

          {/* Estado */}
          {!loading && !result && !error && (
            <div className="space-y-6">
              <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-6">
                <h3 className="font-semibold text-indigo-900 mb-3">
                  ¿Qué se va a crear?
                </h3>
                <ul className="space-y-2 text-sm text-indigo-800">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 flex-shrink-0 mt-0.5" />
                    <span>
                      <strong>Plan Profesional:</strong> $799 MXN/mes - 100 avalúos por mes
                    </span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 mr-2 flex-shrink-0 mt-0.5" />
                    <span>
                      <strong>Plan Empresarial:</strong> $1,499 MXN/mes - 200 avalúos por mes
                    </span>
                  </li>
                </ul>
              </div>

              <button
                onClick={setupStripeProducts}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-4 rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all transform hover:scale-105 shadow-lg"
              >
                Actualizar Productos en Stripe
              </button>

              <p className="text-xs text-center text-gray-500">
                Esto solo debe ejecutarse una vez. Los productos se crearán automáticamente en tu cuenta de Stripe.
              </p>
            </div>
          )}

          {/* Loading */}
          {loading && (
            <div className="text-center py-12">
              <Loader className="w-12 h-12 text-indigo-600 animate-spin mx-auto mb-4" />
              <p className="text-gray-700 font-medium mb-2">
                Creando productos en Stripe...
              </p>
              <p className="text-sm text-gray-500">
                Esto puede tomar unos segundos
              </p>
            </div>
          )}

          {/* Success */}
          {result && (
            <div className="space-y-4">
              <div className="flex items-center justify-center mb-6">
                <CheckCircle className="w-16 h-16 text-green-500" />
              </div>
              <h2 className="text-2xl font-bold text-center text-gray-900 mb-4">
                ¡Productos Creados Exitosamente!
              </h2>
              <div className="space-y-3">
                {result.map((product) => (
                  <div
                    key={product.plan_id}
                    className="bg-green-50 border border-green-200 rounded-lg p-4"
                  >
                    <p className="font-semibold text-green-900 mb-2">
                      {product.plan_name}
                    </p>
                    <div className="text-sm text-green-800 space-y-1">
                      <p>
                        <span className="font-medium">Product ID:</span>{' '}
                        <code className="bg-green-100 px-2 py-0.5 rounded">
                          {product.stripe_product_id}
                        </code>
                      </p>
                      <p>
                        <span className="font-medium">Price ID:</span>{' '}
                        <code className="bg-green-100 px-2 py-0.5 rounded">
                          {product.stripe_price_id}
                        </code>
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
                <p className="text-sm text-blue-800">
                  ✅ Los productos ya están activos en tu cuenta de Stripe
                  <br />
                  ✅ La base de datos se actualizó automáticamente
                  <br />
                  ✅ El sistema de pagos está listo para funcionar
                </p>
              </div>
            </div>
          )}

          {/* Error */}
          {error && (
            <div className="space-y-4">
              <div className="flex items-center justify-center mb-6">
                <XCircle className="w-16 h-16 text-red-500" />
              </div>
              <h2 className="text-2xl font-bold text-center text-gray-900 mb-4">
                Error al Crear Productos
              </h2>
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-sm text-red-800">{error}</p>
              </div>
              <button
                onClick={setupStripeProducts}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all"
              >
                Intentar de Nuevo
              </button>
            </div>
          )}
        </div>

        {/* Info adicional */}
        {!result && (
          <div className="mt-6 text-center text-sm text-gray-500">
            <p>
              Los productos se crearán en tu cuenta de Stripe conectada
            </p>
            <p className="mt-1">
              Puedes verificarlos después en:{' '}
              <a
                href="https://dashboard.stripe.com/products"
                target="_blank"
                rel="noopener noreferrer"
                className="text-indigo-600 hover:underline"
              >
                dashboard.stripe.com/products
              </a>
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default StripeSetup;