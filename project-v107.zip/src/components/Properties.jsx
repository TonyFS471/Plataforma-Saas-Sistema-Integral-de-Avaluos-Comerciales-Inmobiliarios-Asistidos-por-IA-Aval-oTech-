import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Plus, Edit, Trash2, MapPin, Ruler } from 'lucide-react';

export default function Properties({ user, onUpdate }) {
  const [properties, setProperties] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    property_type: 'casa_media',
    address: '',
    city: 'Ciudad de México',
    state: 'CDMX',
    zip_code: '',
    total_area_m2: '',
    built_area_m2: '',
    land_value_per_m2: '',
    construction_value_per_m2: '',
    owner_name: '',
    owner_contact: '',
    cadastral_key: ''
  });

  const propertyTypes = {
    casa_popular: 'Casa Popular',
    casa_interes_social: 'Casa Interés Social',
    casa_media: 'Casa Media',
    casa_residencial: 'Casa Residencial',
    casa_residencial_plus: 'Casa Residencial Plus',
    local_comercial: 'Local Comercial',
    oficina: 'Oficina',
    bodega: 'Bodega',
    edificio: 'Edificio'
  };

  useEffect(() => {
    loadProperties();
  }, []);

  const loadProperties = async () => {
    const { data } = await supabase
      .from('properties')
      .select('*')
      .order('created_at', { ascending: false });
    setProperties(data || []);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        ...formData,
        total_area_m2: parseFloat(formData.total_area_m2),
        built_area_m2: parseFloat(formData.built_area_m2),
        land_value_per_m2: parseFloat(formData.land_value_per_m2) || null,
        construction_value_per_m2: parseFloat(formData.construction_value_per_m2) || null,
        created_by: user.id
      };

      if (editingId) {
        await supabase.from('properties').update(payload).eq('id', editingId);
      } else {
        await supabase.from('properties').insert([payload]);
      }

      setShowModal(false);
      resetForm();
      loadProperties();
      onUpdate();
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (property) => {
    setFormData({
      property_type: property.property_type,
      address: property.address,
      city: property.city,
      state: property.state,
      zip_code: property.zip_code || '',
      total_area_m2: property.total_area_m2,
      built_area_m2: property.built_area_m2,
      land_value_per_m2: property.land_value_per_m2 || '',
      construction_value_per_m2: property.construction_value_per_m2 || '',
      owner_name: property.owner_name || '',
      owner_contact: property.owner_contact || '',
      cadastral_key: property.cadastral_key || ''
    });
    setEditingId(property.id);
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (confirm('¿Eliminar esta propiedad?')) {
      await supabase.from('properties').delete().eq('id', id);
      loadProperties();
      onUpdate();
    }
  };

  const resetForm = () => {
    setFormData({
      property_type: 'casa_media',
      address: '',
      city: 'Ciudad de México',
      state: 'CDMX',
      zip_code: '',
      total_area_m2: '',
      built_area_m2: '',
      land_value_per_m2: '',
      construction_value_per_m2: '',
      owner_name: '',
      owner_contact: '',
      cadastral_key: ''
    });
    setEditingId(null);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Propiedades</h2>
        <button
          onClick={() => {
            resetForm();
            setShowModal(true);
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition"
        >
          <Plus className="w-5 h-5" />
          Nueva Propiedad
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {properties.map((property) => (
          <div key={property.id} className="bg-white border border-slate-200 rounded-lg p-6 hover:shadow-lg transition">
            <div className="flex justify-between items-start mb-4">
              <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-3 py-1 rounded-full">
                {propertyTypes[property.property_type]}
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => handleEdit(property)}
                  className="text-slate-600 hover:text-blue-600 transition"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(property.id)}
                  className="text-slate-600 hover:text-red-600 transition"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-slate-400 mt-1" />
                <p className="text-sm text-slate-700">{property.address}</p>
              </div>
              <div className="flex items-center gap-2">
                <Ruler className="w-4 h-4 text-slate-400" />
                <p className="text-sm text-slate-700">
                  {property.total_area_m2} m² totales
                </p>
              </div>
              {property.owner_name && (
                <p className="text-sm text-slate-600 mt-3">
                  <strong>Propietario:</strong> {property.owner_name}
                </p>
              )}
            </div>

            {(property.land_value_per_m2 || property.construction_value_per_m2) && (
              <div className="mt-4 pt-4 border-t border-slate-200">
                {property.land_value_per_m2 && (
                  <p className="text-xs text-slate-600">
                    Terreno: ${property.land_value_per_m2.toLocaleString()}/m²
                  </p>
                )}
                {property.construction_value_per_m2 && (
                  <p className="text-xs text-slate-600">
                    Construcción: ${property.construction_value_per_m2.toLocaleString()}/m²
                  </p>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4">
              <h3 className="text-xl font-bold text-slate-900">
                {editingId ? 'Editar Propiedad' : 'Nueva Propiedad'}
              </h3>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Tipo de Propiedad
                </label>
                <select
                  value={formData.property_type}
                  onChange={(e) => setFormData({ ...formData, property_type: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                >
                  {Object.entries(propertyTypes).map(([key, label]) => (
                    <option key={key} value={key}>{label}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Dirección Completa
                </label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Ciudad
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Estado
                  </label>
                  <input
                    type="text"
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    CP
                  </label>
                  <input
                    type="text"
                    value={formData.zip_code}
                    onChange={(e) => setFormData({ ...formData, zip_code: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Área Total (m²)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.total_area_m2}
                    onChange={(e) => setFormData({ ...formData, total_area_m2: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Área Construida (m²)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.built_area_m2}
                    onChange={(e) => setFormData({ ...formData, built_area_m2: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Valor Terreno ($/m²)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.land_value_per_m2}
                    onChange={(e) => setFormData({ ...formData, land_value_per_m2: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Valor Construcción ($/m²)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.construction_value_per_m2}
                    onChange={(e) => setFormData({ ...formData, construction_value_per_m2: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Nombre del Propietario
                </label>
                <input
                  type="text"
                  value={formData.owner_name}
                  onChange={(e) => setFormData({ ...formData, owner_name: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Contacto del Propietario
                </label>
                <input
                  type="text"
                  value={formData.owner_contact}
                  onChange={(e) => setFormData({ ...formData, owner_contact: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Clave Catastral
                </label>
                <input
                  type="text"
                  value={formData.cadastral_key}
                  onChange={(e) => setFormData({ ...formData, cadastral_key: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition disabled:opacity-50"
                >
                  {loading ? 'Guardando...' : editingId ? 'Actualizar' : 'Crear'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                  className="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold py-3 rounded-lg transition"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}