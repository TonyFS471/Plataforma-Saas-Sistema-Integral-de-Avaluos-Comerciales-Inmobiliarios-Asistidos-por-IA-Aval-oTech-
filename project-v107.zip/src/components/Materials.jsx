import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Plus, Edit, Trash2, Package } from 'lucide-react';

export default function Materials({ user, onUpdate }) {
  const [materials, setMaterials] = useState([]);
  const [costs, setCosts] = useState([]);
  const [activeView, setActiveView] = useState('materials');
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    category: 'estructural',
    material_name: '',
    unit: '',
    unit_price: '',
    description: '',
    quality_level: 'media'
  });

  const categories = {
    estructural: 'Estructural',
    acabados: 'Acabados',
    instalaciones: 'Instalaciones',
    equipamiento: 'Equipamiento'
  };

  const qualityLevels = {
    economica: 'Económica',
    media: 'Media',
    alta: 'Alta',
    premium: 'Premium'
  };

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [matData, costData] = await Promise.all([
      supabase.from('construction_materials').select('*').order('category', { ascending: true }),
      supabase.from('construction_costs').select('*').order('property_type', { ascending: true })
    ]);
    setMaterials(matData.data || []);
    setCosts(costData.data || []);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        ...formData,
        unit_price: parseFloat(formData.unit_price)
      };

      if (editingId) {
        await supabase.from('construction_materials').update(payload).eq('id', editingId);
      } else {
        await supabase.from('construction_materials').insert([payload]);
      }

      setShowModal(false);
      resetForm();
      loadData();
      onUpdate();
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (material) => {
    setFormData({
      category: material.category,
      material_name: material.material_name,
      unit: material.unit,
      unit_price: material.unit_price,
      description: material.description || '',
      quality_level: material.quality_level || 'media'
    });
    setEditingId(material.id);
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    if (confirm('¿Eliminar este material?')) {
      await supabase.from('construction_materials').delete().eq('id', id);
      loadData();
      onUpdate();
    }
  };

  const resetForm = () => {
    setFormData({
      category: 'estructural',
      material_name: '',
      unit: '',
      unit_price: '',
      description: '',
      quality_level: 'media'
    });
    setEditingId(null);
  };

  const groupedMaterials = materials.reduce((acc, mat) => {
    if (!acc[mat.category]) acc[mat.category] = [];
    acc[mat.category].push(mat);
    return acc;
  }, {});

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Base de Datos de Construcción</h2>
        <div className="flex gap-3">
          <button
            onClick={() => setActiveView('materials')}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              activeView === 'materials'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
            }`}
          >
            Materiales
          </button>
          <button
            onClick={() => setActiveView('costs')}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              activeView === 'costs'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
            }`}
          >
            Costos por Tipo
          </button>
          {activeView === 'materials' && (
            <button
              onClick={() => {
                resetForm();
                setShowModal(true);
              }}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition"
            >
              <Plus className="w-5 h-5" />
              Nuevo Material
            </button>
          )}
        </div>
      </div>

      {activeView === 'materials' ? (
        <div className="space-y-6">
          {Object.entries(groupedMaterials).map(([category, items]) => (
            <div key={category} className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <Package className="w-5 h-5 text-blue-600" />
                {categories[category]}
              </h3>
              <div className="space-y-2">
                {items.map((mat) => (
                  <div
                    key={mat.id}
                    className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <p className="font-semibold text-slate-900">{mat.material_name}</p>
                        <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                          {qualityLevels[mat.quality_level]}
                        </span>
                      </div>
                      {mat.description && (
                        <p className="text-sm text-slate-600 mt-1">{mat.description}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-lg font-bold text-blue-600">
                          ${mat.unit_price.toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                        </p>
                        <p className="text-xs text-slate-500">por {mat.unit}</p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEdit(mat)}
                          className="text-slate-600 hover:text-blue-600 transition"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(mat.id)}
                          className="text-slate-600 hover:text-red-600 transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-bold text-slate-900 mb-4">
            Costos de Construcción por Tipo de Propiedad
          </h3>
          <div className="space-y-3">
            {costs.map((cost) => (
              <div
                key={cost.id}
                className="flex items-center justify-between p-4 bg-slate-50 rounded-lg"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <p className="font-semibold text-slate-900">{cost.description}</p>
                    <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded">
                      {qualityLevels[cost.quality_level]}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 mt-1">{cost.includes}</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-green-600">
                    ${cost.cost_per_m2.toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                  </p>
                  <p className="text-xs text-slate-500">por m²</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-lg w-full">
            <div className="border-b border-slate-200 px-6 py-4">
              <h3 className="text-xl font-bold text-slate-900">
                {editingId ? 'Editar Material' : 'Nuevo Material'}
              </h3>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Categoría
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                >
                  {Object.entries(categories).map(([key, label]) => (
                    <option key={key} value={key}>{label}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Nombre del Material
                </label>
                <input
                  type="text"
                  value={formData.material_name}
                  onChange={(e) => setFormData({ ...formData, material_name: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Unidad
                  </label>
                  <input
                    type="text"
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    placeholder="m², kg, pza, etc."
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Precio Unitario ($)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.unit_price}
                    onChange={(e) => setFormData({ ...formData, unit_price: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Nivel de Calidad
                </label>
                <select
                  value={formData.quality_level}
                  onChange={(e) => setFormData({ ...formData, quality_level: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                >
                  {Object.entries(qualityLevels).map(([key, label]) => (
                    <option key={key} value={key}>{label}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Descripción
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows="2"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition disabled:opacity-50"
                >
                  {loading ? 'Guardando...' : editingId ? 'Actualizar' : 'Crear'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    resetForm();
                  }}
                  className="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold py-3 rounded-lg transition"
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}