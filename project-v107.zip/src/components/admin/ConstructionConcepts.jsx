import React, { useState, useEffect } from 'react';
import { Plus, Search, Edit2, Trash2, Save, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';

export default function ConstructionConcepts() {
  const [concepts, setConcepts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    category: 'Cimentación',
    unit: 'm2',
    unit_price: '',
    quality_level: 'media',
    useful_life_years: '',
    description: ''
  });

  const categories = [
    'Cimentación', 'Estructura', 'Albañilería', 'Acabados',
    'Instalaciones Hidráulicas', 'Instalaciones Eléctricas',
    'Instalaciones Sanitarias', 'Instalaciones Especiales',
    'Herrería y Cancelería', 'Carpintería', 'Azotea', 'Otros'
  ];

  const units = ['m3', 'm2', 'm', 'pza', 'lote', 'salida', 'punto'];
  const qualityLevels = ['económica', 'media', 'buena', 'muy buena', 'lujo'];

  useEffect(() => {
    loadConcepts();
  }, []);

  const loadConcepts = async () => {
    const { data, error } = await supabase
      .from('construction_concepts')
      .select('*')
      .order('category', { ascending: true })
      .order('name', { ascending: true });

    if (!error && data) {
      setConcepts(data);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const conceptData = {
      ...formData,
      unit_price: parseFloat(formData.unit_price),
      useful_life_years: parseInt(formData.useful_life_years)
    };

    if (editingId) {
      const { error } = await supabase
        .from('construction_concepts')
        .update(conceptData)
        .eq('id', editingId);

      if (!error) {
        setEditingId(null);
        resetForm();
        loadConcepts();
      }
    } else {
      const { error } = await supabase
        .from('construction_concepts')
        .insert([conceptData]);

      if (!error) {
        setIsAdding(false);
        resetForm();
        loadConcepts();
      }
    }
  };

  const handleEdit = (concept) => {
    setFormData({
      name: concept.name,
      category: concept.category,
      unit: concept.unit,
      unit_price: concept.unit_price.toString(),
      quality_level: concept.quality_level,
      useful_life_years: concept.useful_life_years.toString(),
      description: concept.description || ''
    });
    setEditingId(concept.id);
    setIsAdding(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('¿Estás seguro de eliminar este concepto?')) {
      const { error } = await supabase
        .from('construction_concepts')
        .delete()
        .eq('id', id);

      if (!error) {
        loadConcepts();
      }
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      category: 'Cimentación',
      unit: 'm2',
      unit_price: '',
      quality_level: 'media',
      useful_life_years: '',
      description: ''
    });
  };

  const filteredConcepts = concepts.filter(c =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const groupedConcepts = categories.reduce((acc, category) => {
    acc[category] = filteredConcepts.filter(c => c.category === category);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Conceptos de Construcción</h2>
          <p className="text-slate-600 mt-1">Gestiona los conceptos por partidas con precios unitarios</p>
        </div>
        <button
          onClick={() => {
            setIsAdding(!isAdding);
            if (isAdding) {
              resetForm();
              setEditingId(null);
            }
          }}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all"
        >
          {isAdding ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {isAdding ? 'Cancelar' : 'Nuevo Concepto'}
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Buscar conceptos..."
          className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
        />
      </div>

      {/* Form */}
      {isAdding && (
        <form onSubmit={handleSubmit} className="bg-slate-50 rounded-xl p-6 border-2 border-indigo-200">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">
            {editingId ? 'Editar Concepto' : 'Nuevo Concepto'}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Nombre del Concepto *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                placeholder="Ej: Zapata corrida de concreto armado"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Categoría *
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Nivel de Calidad *
              </label>
              <select
                value={formData.quality_level}
                onChange={(e) => setFormData({ ...formData, quality_level: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              >
                {qualityLevels.map(level => (
                  <option key={level} value={level}>{level}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Unidad *
              </label>
              <select
                value={formData.unit}
                onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              >
                {units.map(unit => (
                  <option key={unit} value={unit}>{unit}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Precio Unitario (MXN) *
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.unit_price}
                onChange={(e) => setFormData({ ...formData, unit_price: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Vida Útil (años) *
              </label>
              <input
                type="number"
                value={formData.useful_life_years}
                onChange={(e) => setFormData({ ...formData, useful_life_years: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                placeholder="Ej: 50"
                required
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Descripción / Especificaciones
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                rows="3"
                placeholder="Incluye especificaciones técnicas, materiales incluidos, etc."
              />
            </div>
          </div>

          <div className="flex gap-3 mt-4">
            <button
              type="submit"
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <Save className="w-4 h-4" />
              {editingId ? 'Actualizar' : 'Guardar'}
            </button>
            <button
              type="button"
              onClick={() => {
                setIsAdding(false);
                setEditingId(null);
                resetForm();
              }}
              className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
            >
              Cancelar
            </button>
          </div>
        </form>
      )}

      {/* Concepts List */}
      <div className="space-y-6">
        {categories.map(category => {
          const categoryConcepts = groupedConcepts[category];
          if (categoryConcepts.length === 0) return null;

          return (
            <div key={category} className="space-y-3">
              <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-purple-500" />
                {category}
                <span className="text-sm font-normal text-slate-500">
                  ({categoryConcepts.length})
                </span>
              </h3>
              <div className="grid grid-cols-1 gap-3">
                {categoryConcepts.map(concept => (
                  <div
                    key={concept.id}
                    className="bg-white border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold text-slate-900">{concept.name}</h4>
                        {concept.description && (
                          <p className="text-sm text-slate-600 mt-1">{concept.description}</p>
                        )}
                        <div className="flex items-center gap-4 mt-2 flex-wrap">
                          <span className="text-sm text-slate-500">
                            Unidad: <span className="font-medium text-slate-700">{concept.unit}</span>
                          </span>
                          <span className="text-sm text-slate-500">
                            Precio: <span className="font-medium text-indigo-600">
                              ${concept.unit_price.toFixed(2)} MXN
                            </span>
                          </span>
                          <span className="text-sm text-slate-500">
                            Calidad: <span className="font-medium text-slate-700 capitalize">
                              {concept.quality_level}
                            </span>
                          </span>
                          <span className="text-sm text-slate-500">
                            Vida útil: <span className="font-medium text-slate-700">
                              {concept.useful_life_years} años
                            </span>
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 ml-4">
                        <button
                          onClick={() => handleEdit(concept)}
                          className="p-2 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(concept.id)}
                          className="p-2 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {filteredConcepts.length === 0 && (
        <div className="text-center py-12">
          <p className="text-slate-500">No se encontraron conceptos</p>
        </div>
      )}
    </div>
  );
}