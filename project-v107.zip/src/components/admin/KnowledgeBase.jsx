import React, { useState, useEffect } from 'react';
import { Plus, Search, Edit2, Trash2, Save, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';

export default function KnowledgeBase() {
  const [knowledge, setKnowledge] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    topic: '',
    category: 'Normatividad',
    content: '',
    source: '',
    keywords: ''
  });

  const categories = [
    'Normatividad', 
    'Métodos de Valuación', 
    'Factores de Mercado',
    'Instituciones y Dependencias',
    'Cálculos y Fórmulas',
    'Casos Prácticos',
    'Otros'
  ];

  useEffect(() => {
    loadKnowledge();
  }, []);

  const loadKnowledge = async () => {
    const { data, error } = await supabase
      .from('valuation_knowledge_base')
      .select('*')
      .order('category', { ascending: true })
      .order('topic', { ascending: true });

    if (!error && data) {
      setKnowledge(data);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const knowledgeData = {
      ...formData,
      keywords: formData.keywords.split(',').map(k => k.trim()).filter(k => k)
    };

    if (editingId) {
      const { error } = await supabase
        .from('valuation_knowledge_base')
        .update(knowledgeData)
        .eq('id', editingId);

      if (!error) {
        setEditingId(null);
        resetForm();
        loadKnowledge();
      }
    } else {
      const { error } = await supabase
        .from('valuation_knowledge_base')
        .insert([knowledgeData]);

      if (!error) {
        setIsAdding(false);
        resetForm();
        loadKnowledge();
      }
    }
  };

  const handleEdit = (item) => {
    setFormData({
      topic: item.topic,
      category: item.category,
      content: item.content,
      source: item.source || '',
      keywords: Array.isArray(item.keywords) ? item.keywords.join(', ') : ''
    });
    setEditingId(item.id);
    setIsAdding(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('¿Estás seguro de eliminar este conocimiento?')) {
      const { error } = await supabase
        .from('valuation_knowledge_base')
        .delete()
        .eq('id', id);

      if (!error) {
        loadKnowledge();
      }
    }
  };

  const resetForm = () => {
    setFormData({
      topic: '',
      category: 'Normatividad',
      content: '',
      source: '',
      keywords: ''
    });
  };

  const filteredKnowledge = knowledge.filter(k =>
    k.topic.toLowerCase().includes(searchTerm.toLowerCase()) ||
    k.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (Array.isArray(k.keywords) && k.keywords.some(keyword => 
      keyword.toLowerCase().includes(searchTerm.toLowerCase())
    ))
  );

  const groupedKnowledge = categories.reduce((acc, category) => {
    acc[category] = filteredKnowledge.filter(k => k.category === category);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Base de Conocimiento</h2>
          <p className="text-slate-600 mt-1">Conocimiento para el asistente inteligente de valuación</p>
        </div>
        <button
          onClick={() => {
            setIsAdding(!isAdding);
            if (isAdding) {
              resetForm();
              setEditingId(null);
            }
          }}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all"
        >
          {isAdding ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {isAdding ? 'Cancelar' : 'Nuevo Conocimiento'}
        </button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Buscar conocimiento..."
          className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
        />
      </div>

      {isAdding && (
        <form onSubmit={handleSubmit} className="bg-slate-50 rounded-xl p-6 border-2 border-indigo-200">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">
            {editingId ? 'Editar Conocimiento' : 'Nuevo Conocimiento'}
          </h3>
          <div className="grid grid-cols-1 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Tema / Título *
              </label>
              <input
                type="text"
                value={formData.topic}
                onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                placeholder="Ej: Cálculo del factor de depreciación por edad"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Categoría *
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Contenido / Explicación *
              </label>
              <textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                rows="6"
                placeholder="Escribe la información detallada, fórmulas, procedimientos, normativas, etc."
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Fuente / Referencia
              </label>
              <input
                type="text"
                value={formData.source}
                onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                placeholder="Ej: NOM-123, INEGI, Banco de México, etc."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Palabras Clave (separadas por comas)
              </label>
              <input
                type="text"
                value={formData.keywords}
                onChange={(e) => setFormData({ ...formData, keywords: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                placeholder="Ej: depreciación, vida útil, cálculo, factor"
              />
            </div>
          </div>

          <div className="flex gap-3 mt-4">
            <button
              type="submit"
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <Save className="w-4 h-4" />
              {editingId ? 'Actualizar' : 'Guardar'}
            </button>
            <button
              type="button"
              onClick={() => {
                setIsAdding(false);
                setEditingId(null);
                resetForm();
              }}
              className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
            >
              Cancelar
            </button>
          </div>
        </form>
      )}

      <div className="space-y-6">
        {categories.map(category => {
          const categoryItems = groupedKnowledge[category];
          if (categoryItems.length === 0) return null;

          return (
            <div key={category} className="space-y-3">
              <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                {category}
                <span className="text-sm font-normal text-slate-500">({categoryItems.length})</span>
              </h3>
              <div className="grid grid-cols-1 gap-3">
                {categoryItems.map(item => (
                  <div key={item.id} className="bg-white border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold text-slate-900 mb-2">{item.topic}</h4>
                        <p className="text-sm text-slate-600 mb-2 line-clamp-2">{item.content}</p>
                        <div className="flex items-center gap-4 flex-wrap">
                          {item.source && (
                            <span className="text-xs text-slate-500">
                              Fuente: <span className="font-medium text-indigo-600">{item.source}</span>
                            </span>
                          )}
                          {Array.isArray(item.keywords) && item.keywords.length > 0 && (
                            <div className="flex items-center gap-1 flex-wrap">
                              {item.keywords.map((keyword, idx) => (
                                <span key={idx} className="px-2 py-0.5 bg-slate-100 text-slate-600 text-xs rounded-full">
                                  {keyword}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 ml-4">
                        <button
                          onClick={() => handleEdit(item)}
                          className="p-2 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(item.id)}
                          className="p-2 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {filteredKnowledge.length === 0 && (
        <div className="text-center py-12">
          <p className="text-slate-500">No se encontró conocimiento</p>
        </div>
      )}
    </div>
  );
}