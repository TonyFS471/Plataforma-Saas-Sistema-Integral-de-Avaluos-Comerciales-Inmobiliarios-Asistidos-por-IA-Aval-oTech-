import React, { useState, useEffect } from 'react';
import { Plus, Search, Edit2, Trash2, Save, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';

export default function MaterialsCatalog() {
  const [materials, setMaterials] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    category: 'Agregados',
    unit: 'm3',
    unit_price: '',
    description: ''
  });

  const categories = [
    'Agregados', 'Cementantes', 'Acero', 'Madera', 
    'Block y Tabique', 'Acabados', 'Instalaciones', 'Otros'
  ];

  const units = ['m3', 'm2', 'm', 'kg', 'ton', 'pza', 'lote', 'lt'];

  useEffect(() => {
    loadMaterials();
  }, []);

  const loadMaterials = async () => {
    const { data, error } = await supabase
      .from('materials_catalog')
      .select('*')
      .order('category', { ascending: true })
      .order('name', { ascending: true });

    if (!error && data) {
      setMaterials(data);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const materialData = {
      ...formData,
      unit_price: parseFloat(formData.unit_price)
    };

    if (editingId) {
      const { error } = await supabase
        .from('materials_catalog')
        .update(materialData)
        .eq('id', editingId);

      if (!error) {
        setEditingId(null);
        resetForm();
        loadMaterials();
      }
    } else {
      const { error } = await supabase
        .from('materials_catalog')
        .insert([materialData]);

      if (!error) {
        setIsAdding(false);
        resetForm();
        loadMaterials();
      }
    }
  };

  const handleEdit = (material) => {
    setFormData({
      name: material.name,
      category: material.category,
      unit: material.unit,
      unit_price: material.unit_price.toString(),
      description: material.description || ''
    });
    setEditingId(material.id);
    setIsAdding(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('¿Estás seguro de eliminar este material?')) {
      const { error } = await supabase
        .from('materials_catalog')
        .delete()
        .eq('id', id);

      if (!error) {
        loadMaterials();
      }
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      category: 'Agregados',
      unit: 'm3',
      unit_price: '',
      description: ''
    });
  };

  const filteredMaterials = materials.filter(m =>
    m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const groupedMaterials = categories.reduce((acc, category) => {
    acc[category] = filteredMaterials.filter(m => m.category === category);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Catálogo de Materiales</h2>
          <p className="text-slate-600 mt-1">Gestiona los materiales base para construcción</p>
        </div>
        <button
          onClick={() => {
            setIsAdding(!isAdding);
            if (isAdding) {
              resetForm();
              setEditingId(null);
            }
          }}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all"
        >
          {isAdding ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {isAdding ? 'Cancelar' : 'Nuevo Material'}
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Buscar materiales..."
          className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
        />
      </div>

      {/* Form */}
      {isAdding && (
        <form onSubmit={handleSubmit} className="bg-slate-50 rounded-xl p-6 border-2 border-indigo-200">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">
            {editingId ? 'Editar Material' : 'Nuevo Material'}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Nombre del Material *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Categoría *
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Unidad *
              </label>
              <select
                value={formData.unit}
                onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              >
                {units.map(unit => (
                  <option key={unit} value={unit}>{unit}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Precio Unitario (MXN) *
              </label>
              <input
                type="number"
                step="0.01"
                value={formData.unit_price}
                onChange={(e) => setFormData({ ...formData, unit_price: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Descripción
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                rows="2"
              />
            </div>
          </div>

          <div className="flex gap-3 mt-4">
            <button
              type="submit"
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <Save className="w-4 h-4" />
              {editingId ? 'Actualizar' : 'Guardar'}
            </button>
            <button
              type="button"
              onClick={() => {
                setIsAdding(false);
                setEditingId(null);
                resetForm();
              }}
              className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
            >
              Cancelar
            </button>
          </div>
        </form>
      )}

      {/* Materials List */}
      <div className="space-y-6">
        {categories.map(category => {
          const categoryMaterials = groupedMaterials[category];
          if (categoryMaterials.length === 0) return null;

          return (
            <div key={category} className="space-y-3">
              <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-indigo-500" />
                {category}
                <span className="text-sm font-normal text-slate-500">
                  ({categoryMaterials.length})
                </span>
              </h3>
              <div className="grid grid-cols-1 gap-3">
                {categoryMaterials.map(material => (
                  <div
                    key={material.id}
                    className="bg-white border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold text-slate-900">{material.name}</h4>
                        {material.description && (
                          <p className="text-sm text-slate-600 mt-1">{material.description}</p>
                        )}
                        <div className="flex items-center gap-4 mt-2">
                          <span className="text-sm text-slate-500">
                            Unidad: <span className="font-medium text-slate-700">{material.unit}</span>
                          </span>
                          <span className="text-sm text-slate-500">
                            Precio: <span className="font-medium text-indigo-600">
                              ${material.unit_price.toFixed(2)} MXN
                            </span>
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleEdit(material)}
                          className="p-2 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(material.id)}
                          className="p-2 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {filteredMaterials.length === 0 && (
        <div className="text-center py-12">
          <p className="text-slate-500">No se encontraron materiales</p>
        </div>
      )}
    </div>
  );
}