import React, { useState, useEffect } from 'react';
import { Plus, Search, Edit2, Trash2, Save, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';

export default function DamageTypes() {
  const [damages, setDamages] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    damage_name: '',
    system_type: 'Estructural',
    element_type: 'Cimentación',
    severity_factor: '1.0',
    extension_factor: '1.0',
    progression_factor: '1.0',
    description: ''
  });

  const systemTypes = ['Estructural', 'No Estructural'];
  const elementTypes = [
    'Cimentación', 'Estructura', 'Muros', 'Losas', 'Escaleras',
    'Instalaciones', 'Acabados', 'Azotea', 'Otros'
  ];

  useEffect(() => {
    loadDamages();
  }, []);

  const loadDamages = async () => {
    const { data, error } = await supabase
      .from('damage_types_catalog')
      .select('*')
      .order('system_type', { ascending: true })
      .order('damage_name', { ascending: true });

    if (!error && data) {
      setDamages(data);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const damageData = {
      ...formData,
      severity_factor: parseFloat(formData.severity_factor),
      extension_factor: parseFloat(formData.extension_factor),
      progression_factor: parseFloat(formData.progression_factor)
    };

    if (editingId) {
      const { error } = await supabase
        .from('damage_types_catalog')
        .update(damageData)
        .eq('id', editingId);

      if (!error) {
        setEditingId(null);
        resetForm();
        loadDamages();
      }
    } else {
      const { error } = await supabase
        .from('damage_types_catalog')
        .insert([damageData]);

      if (!error) {
        setIsAdding(false);
        resetForm();
        loadDamages();
      }
    }
  };

  const handleEdit = (damage) => {
    setFormData({
      damage_name: damage.damage_name,
      system_type: damage.system_type,
      element_type: damage.element_type,
      severity_factor: damage.severity_factor.toString(),
      extension_factor: damage.extension_factor.toString(),
      progression_factor: damage.progression_factor.toString(),
      description: damage.description || ''
    });
    setEditingId(damage.id);
    setIsAdding(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('¿Estás seguro de eliminar este tipo de daño?')) {
      const { error } = await supabase
        .from('damage_types_catalog')
        .delete()
        .eq('id', id);

      if (!error) {
        loadDamages();
      }
    }
  };

  const resetForm = () => {
    setFormData({
      damage_name: '',
      system_type: 'Estructural',
      element_type: 'Cimentación',
      severity_factor: '1.0',
      extension_factor: '1.0',
      progression_factor: '1.0',
      description: ''
    });
  };

  const filteredDamages = damages.filter(d =>
    d.damage_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.element_type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const groupedDamages = systemTypes.reduce((acc, type) => {
    acc[type] = filteredDamages.filter(d => d.system_type === type);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Catálogo de Tipos de Daños</h2>
          <p className="text-slate-600 mt-1">Sistema SIED: Severidad, Extensión, Progresión</p>
        </div>
        <button
          onClick={() => {
            setIsAdding(!isAdding);
            if (isAdding) {
              resetForm();
              setEditingId(null);
            }
          }}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all"
        >
          {isAdding ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          {isAdding ? 'Cancelar' : 'Nuevo Daño'}
        </button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Buscar daños..."
          className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
        />
      </div>

      {isAdding && (
        <form onSubmit={handleSubmit} className="bg-slate-50 rounded-xl p-6 border-2 border-indigo-200">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">
            {editingId ? 'Editar Tipo de Daño' : 'Nuevo Tipo de Daño'}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Nombre del Daño *
              </label>
              <input
                type="text"
                value={formData.damage_name}
                onChange={(e) => setFormData({ ...formData, damage_name: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                placeholder="Ej: Grietas en muros por asentamiento diferencial"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Tipo de Sistema *
              </label>
              <select
                value={formData.system_type}
                onChange={(e) => setFormData({ ...formData, system_type: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              >
                {systemTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Elemento Afectado *
              </label>
              <select
                value={formData.element_type}
                onChange={(e) => setFormData({ ...formData, element_type: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              >
                {elementTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Factor de Severidad (0.0 - 1.0) *
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="1"
                value={formData.severity_factor}
                onChange={(e) => setFormData({ ...formData, severity_factor: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Factor de Extensión (0.0 - 1.0) *
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="1"
                value={formData.extension_factor}
                onChange={(e) => setFormData({ ...formData, extension_factor: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Factor de Progresión (0.0 - 1.0) *
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="1"
                value={formData.progression_factor}
                onChange={(e) => setFormData({ ...formData, progression_factor: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-1">
                Descripción / Características
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                rows="3"
                placeholder="Describe el daño, causas comunes, efectos..."
              />
            </div>
          </div>

          <div className="flex gap-3 mt-4">
            <button
              type="submit"
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <Save className="w-4 h-4" />
              {editingId ? 'Actualizar' : 'Guardar'}
            </button>
            <button
              type="button"
              onClick={() => {
                setIsAdding(false);
                setEditingId(null);
                resetForm();
              }}
              className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
            >
              Cancelar
            </button>
          </div>
        </form>
      )}

      <div className="space-y-6">
        {systemTypes.map(type => {
          const typeDamages = groupedDamages[type];
          if (typeDamages.length === 0) return null;

          return (
            <div key={type} className="space-y-3">
              <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full ${type === 'Estructural' ? 'bg-red-500' : 'bg-orange-500'}`} />
                {type}
                <span className="text-sm font-normal text-slate-500">({typeDamages.length})</span>
              </h3>
              <div className="grid grid-cols-1 gap-3">
                {typeDamages.map(damage => (
                  <div key={damage.id} className="bg-white border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-semibold text-slate-900">{damage.damage_name}</h4>
                          <span className="px-2 py-0.5 bg-slate-100 text-slate-600 text-xs rounded-full">
                            {damage.element_type}
                          </span>
                        </div>
                        {damage.description && (
                          <p className="text-sm text-slate-600 mt-1 mb-2">{damage.description}</p>
                        )}
                        <div className="flex items-center gap-4 flex-wrap">
                          <span className="text-sm text-slate-500">
                            Severidad: <span className="font-medium text-red-600">{damage.severity_factor}</span>
                          </span>
                          <span className="text-sm text-slate-500">
                            Extensión: <span className="font-medium text-orange-600">{damage.extension_factor}</span>
                          </span>
                          <span className="text-sm text-slate-500">
                            Progresión: <span className="font-medium text-amber-600">{damage.progression_factor}</span>
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 ml-4">
                        <button
                          onClick={() => handleEdit(damage)}
                          className="p-2 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(damage.id)}
                          className="p-2 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {filteredDamages.length === 0 && (
        <div className="text-center py-12">
          <p className="text-slate-500">No se encontraron tipos de daños</p>
        </div>
      )}
    </div>
  );
}