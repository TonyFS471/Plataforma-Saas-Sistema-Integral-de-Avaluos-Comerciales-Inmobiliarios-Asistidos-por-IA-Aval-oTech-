import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader, CheckCircle, XCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';

export default function AuthCallback() {
  const navigate = useNavigate();
  const [status, setStatus] = useState('verifying'); // verifying, success, error
  const [message, setMessage] = useState('Verificando tu cuenta...');

  useEffect(() => {
    handleAuthCallback();
  }, []);

  const handleAuthCallback = async () => {
    try {
      // Obtener el hash de la URL
      const hashParams = new URLSearchParams(window.location.hash.substring(1));
      const accessToken = hashParams.get('access_token');
      const type = hashParams.get('type');

      if (!accessToken) {
        throw new Error('No se encontró token de acceso');
      }

      // Si es signup, verificar el email
      if (type === 'signup') {
        // Obtener el usuario actual
        const { data: { user }, error: userError } = await supabase.auth.getUser(accessToken);
        
        if (userError) throw userError;

        if (user) {
          // Actualizar el registro en la tabla users para marcar email como verificado
          const { error: updateError } = await supabase
            .from('users')
            .update({ email_verified: true })
            .eq('auth_id', user.id);

          if (updateError) {
            console.error('Error updating user verification:', updateError);
          }

          setStatus('success');
          setMessage('¡Email verificado exitosamente!');
          
          // Redirigir a selección de plan después de 2 segundos
          setTimeout(() => {
            navigate('/pricing');
          }, 2000);
        }
      } else {
        // Si es otro tipo de callback (recovery, etc.)
        setStatus('success');
        setMessage('Autenticación exitosa');
        
        setTimeout(() => {
          navigate('/dashboard');
        }, 2000);
      }

    } catch (error) {
      console.error('Auth callback error:', error);
      setStatus('error');
      setMessage(error.message || 'Error al verificar tu cuenta');
      
      // Redirigir al login después de 3 segundos
      setTimeout(() => {
        navigate('/login');
      }, 3000);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-50 to-pink-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl p-8 text-center">
        {status === 'verifying' && (
          <>
            <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Loader className="w-12 h-12 text-indigo-600 animate-spin" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Verificando tu cuenta
            </h2>
            <p className="text-gray-600">
              Por favor espera mientras verificamos tu email...
            </p>
          </>
        )}

        {status === 'success' && (
          <>
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              {message}
            </h2>
            <p className="text-gray-600">
              Redirigiendo...
            </p>
          </>
        )}

        {status === 'error' && (
          <>
            <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <XCircle className="w-12 h-12 text-red-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Error de Verificación
            </h2>
            <p className="text-gray-600 mb-6">
              {message}
            </p>
            <a
              href="/login"
              className="inline-block bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all duration-200"
            >
              Volver al Inicio de Sesión
            </a>
          </>
        )}
      </div>
    </div>
  );
}