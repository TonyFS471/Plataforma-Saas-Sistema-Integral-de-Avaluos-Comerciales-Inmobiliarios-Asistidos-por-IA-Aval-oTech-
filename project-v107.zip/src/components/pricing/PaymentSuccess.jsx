import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, ArrowRight } from 'lucide-react';

export default function PaymentSuccess() {
  const navigate = useNavigate();

  useEffect(() => {
    // Redirigir automáticamente después de 5 segundos
    const timer = setTimeout(() => {
      navigate('/dashboard');
    }, 5000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-50 to-pink-100 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white rounded-2xl shadow-2xl p-12 text-center">
        {/* Success Icon */}
        <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-8">
          <CheckCircle className="w-16 h-16 text-green-600" />
        </div>

        {/* Title */}
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          ¡Pago Exitoso!
        </h1>

        {/* Message */}
        <p className="text-xl text-gray-600 mb-8">
          Tu suscripción ha sido activada correctamente
        </p>

        {/* Details */}
        <div className="bg-indigo-50 rounded-lg p-6 mb-8 text-left">
          <h3 className="font-semibold text-gray-900 mb-4">
            ¿Qué puedes hacer ahora?
          </h3>
          <ul className="space-y-3">
            <li className="flex items-start">
              <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700">
                Crear avalúos ilimitados con nuestra plataforma profesional
              </span>
            </li>
            <li className="flex items-start">
              <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700">
                Acceder al asistente IA especializado en valuación
              </span>
            </li>
            <li className="flex items-start">
              <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700">
                Exportar tus avalúos a PDF profesional
              </span>
            </li>
            <li className="flex items-start">
              <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700">
                Gestionar tu suscripción desde el dashboard
              </span>
            </li>
          </ul>
        </div>

        {/* Info Box */}
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-8 text-left">
          <p className="text-sm text-yellow-800">
            <strong>Importante:</strong> Recibirás un correo de confirmación con los detalles de tu suscripción y tu recibo de pago.
          </p>
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => navigate('/dashboard')}
            className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-3 rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 flex items-center justify-center"
          >
            Ir al Dashboard
            <ArrowRight className="w-5 h-5 ml-2" />
          </button>
          
          <button
            onClick={() => navigate('/properties')}
            className="bg-white text-indigo-600 px-8 py-3 rounded-lg font-semibold border-2 border-indigo-600 hover:bg-indigo-50 transition-all duration-200"
          >
            Crear mi primer avalúo
          </button>
        </div>

        {/* Auto Redirect Notice */}
        <p className="text-sm text-gray-500 mt-8">
          Serás redirigido automáticamente al dashboard en 5 segundos...
        </p>
      </div>
    </div>
  );
}