import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, Zap, Crown, Loader, AlertCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';

export default function PricingPlans() {
  const navigate = useNavigate();
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processingPlan, setProcessingPlan] = useState(null);
  const [error, setError] = useState('');
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadPlans();
    checkUser();
  }, []);

  const checkUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data: userData } = await supabase
        .from('users')
        .select('*')
        .eq('auth_id', user.id)
        .single();
      
      setCurrentUser(userData);
    }
  };

  const loadPlans = async () => {
    const timeoutId = setTimeout(() => {
      setError('La carga está tardando demasiado. Revisa tu conexión.');
      setLoading(false);
    }, 10000); // 10 segundos timeout

    try {
      setLoading(true);
      setError('');

      console.log('Cargando planes de suscripción...');

      const { data, error: fetchError } = await supabase
        .from('subscription_plans')
        .select('*')
        .order('price', { ascending: true });

      clearTimeout(timeoutId);

      if (fetchError) {
        console.error('Error de Supabase:', fetchError);
        throw fetchError;
      }

      if (!data || data.length === 0) {
        console.warn('No se encontraron planes activos');
        setError('No hay planes disponibles en este momento');
        setPlans([]);
      } else {
        console.log('Planes cargados:', data.length);
        setPlans(data);
      }
    } catch (err) {
      clearTimeout(timeoutId);
      console.error('Error loading plans:', err);
      setError(err.message || 'Error al cargar los planes de suscripción');
      setPlans([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectPlan = async (planId) => {
    if (!currentUser) {
      navigate('/register');
      return;
    }

    setProcessingPlan(planId);
    setError('');

    try {
      if (planId === 'free') {
        // Plan gratuito - actualizar directamente
        const { error: updateError } = await supabase
          .from('users')
          .update({
            subscription_status: 'free',
            appraisals_limit: 3
          })
          .eq('id', currentUser.id);

        if (updateError) throw updateError;

        navigate('/dashboard');
      } else {
        // Planes de pago - crear sesión de checkout de Stripe
        const { data: { user } } = await supabase.auth.getUser();
        
        const response = await supabase.functions.invoke('stripe-create-checkout', {
          body: {
            planId,
            userId: currentUser.id,
            email: currentUser.email
          }
        });

        if (response.error) throw response.error;

        if (response.data?.url) {
          window.location.href = response.data.url;
        } else {
          throw new Error('No se pudo crear la sesión de pago');
        }
      }
    } catch (err) {
      console.error('Error selecting plan:', err);
      setError(err.message || 'Error al seleccionar el plan');
      setProcessingPlan(null);
    }
  };

  const getPlanIcon = (planId) => {
    switch (planId) {
      case 'pro':
        return <Zap className="w-8 h-8" />;
      case 'enterprise':
        return <Crown className="w-8 h-8" />;
      default:
        return <Check className="w-8 h-8" />;
    }
  };

  const getPlanColor = (planId) => {
    switch (planId) {
      case 'pro':
        return 'from-indigo-600 to-purple-600';
      case 'enterprise':
        return 'from-purple-600 to-pink-600';
      default:
        return 'from-gray-600 to-gray-700';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-50 to-pink-100 flex flex-col items-center justify-center px-4">
        <div className="bg-white rounded-2xl shadow-xl p-12 text-center max-w-md">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-indigo-600 border-t-transparent mx-auto mb-6"></div>
          <h3 className="text-xl font-semibold text-gray-800 mb-2">Cargando planes...</h3>
          <p className="text-gray-600">Estamos preparando las opciones para ti</p>
        </div>
      </div>
    );
  }

  if (error && plans.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-50 to-pink-100 flex items-center justify-center px-4">
        <div className="bg-white rounded-2xl shadow-xl p-12 text-center max-w-md">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-red-800 mb-3">Error al cargar planes</h3>
          <p className="text-gray-700 mb-6">{error}</p>
          <button
            onClick={loadPlans}
            className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-semibold transition-colors"
          >
            Reintentar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-50 to-pink-100 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            Elige tu Plan
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Selecciona el plan que mejor se adapte a tus necesidades de valuación profesional
          </p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="max-w-2xl mx-auto mb-8 bg-red-50 border-l-4 border-red-500 p-4 rounded">
            <div className="flex items-start">
              <AlertCircle className="w-5 h-5 text-red-500 mr-3 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        )}

        {/* Plans Grid */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan) => {
            const isRecommended = plan.id === 'pro';
            const features = Array.isArray(plan.features) ? plan.features : [];

            return (
              <div
                key={plan.id}
                className={`relative bg-white rounded-2xl shadow-xl overflow-hidden ${
                  isRecommended ? 'ring-4 ring-indigo-600 transform scale-105' : ''
                }`}
              >
                {/* Recommended Badge */}
                {isRecommended && (
                  <div className="absolute top-0 right-0 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-1 text-sm font-semibold rounded-bl-lg">
                    RECOMENDADO
                  </div>
                )}

                {/* Plan Header */}
                <div className={`bg-gradient-to-r ${getPlanColor(plan.id)} text-white p-8 text-center`}>
                  <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                    {getPlanIcon(plan.id)}
                  </div>
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <p className="text-white text-opacity-90">{plan.description}</p>
                </div>

                {/* Price */}
                <div className="p-8 text-center border-b">
                  <div className="flex items-center justify-center mb-2">
                    <span className="text-4xl font-bold text-gray-900">
                      ${(plan.price || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                    </span>
                    <span className="text-gray-600 ml-2">{plan.currency || 'MXN'}</span>
                  </div>
                  <p className="text-gray-600">
                    {plan.price === 0 ? 'Gratis para siempre' : 'por mes'}
                  </p>
                </div>

                {/* Features */}
                <div className="p-8">
                  <ul className="space-y-4">
                    {features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Button */}
                <div className="p-8 pt-0">
                  <button
                    onClick={() => handleSelectPlan(plan.id)}
                    disabled={processingPlan === plan.id}
                    className={`w-full bg-gradient-to-r ${getPlanColor(plan.id)} text-white py-3 rounded-lg font-semibold hover:opacity-90 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center`}
                  >
                    {processingPlan === plan.id ? (
                      <>
                        <Loader className="w-5 h-5 animate-spin mr-2" />
                        Procesando...
                      </>
                    ) : plan.price === 0 ? (
                      'Comenzar Gratis'
                    ) : (
                      'Suscribirme'
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Note */}
        <div className="text-center mt-12">
          <p className="text-gray-600 mb-2">
            ¿Ya tienes una cuenta?{' '}
            <a href="/login" className="text-indigo-600 hover:text-indigo-700 font-semibold">
              Inicia sesión aquí
            </a>
          </p>
          <p className="text-sm text-gray-500">
            Todos los planes incluyen 7 días de prueba. Cancela en cualquier momento.
          </p>
        </div>
      </div>
    </div>
  );
}