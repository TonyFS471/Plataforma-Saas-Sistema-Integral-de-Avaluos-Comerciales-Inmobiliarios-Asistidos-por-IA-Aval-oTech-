import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Building2, FileText, Database, Bot, LogOut, Home, Plus, Settings, CreditCard } from 'lucide-react';
import Properties from './Properties';
import Appraisals from './Appraisals';
import Materials from './Materials';
import AIAssistant from './AIAssistant';
import AdminPanel from './AdminPanel';
import SubscriptionManager from './subscription/SubscriptionManager';

export default function Dashboard({ user, onLogout }) {
  const [activeTab, setActiveTab] = useState('properties');
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [stats, setStats] = useState({
    properties: 0,
    appraisals: 0,
    materials: 0
  });

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    const [propData, apprData, matData] = await Promise.all([
      supabase.from('properties').select('id', { count: 'exact' }),
      supabase.from('appraisals').select('id', { count: 'exact' }),
      supabase.from('construction_materials').select('id', { count: 'exact' })
    ]);

    setStats({
      properties: propData.count || 0,
      appraisals: apprData.count || 0,
      materials: matData.count || 0
    });
  };

  const tabs = [
    { id: 'properties', name: 'Propiedades', icon: Home },
    { id: 'appraisals', name: 'Avalúos', icon: FileText },
    { id: 'materials', name: 'Materiales', icon: Database },
    { id: 'ai', name: 'Asistente IA', icon: Bot },
    { id: 'subscription', name: 'Mi Suscripción', icon: CreditCard }
  ];

  const getRoleBadge = (role) => {
    const roles = {
      admin: { label: 'Administrador', color: 'bg-purple-100 text-purple-800' },
      valuador_senior: { label: 'Valuador', color: 'bg-blue-100 text-blue-800' },
      valuador_junior: { label: 'Valuador', color: 'bg-green-100 text-green-800' },
      valuador: { label: 'Valuador', color: 'bg-blue-100 text-blue-800' }
    };
    return roles[role] || { label: 'Valuador', color: 'bg-blue-100 text-blue-800' };
  };

  const roleBadge = getRoleBadge(user.role);

  // Si está en el panel de administración, mostrar solo ese componente
  if (showAdminPanel) {
    return <AdminPanel onBack={() => setShowAdminPanel(false)} />;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-slate-900 to-blue-900 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-white/10 p-3 rounded-xl backdrop-blur">
                <Building2 className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">AvalúoTech</h1>
                <p className="text-sm text-blue-200">Sistema de Avalúos Comerciales</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="font-semibold">{user.full_name}</p>
                <span className={`text-xs px-2 py-1 rounded-full ${roleBadge.color}`}>
                  {roleBadge.label}
                </span>
              </div>
              {user.role === 'admin' && (
                <button
                  onClick={() => setShowAdminPanel(true)}
                  className="bg-white/10 hover:bg-white/20 p-2 rounded-lg transition backdrop-blur"
                  title="Panel de Administración"
                >
                  <Settings className="w-5 h-5" />
                </button>
              )}
              <button
                onClick={onLogout}
                className="bg-white/10 hover:bg-white/20 p-2 rounded-lg transition backdrop-blur"
                title="Cerrar sesión"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Stats */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-blue-600">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Propiedades</p>
                <p className="text-3xl font-bold text-slate-900">{stats.properties}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-lg">
                <Home className="w-8 h-8 text-blue-600" />
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-green-600">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Avalúos</p>
                <p className="text-3xl font-bold text-slate-900">{stats.appraisals}</p>
              </div>
              <div className="bg-green-100 p-3 rounded-lg">
                <FileText className="w-8 h-8 text-green-600" />
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl shadow-md p-6 border-l-4 border-purple-600">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Materiales</p>
                <p className="text-3xl font-bold text-slate-900">{stats.materials}</p>
              </div>
              <div className="bg-purple-100 p-3 rounded-lg">
                <Database className="w-8 h-8 text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-md mb-6">
          <div className="border-b border-slate-200">
            <nav className="flex space-x-1 p-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-2 px-4 py-3 rounded-lg font-medium transition ${
                      activeTab === tab.id
                        ? 'bg-blue-600 text-white'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    {tab.name}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Content */}
          <div className="p-6">
            {activeTab === 'properties' && <Properties user={user} onUpdate={loadStats} />}
            {activeTab === 'appraisals' && <Appraisals user={user} onUpdate={loadStats} />}
            {activeTab === 'materials' && <Materials user={user} onUpdate={loadStats} />}
            {activeTab === 'ai' && <AIAssistant user={user} />}
            {activeTab === 'subscription' && <SubscriptionManager user={user} />}
          </div>
        </div>

        {/* Footer con Derechos de Autor */}
        <footer className="bg-white rounded-xl shadow-md p-6 text-center border-t-4 border-blue-600 mt-6">
          <p className="text-slate-600 text-sm">
            © 2025 Todos los Derechos Reservados. <span className="font-semibold">Ing. Santos Antonio Fraustro Solis</span>
          </p>
          <p className="text-slate-400 text-xs mt-1">
            Sistema de Avalúos Asistidos por Inteligencia Artificial
          </p>
        </footer>
      </div>
    </div>
  );
}