import React, { useState, useEffect } from 'react';
import { useAppraisalFormContext } from './context/AppraisalFormContext';
import { Calculator, TrendingUp, DollarSign } from 'lucide-react';

export default function CapitalizationMethod({ viewMode }) {
  const { formData, updateField } = useAppraisalFormContext();
  
  const [monthlyRent, setMonthlyRent] = useState(formData.monthly_rent || 0);
  const [capitalizationRate, setCapitalizationRate] = useState(formData.capitalization_rate || 8);
  const [annualExpenses, setAnnualExpenses] = useState(formData.annual_expenses || 0);
  const [calculatedValue, setCalculatedValue] = useState(0);

  useEffect(() => {
    calculateCapitalization();
  }, [monthlyRent, capitalizationRate, annualExpenses]);

  const calculateCapitalization = () => {
    const annualRent = monthlyRent * 12;
    const netRent = annualRent - annualExpenses;
    const value = capitalizationRate > 0 ? (netRent / (capitalizationRate / 100)) : 0;
    
    setCalculatedValue(value);
    updateField('capitalization_value', value);
  };

  const handleFieldUpdate = (field, value) => {
    updateField(field, value);
    if (field === 'monthly_rent') setMonthlyRent(value);
    if (field === 'capitalization_rate') setCapitalizationRate(value);
    if (field === 'annual_expenses') setAnnualExpenses(value);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('es-MX', {
      style: 'currency',
      currency: 'MXN',
      minimumFractionDigits: 2
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-lg p-6">
        <h3 className="text-xl font-bold text-green-900 mb-2 flex items-center gap-2">
          <TrendingUp className="w-6 h-6" />
          Método de Capitalización de Rentas
        </h3>
        <p className="text-sm text-green-700">
          Este método estima el valor del inmueble basándose en la capacidad de generar ingresos por renta.
        </p>
      </div>

      {/* Fórmula */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h4 className="font-semibold text-blue-900 mb-2">Fórmula:</h4>
        <p className="text-blue-800 font-mono text-sm">
          Valor = Renta Neta Anual / Tasa de Capitalización
        </p>
        <p className="text-blue-700 text-xs mt-2">
          Donde: Renta Neta = (Renta Mensual × 12) - Gastos Anuales
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Renta Mensual */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <DollarSign className="w-4 h-4 inline mr-1" />
            Renta Mensual Estimada
          </label>
          {viewMode ? (
            <p className="text-gray-900 font-semibold">{formatCurrency(monthlyRent)}</p>
          ) : (
            <input
              type="number"
              value={monthlyRent}
              onChange={(e) => handleFieldUpdate('monthly_rent', parseFloat(e.target.value) || 0)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
              min="0"
              step="100"
              placeholder="0.00"
            />
          )}
        </div>

        {/* Tasa de Capitalización */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Tasa de Capitalización (%)
          </label>
          <p className="text-xs text-gray-500 mb-2">
            Tasa típica: 6-12% (menor tasa = mayor valor)
          </p>
          {viewMode ? (
            <p className="text-gray-900 font-semibold">{capitalizationRate}%</p>
          ) : (
            <input
              type="number"
              value={capitalizationRate}
              onChange={(e) => handleFieldUpdate('capitalization_rate', parseFloat(e.target.value) || 0)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
              min="0"
              max="100"
              step="0.1"
            />
          )}
        </div>

        {/* Gastos Anuales */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Gastos Anuales (mantenimiento, impuestos, etc.)
          </label>
          {viewMode ? (
            <p className="text-gray-900 font-semibold">{formatCurrency(annualExpenses)}</p>
          ) : (
            <input
              type="number"
              value={annualExpenses}
              onChange={(e) => handleFieldUpdate('annual_expenses', parseFloat(e.target.value) || 0)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
              min="0"
              step="100"
              placeholder="0.00"
            />
          )}
        </div>
      </div>

      {/* Cálculo Paso a Paso */}
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
        <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
          <Calculator className="w-5 h-5" />
          Cálculo Detallado
        </h4>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">Renta Mensual:</span>
            <span className="font-semibold">{formatCurrency(monthlyRent)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Renta Anual (x12):</span>
            <span className="font-semibold">{formatCurrency(monthlyRent * 12)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">(-) Gastos Anuales:</span>
            <span className="font-semibold text-red-600">-{formatCurrency(annualExpenses)}</span>
          </div>
          <div className="border-t border-gray-300 pt-2 flex justify-between">
            <span className="text-gray-600">Renta Neta Anual:</span>
            <span className="font-semibold text-green-600">{formatCurrency((monthlyRent * 12) - annualExpenses)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Tasa de Capitalización:</span>
            <span className="font-semibold">{capitalizationRate}%</span>
          </div>
          <div className="border-t-2 border-green-500 pt-3 flex justify-between">
            <span className="text-gray-900 font-bold">Valor por Capitalización:</span>
            <span className="font-bold text-xl text-green-600">{formatCurrency(calculatedValue)}</span>
          </div>
        </div>
      </div>

      {/* Observaciones */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Observaciones del Método de Capitalización
        </label>
        <p className="text-xs text-gray-500 mb-2">
          Justifica la tasa elegida y explica las consideraciones del mercado de rentas en la zona.
        </p>
        {viewMode ? (
          <p className="text-gray-900 whitespace-pre-line">{formData.capitalization_observations || 'Sin observaciones.'}</p>
        ) : (
          <textarea
            value={formData.capitalization_observations || ''}
            onChange={(e) => updateField('capitalization_observations', e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
            rows="4"
            placeholder="Explica cómo se determinó la renta mensual, la tasa de capitalización y su relación con el mercado local..."
          />
        )}
      </div>
    </div>
  );
}
