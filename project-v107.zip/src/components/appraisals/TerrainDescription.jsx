import React from 'react';
import { useAppraisalFormContext } from './context/AppraisalFormContext';
import SelectField from '../common/SelectField';

export default function TerrainDescription({ viewMode }) {
  const { formData, updateField } = useAppraisalFormContext();

  const terrainShapes = ['Regular', 'Irregular', 'Rectangular', 'Trapezoidal', 'Triangular'];
  const topographies = ['Plana', 'Pendiente suave', 'Pendiente pronunciada', 'Accidentada'];
  const soilTypes = ['Arcilloso', 'Arenoso', 'Rocoso', 'Mixto', 'Tepetate'];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-slate-900 mb-4">Descripción del Terreno</h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Forma del Terreno */}
        <SelectField
          label="Forma del Terreno"
          value={formData.land_shape || ''}
          onChange={(value) => updateField('land_shape', value)}
          options={terrainShapes}
          viewMode={viewMode}
        />

        {/* Topografía */}
        <SelectField
          label="Topografía"
          value={formData.land_topography || ''}
          onChange={(value) => updateField('land_topography', value)}
          options={topographies}
          viewMode={viewMode}
        />

        {/* Tipo de Suelo */}
        <SelectField
          label="Tipo de Suelo"
          value={formData.soil_type || ''}
          onChange={(value) => updateField('soil_type', value)}
          options={soilTypes}
          viewMode={viewMode}
        />

        {/* Frente (metros) */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Frente (metros)
          </label>
          {viewMode ? (
            <p className="text-gray-900">{formData.front_meters || 0} m</p>
          ) : (
            <input
              type="number"
              value={formData.front_meters || 0}
              onChange={(e) => updateField('front_meters', parseFloat(e.target.value) || 0)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              min="0"
              step="0.01"
            />
          )}
        </div>

        {/* Fondo (metros) */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Fondo (metros)
          </label>
          {viewMode ? (
            <p className="text-gray-900">{formData.depth_meters || 0} m</p>
          ) : (
            <input
              type="number"
              value={formData.depth_meters || 0}
              onChange={(e) => updateField('depth_meters', parseFloat(e.target.value) || 0)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              min="0"
              step="0.01"
            />
          )}
        </div>

        {/* Superficie de Terreno */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Superficie de Terreno (m²)
          </label>
          {viewMode ? (
            <p className="text-gray-900">{formData.land_area || 0} m²</p>
          ) : (
            <input
              type="number"
              value={formData.land_area || 0}
              onChange={(e) => updateField('land_area', parseFloat(e.target.value) || 0)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              min="0"
              step="0.01"
            />
          )}
        </div>
      </div>

      {/* Observaciones */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Observaciones del Terreno
        </label>
        {viewMode ? (
          <p className="text-gray-900 whitespace-pre-line">{formData.terrain_observations || 'Sin observaciones.'}</p>
        ) : (
          <textarea
            value={formData.terrain_observations || ''}
            onChange={(e) => updateField('terrain_observations', e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            rows="4"
            placeholder="Describe características especiales del terreno..."
          />
        )}
      </div>
    </div>
  );
}
