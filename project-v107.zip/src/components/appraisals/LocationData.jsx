import React from 'react';
import { useAppraisalFormContext } from './context/AppraisalFormContext';
import { MapPin, Home, Building2 } from 'lucide-react';

export default function LocationData({ viewMode = false }) {
  const { formData, updateField } = useAppraisalFormContext();

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-lg border-l-4 border-green-500">
        <h3 className="text-xl font-bold text-slate-900 mb-2 flex items-center gap-2">
          <MapPin className="w-6 h-6 text-green-600" />
          II. Ubicación y Datos del Inmueble
        </h3>
        <p className="text-sm text-slate-600">
          Dirección completa y características de ubicación del inmueble
        </p>
      </div>

      {/* Tipo de Inmueble */}
      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          <Building2 className="w-4 h-4 inline mr-2" />
          Tipo de Inmueble
        </label>
        <select
          value={formData.property_type || ''}
          onChange={(e) => updateField('property_type', e.target.value)}
          className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
          disabled={viewMode}
        >
          <option value="">Seleccionar...</option>
          <option value="casa_habitacion">Casa Habitación</option>
          <option value="departamento">Departamento</option>
          <option value="terreno">Terreno</option>
          <option value="local_comercial">Local Comercial</option>
          <option value="bodega">Bodega</option>
          <option value="oficina">Oficina</option>
          <option value="edificio">Edificio</option>
          <option value="rancho">Rancho</option>
          <option value="otro">Otro</option>
        </select>
      </div>

      {/* Dirección */}
      <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
        <h4 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
          <Home className="w-5 h-5 text-green-600" />
          Domicilio del Inmueble
        </h4>
        
        <div className="grid grid-cols-1 gap-4">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Calle y Número
            </label>
            <input 
              type="text" 
              value={formData.property_address || ''} 
              onChange={(e) => updateField('property_address', e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
              disabled={viewMode}
              placeholder="Calle y número exterior/interior"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Colonia / Fraccionamiento
              </label>
              <input 
                type="text" 
                value={formData.property_colony || ''} 
                onChange={(e) => updateField('property_colony', e.target.value)}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
                disabled={viewMode}
                placeholder="Colonia o fraccionamiento"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Código Postal
              </label>
              <input 
                type="text" 
                value={formData.property_zip || ''} 
                onChange={(e) => updateField('property_zip', e.target.value)}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
                disabled={viewMode}
                placeholder="00000"
                maxLength={5}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Municipio / Alcaldía
              </label>
              <input 
                type="text" 
                value={formData.property_municipality || ''} 
                onChange={(e) => updateField('property_municipality', e.target.value)}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
                disabled={viewMode}
                placeholder="Municipio o alcaldía"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Estado
              </label>
              <input 
                type="text" 
                value={formData.property_state || ''} 
                onChange={(e) => updateField('property_state', e.target.value)}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
                disabled={viewMode}
                placeholder="Estado de la República"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Superficies */}
      <div className="bg-green-50 p-6 rounded-lg border border-green-200">
        <h4 className="text-lg font-bold text-slate-800 mb-4">
          Superficies del Inmueble
        </h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Superficie de Terreno (m²)
            </label>
            <input 
              type="number" 
              step="0.01"
              value={formData.land_area || ''} 
              onChange={(e) => updateField('land_area', parseFloat(e.target.value) || 0)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
              disabled={viewMode}
              placeholder="0.00"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Superficie de Construcción (m²)
            </label>
            <input 
              type="number" 
              step="0.01"
              value={formData.construction_area || ''} 
              onChange={(e) => updateField('construction_area', parseFloat(e.target.value) || 0)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
              disabled={viewMode}
              placeholder="0.00"
            />
          </div>
        </div>
      </div>

      {/* Características Básicas */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Recámaras
          </label>
          <input 
            type="number" 
            value={formData.bedrooms || ''} 
            onChange={(e) => updateField('bedrooms', parseInt(e.target.value) || 0)}
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
            disabled={viewMode}
            min="0"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Baños
          </label>
          <input 
            type="number" 
            step="0.5"
            value={formData.bathrooms || ''} 
            onChange={(e) => updateField('bathrooms', parseFloat(e.target.value) || 0)}
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
            disabled={viewMode}
            min="0"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Cajones
          </label>
          <input 
            type="number" 
            value={formData.parking_spaces || ''} 
            onChange={(e) => updateField('parking_spaces', parseInt(e.target.value) || 0)}
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
            disabled={viewMode}
            min="0"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Niveles
          </label>
          <select
            value={formData.number_of_levels || '1'}
            onChange={(e) => updateField('number_of_levels', e.target.value)}
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
            disabled={viewMode}
          >
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5+">5+</option>
          </select>
        </div>
      </div>
    </div>
  );
}