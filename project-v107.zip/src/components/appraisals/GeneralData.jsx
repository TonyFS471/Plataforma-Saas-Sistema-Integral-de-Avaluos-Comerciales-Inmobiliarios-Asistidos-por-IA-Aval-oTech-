import React from 'react';
import { useAppraisalFormContext } from './context/AppraisalFormContext';
import { Calendar, User, FileText, Target } from 'lucide-react';

export default function GeneralData({ viewMode = false }) {
  const { formData, updateField } = useAppraisalFormContext();

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg border-l-4 border-blue-500">
        <h3 className="text-xl font-bold text-slate-900 mb-2 flex items-center gap-2">
          <FileText className="w-6 h-6 text-blue-600" />
          I. Datos Generales del Avalúo
        </h3>
        <p className="text-sm text-slate-600">
          Información general y de identificación del avalúo inmobiliario
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Número de Avalúo */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            <FileText className="w-4 h-4 inline mr-2" />
            Número de Avalúo
          </label>
          <input 
            type="text" 
            value={formData.appraisal_number || ''} 
            onChange={(e) => updateField('appraisal_number', e.target.value)}
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
            disabled={viewMode}
            placeholder="Ej: AV-2025-001"
          />
        </div>

        {/* Fecha de Solicitud */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            <Calendar className="w-4 h-4 inline mr-2" />
            Fecha de Solicitud
          </label>
          <input 
            type="date" 
            value={formData.request_date || ''} 
            onChange={(e) => updateField('request_date', e.target.value)}
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
            disabled={viewMode}
          />
        </div>

        {/* Fecha de Avalúo */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            <Calendar className="w-4 h-4 inline mr-2" />
            Fecha de Avalúo
          </label>
          <input 
            type="date" 
            value={formData.appraisal_date || ''} 
            onChange={(e) => updateField('appraisal_date', e.target.value)}
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
            disabled={viewMode}
          />
        </div>

        {/* Propósito del Avalúo */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            <Target className="w-4 h-4 inline mr-2" />
            Propósito del Avalúo
          </label>
          <select
            value={formData.purpose || ''}
            onChange={(e) => updateField('purpose', e.target.value)}
            className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
            disabled={viewMode}
          >
            <option value="">Seleccionar...</option>
            <option value="Compraventa">Compraventa</option>
            <option value="Crédito Hipotecario">Crédito Hipotecario</option>
            <option value="Garantía">Garantía</option>
            <option value="Fiscal">Fiscal</option>
            <option value="Seguro">Seguro</option>
            <option value="Donación">Donación</option>
            <option value="Herencia">Herencia</option>
            <option value="Adjudicación">Adjudicación</option>
            <option value="Otro">Otro</option>
          </select>
        </div>
      </div>

      {/* Información del Cliente */}
      <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
        <h4 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
          <User className="w-5 h-5 text-blue-600" />
          Datos del Cliente
        </h4>
        
        <div className="grid grid-cols-1 gap-4">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Nombre Completo del Cliente
            </label>
            <input 
              type="text" 
              value={formData.client_name || ''} 
              onChange={(e) => updateField('client_name', e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
              disabled={viewMode}
              placeholder="Nombre completo o razón social"
            />
          </div>
        </div>
      </div>

      {/* Información del Perito Valuador */}
      <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
        <h4 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
          <User className="w-5 h-5 text-blue-600" />
          Datos del Perito Valuador
        </h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Nombre del Valuador
            </label>
            <input 
              type="text" 
              value={formData.valuator_name || ''} 
              onChange={(e) => updateField('valuator_name', e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
              disabled={viewMode}
              placeholder="Nombre completo del perito"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Cédula Profesional / Licencia
            </label>
            <input 
              type="text" 
              value={formData.valuator_license || ''} 
              onChange={(e) => updateField('valuator_license', e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
              disabled={viewMode}
              placeholder="Número de cédula o licencia"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Email del Valuador
            </label>
            <input 
              type="email" 
              value={formData.valuator_email || ''} 
              onChange={(e) => updateField('valuator_email', e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
              disabled={viewMode}
              placeholder="correo@ejemplo.com"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Teléfono del Valuador
            </label>
            <input 
              type="tel" 
              value={formData.valuator_phone || ''} 
              onChange={(e) => updateField('valuator_phone', e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition"
              disabled={viewMode}
              placeholder="555-555-5555"
            />
          </div>
        </div>
      </div>

      {/* Observaciones Generales */}
      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          Observaciones Generales
        </label>
        <textarea
          value={formData.observations || ''}
          onChange={(e) => updateField('observations', e.target.value)}
          rows={4}
          className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none disabled:bg-gray-100 disabled:cursor-not-allowed transition resize-none"
          disabled={viewMode}
          placeholder="Observaciones adicionales sobre el avalúo..."
        />
      </div>
    </div>
  );
}