import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '../../lib/supabase';
import { Camera, Trash, Plus, Image as ImageIcon, UploadCloud, Sparkles } from 'lucide-react';
import { useAppraisalFormContext } from './context/AppraisalFormContext';

export default function PhotoReport({ viewMode }) {
  const { formData, updateField } = useAppraisalFormContext();
  const [photos, setPhotos] = useState(formData.photos || []);
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState({});
  const fileInputRef = useRef(null);

  useEffect(() => {
    setPhotos(formData.photos || []);
  }, [formData.photos]);

  const handleFileChange = async (event) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    const newPhotos = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
      const filePath = `appraisal_photos/${formData.id}/${fileName}`;

      try {
        const { error: uploadError } = await supabase.storage
          .from('appraisal-photos')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        const { data: publicUrlData } = supabase.storage
          .from('appraisal-photos')
          .getPublicUrl(filePath);

        if (publicUrlData.publicUrl) {
          newPhotos.push({
            id: Math.random().toString(36).substring(2, 9),
            url: publicUrlData.publicUrl,
            category: 'Fachada',
            notes: '',
            filename: fileName
          });
        }
      } catch (error) {
        console.error('Error al subir la imagen:', error);
        alert(`Error al subir la imagen ${file.name}: ${error.message}`);
      }
    }

    const updatedPhotos = [...photos, ...newPhotos];
    setPhotos(updatedPhotos);
    updateField('photos', updatedPhotos);
    setUploading(false);
    fileInputRef.current.value = null;
  };

  const handleUpdatePhoto = (id, field, value) => {
    const updatedPhotos = photos.map(p =>
      p.id === id ? { ...p, [field]: value } : p
    );
    setPhotos(updatedPhotos);
    updateField('photos', updatedPhotos);
  };

  const handleDeletePhoto = async (id) => {
    if (!confirm('¿Estás seguro de eliminar esta foto?')) return;

    const photoToDelete = photos.find(p => p.id === id);
    if (!photoToDelete) return;

    try {
      const filePath = `appraisal_photos/${formData.id}/${photoToDelete.filename}`;
      const { error: deleteError } = await supabase.storage
        .from('appraisal-photos')
        .remove([filePath]);

      if (deleteError) throw deleteError;

      const updatedPhotos = photos.filter(p => p.id !== id);
      setPhotos(updatedPhotos);
      updateField('photos', updatedPhotos);
    } catch (error) {
      console.error('Error al eliminar la imagen:', error);
      alert(`Error al eliminar la imagen: ${error.message}`);
    }
  };

  const handleAnalyzePhoto = async (photoId) => {
    const photo = photos.find(p => p.id === photoId);
    if (!photo) return;

    setAnalyzing(prev => ({ ...prev, [photoId]: true }));

    try {
      const { data, error } = await supabase.functions.invoke('analyze-photo-openai', {
        body: {
          imageUrl: photo.url,
          appraisalId: formData.id
        }
      });

      if (error) throw error;

      if (data?.success && data?.analysis) {
        handleUpdatePhoto(photoId, 'notes', data.analysis);
        alert('✅ Análisis con IA completado');
      } else {
        throw new Error(data?.error || 'Error al analizar la imagen');
      }
    } catch (error) {
      console.error('Error al analizar con IA:', error);
      alert(`❌ Error: ${error.message}`);
    } finally {
      setAnalyzing(prev => ({ ...prev, [photoId]: false }));
    }
  };

  const photoCategories = [
    'Fachada', 'Interiores', 'Exteriores', 'Daños', 'Ubicación'
  ];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-slate-900 mb-4">Reporte Fotográfico</h3>

      {!viewMode && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-center justify-between">
          <p className="text-sm text-blue-800">
            Sube fotos del inmueble para el reporte fotográfico.
          </p>
          <input
            type="file"
            id="multi-file-upload"
            accept="image/*"
            multiple
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current.click()}
            disabled={uploading}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition flex items-center gap-2"
          >
            {uploading ? <UploadCloud className="w-5 h-5 animate-pulse" /> : <Plus className="w-5 h-5" />}
            {uploading ? 'Subiendo...' : 'Subir Fotos'}
          </button>
        </div>
      )}

      {photos.length === 0 && !uploading && (
        <div className="bg-white rounded-lg shadow-md p-12 text-center border border-dashed border-gray-300">
          <ImageIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h4 className="text-xl font-semibold text-gray-700 mb-2">
            Aún no hay fotos
          </h4>
          <p className="text-gray-500 mb-6">
            Sube las primeras imágenes del inmueble para empezar tu reporte fotográfico.
          </p>
          {!viewMode && (
            <button
              onClick={() => fileInputRef.current.click()}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition inline-flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Subir Primera Foto
            </button>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {photos.map((photo) => (
          <div key={photo.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <div className="relative h-48 bg-gray-100 flex items-center justify-center">
              <img src={photo.url} alt="Propiedad" className="object-cover w-full h-full" />
              {!viewMode && (
                <button
                  onClick={() => handleDeletePhoto(photo.id)}
                  className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full hover:bg-red-600 transition"
                  title="Eliminar foto"
                >
                  <Trash className="w-4 h-4" />
                </button>
              )}
            </div>
            <div className="p-4 space-y-3">
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">Categoría</label>
                {viewMode ? (
                  <p className="text-sm font-medium text-gray-800">{photo.category}</p>
                ) : (
                  <select
                    value={photo.category}
                    onChange={(e) => handleUpdatePhoto(photo.id, 'category', e.target.value)}
                    className="w-full text-sm px-3 py-2 border border-gray-300 rounded-lg focus:ring-1 focus:ring-blue-500"
                  >
                    {photoCategories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                )}
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">Notas</label>
                {viewMode ? (
                  <p className="text-sm text-gray-700 whitespace-pre-line">{photo.notes || 'Sin notas.'}</p>
                ) : (
                  <>
                    <textarea
                      value={photo.notes}
                      onChange={(e) => handleUpdatePhoto(photo.id, 'notes', e.target.value)}
                      placeholder="Describe lo que se ve en la foto..."
                      rows="2"
                      className="w-full text-sm px-3 py-2 border border-gray-300 rounded-lg focus:ring-1 focus:ring-blue-500 resize-none"
                    />
                    <button
                      onClick={() => handleAnalyzePhoto(photo.id)}
                      disabled={analyzing[photo.id]}
                      className="mt-2 w-full px-3 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition flex items-center justify-center gap-2 text-sm disabled:bg-purple-300"
                    >
                      {analyzing[photo.id] ? (
                        <>
                          <Sparkles className="w-4 h-4 animate-pulse" />
                          Analizando...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4" />
                          Analizar con IA
                        </>
                      )}
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}