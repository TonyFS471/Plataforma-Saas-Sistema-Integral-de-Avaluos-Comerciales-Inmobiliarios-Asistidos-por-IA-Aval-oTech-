import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '../../../lib/supabase';

export const usePreRealMethod = (appraisalId, physicalTotal = 0) => {
  const [preRealData, setPreRealData] = useState({
    // Factores de Integración (Fci)
    fci_ubicacion: 1.00,
    fci_accesibilidad: 1.00,
    fci_servicios: 1.00,
    fci_uso_suelo: 1.00,
    fci_impacto_ambiental: 1.00,
    
    // Factores de Oferta y Demanda (Fod)
    fod_comportamiento_mercado: 1.00,
    fod_transacciones: 1.00,
    fod_liquidez: 1.00,
    fod_plusvalia: 1.00,
    
    // Observaciones
    observaciones: ''
  });

  const [loading, setLoading] = useState(false);

  // Cargar datos desde Supabase
  useEffect(() => {
    if (!appraisalId) return;

    const loadData = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('pre_real_method')
          .select('*')
          .eq('appraisal_id', appraisalId)
          .single();

        if (data) {
          setPreRealData(data);
        }
      } catch (error) {
        console.error('Error cargando PRE-REAL:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [appraisalId]);

  // Actualizar campo
  const updateField = useCallback(async (field, value) => {
    try {
      setPreRealData(prev => ({
        ...prev,
        [field]: value
      }));

      // Guardar en Supabase de forma asíncrona
      if (appraisalId) {
        const { data: existing } = await supabase
          .from('pre_real_method')
          .select('id')
          .eq('appraisal_id', appraisalId)
          .single();

        if (existing) {
          await supabase
            .from('pre_real_method')
            .update({ [field]: value })
            .eq('appraisal_id', appraisalId);
        } else {
          await supabase
            .from('pre_real_method')
            .insert([{
              appraisal_id: appraisalId,
              [field]: value
            }]);
        }
      }
    } catch (error) {
      console.error('Error actualizando PRE-REAL:', error);
    }
  }, [appraisalId]);

  // Cálculos memoizados
  const calculations = useMemo(() => {
    // Factor de Integración (promedio de Fci)
    const fci = (
      parseFloat(preRealData.fci_ubicacion || 1) +
      parseFloat(preRealData.fci_accesibilidad || 1) +
      parseFloat(preRealData.fci_servicios || 1) +
      parseFloat(preRealData.fci_uso_suelo || 1) +
      parseFloat(preRealData.fci_impacto_ambiental || 1)
    ) / 5;

    // Factor de Oferta y Demanda (promedio de Fod)
    const fod = (
      parseFloat(preRealData.fod_comportamiento_mercado || 1) +
      parseFloat(preRealData.fod_transacciones || 1) +
      parseFloat(preRealData.fod_liquidez || 1) +
      parseFloat(preRealData.fod_plusvalia || 1)
    ) / 4;

    // Valor PRE-REAL = Valor Físico Directo × Fci × Fod
    const valorPreReal = physicalTotal * fci * fod;

    return {
      fci: fci.toFixed(4),
      fod: fod.toFixed(4),
      total: valorPreReal
    };
  }, [preRealData, physicalTotal]);

  return {
    preRealData,
    calculations,
    loading,
    updateField
  };
};
