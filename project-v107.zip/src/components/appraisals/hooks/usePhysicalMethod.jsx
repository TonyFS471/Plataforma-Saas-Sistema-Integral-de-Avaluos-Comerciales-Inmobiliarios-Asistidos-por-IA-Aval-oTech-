import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '../../../lib/supabase';

export const usePhysicalMethod = (appraisalId) => {
  const [landItems, setLandItems] = useState([]);
  const [constructionItems, setConstructionItems] = useState([]);
  const [loading, setLoading] = useState(false);

  // Cargar items desde Supabase
  useEffect(() => {
    if (!appraisalId) return;

    const loadItems = async () => {
      try {
        setLoading(true);

        const [landResult, constructionResult] = await Promise.all([
          supabase
            .from('physical_method_land')
            .select('*')
            .eq('appraisal_id', appraisalId)
            .order('created_at', { ascending: true }),
          supabase
            .from('physical_method_construction')
            .select('*')
            .eq('appraisal_id', appraisalId)
            .order('created_at', { ascending: true })
        ]);

        if (landResult.data) setLandItems(landResult.data);
        if (constructionResult.data) setConstructionItems(constructionResult.data);
      } catch (error) {
        console.error('Error cargando items:', error);
      } finally {
        setLoading(false);
      }
    };

    loadItems();
  }, [appraisalId]);

  // Función de cálculo pura
  const calculateItemValues = useCallback((item) => {
    const m2 = parseFloat(item.m2) || 0;
    const puReposicion = parseFloat(item.pu_reposicion) || 0;
    const vidaUtil = parseFloat(item.vida_util) || 100;
    const edadAparente = parseFloat(item.edad_aparente) || 0;
    const costoReposicion = parseFloat(item.costo_reposicion_nuevo) || 0;

    const valorParcial = m2 * puReposicion;
    const depreciationMultiplier = vidaUtil > 0 ? (vidaUtil - edadAparente) / vidaUtil : 1;
    const valorNeto = (costoReposicion > 0 ? costoReposicion : valorParcial) * depreciationMultiplier;

    return {
      valor_parcial: valorParcial,
      depreciation_multiplier: depreciationMultiplier,
      valor_neto: valorNeto
    };
  }, []);

  // Actualizar item con cálculos automáticos
  const updateItem = useCallback(async (table, id, updates) => {
    try {
      const setterFunction = table === 'physical_method_land' ? setLandItems : setConstructionItems;
      
      // Calcular valores derivados
      const calculatedValues = calculateItemValues({ ...updates });
      const fullUpdate = { ...updates, ...calculatedValues };

      // Actualizar estado local inmediatamente
      setterFunction(prev =>
        prev.map(item => (item.id === id ? { ...item, ...fullUpdate } : item))
      );

      // Persistir a Supabase de forma asíncrona
      await supabase
        .from(table)
        .update(fullUpdate)
        .eq('id', id);

    } catch (error) {
      console.error('Error actualizando item:', error);
    }
  }, [calculateItemValues]);

  // Agregar nuevo item
  const addItem = useCallback(async (table, newItem) => {
    try {
      const calculatedValues = calculateItemValues(newItem);
      const fullItem = { ...newItem, ...calculatedValues, appraisal_id: appraisalId };

      const { data, error } = await supabase
        .from(table)
        .insert([fullItem])
        .select()
        .single();

      if (error) throw error;

      const setterFunction = table === 'physical_method_land' ? setLandItems : setConstructionItems;
      setterFunction(prev => [...prev, data]);

      return data;
    } catch (error) {
      console.error('Error agregando item:', error);
      throw error;
    }
  }, [appraisalId, calculateItemValues]);

  // Eliminar item
  const deleteItem = useCallback(async (table, id) => {
    try {
      await supabase
        .from(table)
        .delete()
        .eq('id', id);

      const setterFunction = table === 'physical_method_land' ? setLandItems : setConstructionItems;
      setterFunction(prev => prev.filter(item => item.id !== id));
    } catch (error) {
      console.error('Error eliminando item:', error);
      throw error;
    }
  }, []);

  // Cálculos memoizados
  const totals = useMemo(() => {
    const landTotal = landItems.reduce((sum, item) => sum + (parseFloat(item.valor_neto) || 0), 0);
    const constructionTotal = constructionItems.reduce((sum, item) => sum + (parseFloat(item.valor_neto) || 0), 0);
    const total = landTotal + constructionTotal;

    return {
      landTotal,
      constructionTotal,
      total
    };
  }, [landItems, constructionItems]);

  return {
    landItems,
    constructionItems,
    totals,
    loading,
    updateItem,
    addItem,
    deleteItem
  };
};
