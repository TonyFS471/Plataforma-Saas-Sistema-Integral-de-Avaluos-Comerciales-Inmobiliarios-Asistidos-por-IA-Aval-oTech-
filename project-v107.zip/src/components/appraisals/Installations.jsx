import SelectField from '../common/SelectField';
import { useAppraisalFormContext } from './context/AppraisalFormContext';

export default function Installations({ viewMode }) {
  const { formData, updateField } = useAppraisalFormContext();
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-slate-900 mb-4">VII. Instalaciones Detalladas</h3>
      
      {/* INSTALACIÓN HIDRÁULICA */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-blue-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">INSTALACIÓN HIDRÁULICA</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SelectField
            label="Tubería/Equipo"
            value={formData.tuberia_equipo || ''}
            onChange={(val) => updateField('tuberia_equipo', val)}
            otherValue={formData.tuberia_equipo_otro || ''}
            onOtherChange={(val) => updateField('tuberia_equipo_otro', val)}
            options={[
              'Galvanizada',
              'Cobre',
              'PVC',
              'CPVC',
              'PEX',
              'Polietileno'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Muebles Sanitarios"
            value={formData.muebles_sanitarios || ''}
            onChange={(val) => updateField('muebles_sanitarios', val)}
            otherValue={formData.muebles_sanitarios_otro || ''}
            onOtherChange={(val) => updateField('muebles_sanitarios_otro', val)}
            options={[
              'Económicos',
              'Estándar',
              'De calidad',
              'De lujo'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Muebles de Cocina"
            value={formData.muebles_cocina || ''}
            onChange={(val) => updateField('muebles_cocina', val)}
            otherValue={formData.muebles_cocina_otro || ''}
            onOtherChange={(val) => updateField('muebles_cocina_otro', val)}
            options={[
              'Sin muebles',
              'Económicos',
              'Estándar',
              'De calidad',
              'De lujo'
            ]}
            disabled={viewMode}
          />
        </div>
      </div>
      
      {/* INSTALACIÓN SANITARIA */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-green-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">INSTALACIÓN SANITARIA</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SelectField
            label="Tubería"
            value={formData.sanitaria_tuberia || ''}
            onChange={(val) => updateField('sanitaria_tuberia', val)}
            otherValue={formData.sanitaria_tuberia_otro || ''}
            onOtherChange={(val) => updateField('sanitaria_tuberia_otro', val)}
            options={[
              'Barro',
              'Concreto',
              'Asbesto cemento',
              'Fierro fundido',
              'PVC',
              'Cobre'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Registro"
            value={formData.sanitaria_registro || ''}
            onChange={(val) => updateField('sanitaria_registro', val)}
            otherValue={formData.sanitaria_registro_otro || ''}
            onOtherChange={(val) => updateField('sanitaria_registro_otro', val)}
            options={[
              'Sin registro',
              'Tabique',
              'Prefabricado',
              'Concreto armado'
            ]}
            disabled={viewMode}
          />
        </div>
      </div>
      
      {/* INSTALACIÓN ELÉCTRICA */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-yellow-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">INSTALACIÓN ELÉCTRICA</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SelectField
            label="Tipo de Instalación"
            value={formData.instalaciones_electricas || ''}
            onChange={(val) => updateField('instalaciones_electricas', val)}
            otherValue={formData.instalaciones_electricas_otro || ''}
            onOtherChange={(val) => updateField('instalaciones_electricas_otro', val)}
            options={[
              'Aparente',
              'Oculta económica',
              'Oculta de calidad'
            ]}
            disabled={viewMode}
          />
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Estado General</label>
            <select
              value={formData.electrica_estado || ''}
              onChange={(e) => updateField('electrica_estado', e.target.value)}
              disabled={viewMode}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none disabled:bg-gray-100"
            >
              <option value="">Seleccionar...</option>
              <option value="excelente">Excelente</option>
              <option value="bueno">Bueno</option>
              <option value="regular">Regular</option>
              <option value="malo">Malo</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* INSTALACIONES DE GAS */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-red-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">INSTALACIONES DE GAS</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SelectField
            label="Tipo de Gas"
            value={formData.gas_tipo || ''}
            onChange={(val) => updateField('gas_tipo', val)}
            otherValue={formData.gas_tipo_otro || ''}
            onOtherChange={(val) => updateField('gas_tipo_otro', val)}
            options={[
              'Sin instalación de gas',
              'Gas LP (cilindro)',
              'Gas LP (estacionario)',
              'Gas natural'
            ]}
            disabled={viewMode}
          />
          
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Estado General</label>
            <select
              value={formData.gas_estado || ''}
              onChange={(e) => updateField('gas_estado', e.target.value)}
              disabled={viewMode}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none disabled:bg-gray-100"
            >
              <option value="">Seleccionar...</option>
              <option value="excelente">Excelente</option>
              <option value="bueno">Bueno</option>
              <option value="regular">Regular</option>
              <option value="malo">Malo</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* PUERTAS Y VENTANERÍA METÁLICA */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-purple-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">PUERTAS Y VENTANERÍA METÁLICA</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SelectField
            label="Puertas/Ventanería Metálica"
            value={formData.puertas_ventaneria_metalica || ''}
            onChange={(val) => updateField('puertas_ventaneria_metalica', val)}
            otherValue={formData.puertas_ventaneria_metalica_otro || ''}
            onOtherChange={(val) => updateField('puertas_ventaneria_metalica_otro', val)}
            options={[
              'Sin elementos metálicos',
              'Herrería económica',
              'Herrería de calidad',
              'Aluminio económico',
              'Aluminio anodizado',
              'Aluminio de calidad',
              'Acero inoxidable'
            ]}
            disabled={viewMode}
          />
        </div>
      </div>
      
      {/* VIDRERÍA */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-indigo-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">VIDRERÍA</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SelectField
            label="Tipo de Vidrio"
            value={formData.vidrieria || ''}
            onChange={(val) => updateField('vidrieria', val)}
            otherValue={formData.vidrieria_otro || ''}
            onOtherChange={(val) => updateField('vidrieria_otro', val)}
            options={[
              'Semidoble',
              'Doble',
              'Templado',
              'Laminado',
              'Climalit (doble acristalamiento)'
            ]}
            disabled={viewMode}
          />
        </div>
      </div>
      
      {/* INSTALACIONES ESPECIALES */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-pink-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">INSTALACIONES ESPECIALES</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SelectField
            label="Instalaciones Especiales"
            value={formData.instalaciones_especiales || ''}
            onChange={(val) => updateField('instalaciones_especiales', val)}
            otherValue={formData.instalaciones_especiales_otro || ''}
            onOtherChange={(val) => updateField('instalaciones_especiales_otro', val)}
            options={[
              'Sin instalaciones especiales',
              'Aire acondicionado tipo ventana',
              'Aire acondicionado minisplit',
              'Aire acondicionado central',
              'Calefacción',
              'Elevador',
              'Sistema de seguridad',
              'Red de datos',
              'Sistema de sonido',
              'Paneles solares'
            ]}
            disabled={viewMode}
          />
        </div>
      </div>
      
      {/* OBRAS COMPLEMENTARIAS */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-orange-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">OBRAS COMPLEMENTARIAS</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SelectField
            label="Obras Complementarias"
            value={formData.obras_complementarias || ''}
            onChange={(val) => updateField('obras_complementarias', val)}
            otherValue={formData.obras_complementarias_otro || ''}
            onOtherChange={(val) => updateField('obras_complementarias_otro', val)}
            options={[
              'Sin obras complementarias',
              'Cisterna',
              'Alberca',
              'Jardín',
              'Áreas verdes',
              'Cochera techada',
              'Terraza',
              'Roof garden',
              'Bodega',
              'Cuarto de servicio'
            ]}
            disabled={viewMode}
          />
        </div>
      </div>
      
      {/* OBSERVACIONES ADICIONALES */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-gray-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">OBSERVACIONES ADICIONALES</h4>
        
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">Observaciones sobre Instalaciones</label>
          <textarea
            value={formData.instalaciones_observaciones || ''}
            onChange={(e) => updateField('instalaciones_observaciones', e.target.value)}
            placeholder="Detalles adicionales sobre las instalaciones..."
            rows="3"
            disabled={viewMode}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none resize-none disabled:bg-gray-100"
          />
        </div>
      </div>
    </div>
  );
}
