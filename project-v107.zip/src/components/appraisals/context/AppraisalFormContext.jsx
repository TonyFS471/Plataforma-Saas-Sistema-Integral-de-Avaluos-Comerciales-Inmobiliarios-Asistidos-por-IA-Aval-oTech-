import React, { createContext, useContext, useState, useCallback, useEffect, useMemo } from 'react';
import { supabase } from '../../../lib/supabase';

const AppraisalFormContext = createContext();

export const useAppraisalFormContext = () => {
  const context = useContext(AppraisalFormContext);
  if (!context) {
    throw new Error('useAppraisalFormContext debe usarse dentro de AppraisalFormProvider');
  }
  return context;
};

export const AppraisalFormProvider = ({ children, appraisalId }) => {
  const [formData, setFormData] = useState({
    // Identificación
    id: appraisalId || null,
    appraisal_number: '',
    appraisal_date: new Date().toISOString().split('T')[0],
    client_name: '',
    client_email: '',
    client_phone: '',
    property_id: '',
    
    // Detalles de la propiedad
    property_type: 'casa',
    address: '',
    city: '',
    state: '',
    zip_code: '',
    
    // Descripción urbana
    land_use: '',
    zoning: '',
    infrastructure: '',
    
    // Características del terreno
    land_area: '',
    land_shape: '',
    land_topography: '',
    land_services: '',
    
    // Características de la construcción
    construction_area: '',
    construction_levels: '',
    construction_age: '',
    conservation_state: 'bueno',
    
    // ELEMENTOS CONSTRUCTIVOS - a) OBRA NEGRA
    cimentacion: '',
    cimentacion_otro: '',
    estructura: '',
    estructura_otro: '',
    muros: '',
    muros_otro: '',
    entrepisos: '',
    entrepisos_otro: '',
    techos: '',
    techos_otro: '',
    azoteas: '',
    azoteas_otro: '',
    bardas_cercas: '',
    bardas_cercas_otro: '',
    
    // b) REVESTIMIENTOS Y ACABADOS
    aplanados: '',
    aplanados_otro: '',
    plafones: '',
    plafones_otro: '',
    lambrines: '',
    lambrines_otro: '',
    pisos: '',
    pisos_otro: '',
    pintura: '',
    pintura_otro: '',
    
    // c) CARPINTERÍA
    puertas: '',
    puertas_otro: '',
    ventanas: '',
    ventanas_otro: '',
    guardamoyas: '',
    guardamoyas_otro: '',
    
    // d) ESTRUCTURAS METÁLICAS
    estructuras_metalicas: '',
    estructuras_metalicas_otro: '',
    
    // e) OTROS ELEMENTOS
    elementos_otros: '',
    
    // INSTALACIONES - Muebles
    muebles_sanitarios: '',
    muebles_sanitarios_otro: '',
    muebles_cocina: '',
    muebles_cocina_otro: '',
    
    // INSTALACIONES - Hidráulica
    hidraulica_tuberia: '',
    hidraulica_tuberia_otro: '',
    
    // INSTALACIONES - Sanitaria
    sanitaria_tuberia: '',
    sanitaria_tuberia_otro: '',
    sanitaria_registro: '',
    sanitaria_registro_otro: '',
    
    // INSTALACIONES - Eléctrica
    electrica_tipo: '',
    electrica_tipo_otro: '',
    electrica_estado: '',
    
    // INSTALACIONES - Gas
    gas_tipo: 'No',
    gas_tipo_otro: '',
    gas_estado: '',
    
    // INSTALACIONES - Especiales
    puertas_ventaneria_metalica: '',
    puertas_ventaneria_metalica_otro: '',
    instalaciones_especiales: '',
    instalaciones_especiales_otro: '',
    
    // INSTALACIONES - Obras complementarias
    obras_complementarias: '',
    obras_complementarias_otro: '',
    instalaciones_observaciones: '',
    
    // Valores de métodos
    physical_total_value: 0,
    pre_real_value: 0,
    pre_real_observations: '',
    capitalization_value: 0,
    homologation_average: 0,
    
    // Capitalización
    monthly_rent: '',
    capitalization_rate: '',
    annual_rent: '',
    
    // Homologación
    comparable_1_price: '',
    comparable_2_price: '',
    comparable_3_price: '',
    
    // Conclusión
    final_value: '',
    observations: '',
    recommendations: '',
    
    // Reporte fotográfico
    photos: []
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Cargar datos del avalúo automáticamente al montar
  useEffect(() => {
    if (appraisalId) {
      loadAppraisal(appraisalId);
    }
  }, [appraisalId]);

  // Actualizar un campo específico CON PERSISTENCIA AUTOMÁTICA
  // MEMOIZADO para evitar recreaciones que causen bucles infinitos
  const updateField = useCallback(async (field, value) => {
    // Actualizar UI inmediatamente
    setFormData(prev => {
      // CRÍTICO: No actualizar si el valor es el mismo (previene bucles)
      if (prev[field] === value) {
        return prev;
      }
      return {
        ...prev,
        [field]: value
      };
    });

    // Persistir a Supabase SOLO si existe appraisalId
    if (appraisalId) {
      try {
        await supabase
          .from('appraisals')
          .update({ [field]: value })
          .eq('id', appraisalId);
      } catch (err) {
        console.error('[Context] Error al guardar campo:', err);
      }
    }
  }, [appraisalId]);

  // Actualizar múltiples campos SIN auto-persistencia (para operaciones batch)
  // MEMOIZADO para estabilidad de referencia
  const updateFields = useCallback((fields) => {
    setFormData(prev => ({
      ...prev,
      ...fields
    }));
  }, []);

  // Guardar borrador
  const saveDraft = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuario no autenticado');

      const appraisalData = {
        ...formData,
        user_id: user.id,
        status: 'borrador',
        updated_at: new Date().toISOString()
      };

      if (appraisalId) {
        const { error: updateError } = await supabase
          .from('appraisals')
          .update(appraisalData)
          .eq('id', appraisalId);

        if (updateError) throw updateError;
      } else {
        const { data, error: insertError } = await supabase
          .from('appraisals')
          .insert([appraisalData])
          .select()
          .single();

        if (insertError) throw insertError;
        return data.id;
      }

      return appraisalId;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [formData, appraisalId]);

  // Enviar avalúo
  const submitAppraisal = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuario no autenticado');

      const appraisalData = {
        ...formData,
        user_id: user.id,
        status: 'completado',
        submitted_at: new Date().toISOString()
      };

      if (appraisalId) {
        const { error: updateError } = await supabase
          .from('appraisals')
          .update(appraisalData)
          .eq('id', appraisalId);

        if (updateError) throw updateError;
      } else {
        const { data, error: insertError } = await supabase
          .from('appraisals')
          .insert([appraisalData])
          .select()
          .single();

        if (insertError) throw insertError;
        return data.id;
      }

      return appraisalId;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [formData, appraisalId]);

  // Cargar avalúo existente
  const loadAppraisal = useCallback(async (id) => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('appraisals')
        .select('*')
        .eq('id', id)
        .maybeSingle(); // ✅ Usar maybeSingle() en lugar de single() para manejar 0 o 1 resultado

      if (fetchError) {
        console.error('[Context] Error al cargar avalúo:', fetchError);
        throw fetchError;
      }

      if (!data) {
        throw new Error(`No se encontró el avalúo con ID: ${id}`);
      }
      
      setFormData(data);
    } catch (err) {
      console.error('[Context] Error fatal al cargar avalúo:', err);
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  // CRÍTICO: Memoizar el valor del contexto para evitar recreaciones innecesarias
  // Esto previene bucles infinitos en componentes que consumen el contexto
  const value = useMemo(() => ({
    formData,
    updateField,
    updateFields,
    saveDraft,
    submitAppraisal,
    loadAppraisal,
    loading,
    error,
    appraisalId
  }), [formData, updateField, updateFields, saveDraft, submitAppraisal, loadAppraisal, loading, error, appraisalId]);

  return (
    <AppraisalFormContext.Provider value={value}>
      {children}
    </AppraisalFormContext.Provider>
  );
};
