import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '../../lib/supabase';
import { Plus, Trash2 } from 'lucide-react';
import SelectField from '../common/SelectField';
import YesNoDescriptionField from '../common/YesNoDescriptionField';

// Componente auxiliar para inputs en tabla
const TableInput = ({ type = 'text', value, onChange, disabled, step = 'any', placeholder = '', min = '0' }) => (
  <input
    type={type}
    value={value || ''}
    onChange={onChange}
    className="w-full p-1 border border-slate-300 rounded text-sm disabled:bg-gray-100 dark:bg-slate-700 dark:text-gray-200 dark:border-slate-600"
    disabled={disabled}
    step={step}
    placeholder={placeholder}
    min={min}
  />
);

// Componente para campos de selección con texto alternativo (igual que en otros pasos)
const TableSelectField = ({ value, otherValue, onChange, onOtherChange, options, disabled, placeholder = '' }) => (
  <div className="w-full">
    <select
      value={value || ''}
      onChange={(e) => onChange(e.target.value)}
      className="w-full p-1 border border-slate-300 rounded text-sm disabled:bg-gray-100 dark:bg-slate-700 dark:text-gray-200 dark:border-slate-600"
      disabled={disabled}
    >
      <option value="">{placeholder}</option>
      {options.map((opt, idx) => (
        <option key={idx} value={opt}>{opt}</option>
      ))}
    </select>
    {value === 'Otra (especificar)' && (
      <input
        type="text"
        value={otherValue || ''}
        onChange={(e) => onOtherChange(e.target.value)}
        className="w-full p-1 border border-slate-300 rounded text-sm mt-1 dark:bg-slate-700 dark:text-gray-200 dark:border-slate-600"
        placeholder="Especificar..."
        disabled={disabled}
      />
    )}
  </div>
);

export default function PhysicalMethod({ appraisalId, onPhysicalMethodTotalChange, viewMode }) {
  const [landItems, setLandItems] = useState([]);
  const [constructionItems, setConstructionItems] = useState([]);
  const [installationItems, setInstallationItems] = useState([]);
  const [otherAssetsItems, setOtherAssetsItems] = useState([]);
  const [loading, setLoading] = useState(false);

  // Estados para los catálogos
  const [catalogoClasificacionTerreno, setCatalogoClasificacionTerreno] = useState([]);
  const [catalogoTipoArea, setCatalogoTipoArea] = useState([]);
  const [catalogoConceptoConstruccion, setCatalogoConceptoConstruccion] = useState([]);
  const [catalogoConceptoInstalacion, setCatalogoConceptoInstalacion] = useState([]);
  const [catalogoOtrosBienes, setCatalogoOtrosBienes] = useState([]);

  // Cargar catálogos desde Supabase
  useEffect(() => {
    const fetchCatalogos = async () => {
      try {
        const [clasificacionRes, tipoAreaRes, conceptoConstrRes, conceptoInstRes, otrosBienesRes] = await Promise.all([
          supabase.from('catalogo_clasificacion_terreno').select('opcion').eq('activo', true).order('id'),
          supabase.from('catalogo_tipo_area').select('opcion').eq('activo', true).order('id'),
          supabase.from('catalogo_concepto_construccion').select('opcion').eq('activo', true).order('id'),
          supabase.from('catalogo_concepto_instalacion').select('opcion').eq('activo', true).order('id'),
          supabase.from('catalogo_otros_bienes').select('opcion').eq('activo', true).order('id')
        ]);

        if (!clasificacionRes.error) setCatalogoClasificacionTerreno(clasificacionRes.data.map(c => c.opcion));
        if (!tipoAreaRes.error) setCatalogoTipoArea(tipoAreaRes.data.map(c => c.opcion));
        if (!conceptoConstrRes.error) setCatalogoConceptoConstruccion(conceptoConstrRes.data.map(c => c.opcion));
        if (!conceptoInstRes.error) setCatalogoConceptoInstalacion(conceptoInstRes.data.map(c => c.opcion));
        if (!otrosBienesRes.error) setCatalogoOtrosBienes(otrosBienesRes.data.map(c => c.opcion));
      } catch (error) {
        console.error('Error fetching catalogos:', error);
      }
    };

    fetchCatalogos();
  }, []);

  // --- Fetch Data ---
  useEffect(() => {
    if (!appraisalId) return;

    const fetchPhysicalMethodData = async () => {
      setLoading(true);
      try {
        const [landRes, constRes, instRes, otherRes] = await Promise.all([
          supabase.from('physical_method_land').select('*').eq('appraisal_id', appraisalId).order('created_at'),
          supabase.from('physical_method_constructions').select('*').eq('appraisal_id', appraisalId).order('created_at'),
          supabase.from('physical_method_installations').select('*').eq('appraisal_id', appraisalId).order('created_at'),
          supabase.from('physical_method_other_assets').select('*').eq('appraisal_id', appraisalId).order('created_at'),
        ]);

        if (landRes.error) throw landRes.error;
        if (constRes.error) throw constRes.error;
        if (instRes.error) throw instRes.error;
        if (otherRes.error) throw otherRes.error;

        setLandItems(landRes.data || []);
        setConstructionItems(constRes.data || []);
        setInstallationItems(instRes.data || []);
        setOtherAssetsItems(otherRes.data || []);

      } catch (error) {
        console.error('Error fetching physical method data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPhysicalMethodData();
  }, [appraisalId]);

  // --- Calculations ---
  const calculateSubtotals = useCallback(() => {
    const subtotalLand = landItems.reduce((sum, item) => sum + (parseFloat(item.total_value) || 0), 0);
    const subtotalConstructions = constructionItems.reduce((sum, item) => sum + (parseFloat(item.valor_parcial) || 0), 0);
    const subtotalInstallations = installationItems.reduce((sum, item) => sum + (parseFloat(item.valor_parcial) || 0), 0);
    const subtotalOtherAssets = otherAssetsItems.reduce((sum, item) => sum + (parseFloat(item.valor_parcial) || 0), 0);

    const totalPhysicalValue = subtotalLand + subtotalConstructions + subtotalInstallations + subtotalOtherAssets;
    onPhysicalMethodTotalChange(totalPhysicalValue);

    return {
      subtotalLand,
      subtotalConstructions,
      subtotalInstallations,
      subtotalOtherAssets,
      totalPhysicalValue
    };
  }, [landItems, constructionItems, installationItems, otherAssetsItems, onPhysicalMethodTotalChange]);

  useEffect(() => {
    calculateSubtotals();
  }, [landItems, constructionItems, installationItems, otherAssetsItems, calculateSubtotals]);

  // --- CRUD Operations for each section ---

  // Generic item change handler, saves to DB immediately
  const handleItemChange = async (table, items, setItems, id, field, value) => {
    // Parse value for numeric fields
    let parsedValue = value;
    if (['surface_m2', 'unit_value', 'm2', 'pu_reposicion', 'lote_or_quantity', 'quantity', 'pu_reposicion_nuevo'].includes(field)) {
      parsedValue = parseFloat(value) || 0;
    } else if (['depreciation_percentage', 'factor_obsolescencia_percentage', 'factor_edad_conservacion_percentage'].includes(field)) {
      // Convert input percentage (e.g., 10 for 10%) to decimal (0.10) for database storage
      parsedValue = (parseFloat(value) / 100) || 0;
      if (parsedValue < 0) parsedValue = 0;
      if (parsedValue > 1) parsedValue = 1;
    }

    const updatedItems = items.map(item =>
      item.id === id ? { ...item, [field]: parsedValue } : item
    );
    setItems(updatedItems);

    if (appraisalId && id) { // Only update DB if appraisalId and item id exist
      setLoading(true);
      try {
        const updatePayload = { [field]: parsedValue };
        const { error } = await supabase.from(table).update(updatePayload).eq('id', id);
        if (error) throw error;
        
        // Re-fetch the item to get the updated calculated columns
        const { data: updatedItem, error: fetchError } = await supabase.from(table).select('*').eq('id', id).single();
        if (fetchError) throw fetchError;
        
        // Update the state with the fresh data from DB
        setItems(prevItems => prevItems.map(item => item.id === id ? updatedItem : item));
      } catch (error) {
        console.error(`Error updating ${table} item ${id} for field ${field}:`, error);
      } finally {
        setLoading(false);
      }
    }
  };

  // Generic add item handler
  const handleAddItem = async (table, items, setItems, newItemDefaults) => {
    if (!appraisalId) {
      alert('Para añadir elementos del Método Físico, primero debes guardar el avalúo como borrador.');
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from(table)
        .insert([{ ...newItemDefaults, appraisal_id: appraisalId }])
        .select()
        .single();
      if (error) throw error;
      setItems([...items, data]);
    } catch (error) {
      console.error(`Error adding item to ${table}:`, error);
      alert(`Error al añadir el elemento: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Generic remove item handler
  const handleRemoveItem = async (table, items, setItems, id) => {
    if (!confirm('¿Estás seguro de eliminar este elemento definitivamente?')) return;
    setLoading(true);
    try {
      const { error } = await supabase.from(table).delete().eq('id', id);
      if (error) throw error;
      setItems(items.filter(item => item.id !== id));
    } catch (error) {
      console.error(`Error removing item from ${table}:`, error);
      alert(`Error al eliminar el elemento: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // --- Section specific handlers ---
  const handleLandChange = (id, field, value) => handleItemChange('physical_method_land', landItems, setLandItems, id, field, value);
  const handleAddLandItem = () => handleAddItem('physical_method_land', landItems, setLandItems, { classification: 'Homogéneo', surface_m2: 0, unit_value: 0 });
  const handleRemoveLandItem = (id) => handleRemoveItem('physical_method_land', landItems, setLandItems, id);

  const handleConstructionChange = (id, field, value) => handleItemChange('physical_method_constructions', constructionItems, setConstructionItems, id, field, value);
  const handleAddConstructionItem = () => handleAddItem('physical_method_constructions', constructionItems, setConstructionItems, { concept: 'Nueva Construcción', area_type: 'Techada', m2: 0, pu_reposicion: 0, depreciation_percentage: 0 });
  const handleRemoveConstructionItem = (id) => handleRemoveItem('physical_method_constructions', constructionItems, setConstructionItems, id);

  const handleInstallationChange = (id, field, value) => handleItemChange('physical_method_installations', installationItems, setInstallationItems, id, field, value);
  const handleAddInstallationItem = () => handleAddItem('physical_method_installations', installationItems, setInstallationItems, { concept: 'Nueva Instalación Especializada', lote_or_quantity: 1, pu_reposicion: 0, factor_obsolescencia_percentage: 0, factor_edad_conservacion_percentage: 0 });
  const handleRemoveInstallationItem = (id) => handleRemoveItem('physical_method_installations', installationItems, setInstallationItems, id);

  const handleOtherAssetChange = (id, field, value) => handleItemChange('physical_method_other_assets', otherAssetsItems, setOtherAssetsItems, id, field, value);
  const handleAddOtherAssetItem = () => handleAddItem('physical_method_other_assets', otherAssetsItems, setOtherAssetsItems, { concept: 'Nuevo Bien', quantity: 1, pu_reposicion_nuevo: 0, factor_obsolescencia_percentage: 0, factor_edad_conservacion_percentage: 0 });
  const handleRemoveOtherAssetItem = (id) => handleRemoveItem('physical_method_other_assets', otherAssetsItems, setOtherAssetsItems, id);

  const { subtotalLand, subtotalConstructions, subtotalInstallations, subtotalOtherAssets, totalPhysicalValue } = calculateSubtotals();

  return (
    <div className="space-y-8 p-1">
      <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-4">VII. APLICACIÓN DEL MÉTODO FÍSICO</h3>

      {loading && <p className="text-center text-slate-600 dark:text-slate-400">Cargando datos...</p>}
      
      {/* a) TERRENO */}
      <div className="bg-white dark:bg-slate-800 rounded-lg p-6 shadow-sm border border-slate-200 dark:border-slate-700">
        <h4 className="text-md font-bold text-slate-900 dark:text-slate-100 mb-4">a) TERRENO: Homologación de [tipo]</h4>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
            <thead className="bg-slate-50 dark:bg-slate-700">
              <tr>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Clasificación</th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Superficie (m²)</th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Valor Unit. ($/m²)</th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase tracking-wider">Valor ($)</th>
                {!viewMode && <th scope="col" className="relative px-3 py-2"><span className="sr-only">Acciones</span></th>}
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
              {landItems.map((item) => (
                <tr key={item.id}>
                  <td className="px-3 py-2 whitespace-nowrap">
                    <TableSelectField 
                      value={item.classification} 
                      otherValue={item.classification_other}
                      onChange={(val) => handleLandChange(item.id, 'classification', val)} 
                      onOtherChange={(val) => handleLandChange(item.id, 'classification_other', val)}
                      options={catalogoClasificacionTerreno}
                      disabled={viewMode}
                      placeholder="Seleccione clasificación"
                    />
                  </td>
                  <td className="px-3 py-2 whitespace-nowrap"><TableInput type="number" step="0.01" value={item.surface_m2} onChange={(e) => handleLandChange(item.id, 'surface_m2', e.target.value)} disabled={viewMode} min="0"/></td>
                  <td className="px-3 py-2 whitespace-nowrap"><TableInput type="number" step="0.01" value={item.unit_value} onChange={(e) => handleLandChange(item.id, 'unit_value', e.target.value)} disabled={viewMode} min="0"/></td>
                  <td className="px-3 py-2 whitespace-nowrap text-right font-semibold text-slate-800 dark:text-slate-200">{(parseFloat(item.total_value) || 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN' })}</td>
                  {!viewMode && (
                    <td className="px-3 py-2 whitespace-nowrap text-right text-sm font-medium">
                      <button onClick={() => handleRemoveLandItem(item.id)} className="text-red-600 hover:text-red-900 p-1 dark:text-red-400 dark:hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={3} className="px-3 py-2 text-right text-sm font-bold text-slate-700 dark:text-slate-300">Subtotal Terreno:</td>
                <td className="px-3 py-2 text-right text-lg font-bold text-blue-600 dark:text-blue-400">
                  {subtotalLand.toLocaleString('es-MX', { style: 'currency', currency: 'MXN' })}
                </td>
                {!viewMode && <td></td>}
              </tr>
            </tfoot>
          </table>
        </div>
        {!viewMode && (
          <button onClick={handleAddLandItem} className="mt-4 flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition dark:bg-blue-800 dark:text-blue-200 dark:hover:bg-blue-700">
            <Plus className="w-4 h-4" /> Agregar Fila
          </button>
        )}
      </div>

      {/* b) CONSTRUCCIONES */}
      <div className="bg-white dark:bg-slate-800 rounded-lg p-6 shadow-sm border border-slate-200 dark:border-slate-700">
        <h4 className="text-md font-bold text-slate-900 dark:text-slate-100 mb-4">b) CONSTRUCCIONES (con base en manuales de costos)</h4>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700 text-xs">
            <thead className="bg-slate-50 dark:bg-slate-700">
              <tr>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">No.</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Concepto</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Tipo Área</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 uppercase">Mts²</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">PU Reposic.</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 uppercase">Valor Neto</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 uppercase">Deprec. %</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 uppercase">Factor</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Valor Parcial</th>
                {!viewMode && <th scope="col" className="relative px-2 py-2"><span className="sr-only">Acciones</span></th>}
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
              {constructionItems.map((item, index) => (
                <tr key={item.id}>
                  <td className="px-2 py-2 whitespace-nowrap text-slate-800 dark:text-slate-200">{index + 1}</td>
                  <td className="px-2 py-2 whitespace-nowrap">
                    <TableSelectField 
                      value={item.concept} 
                      otherValue={item.concept_other}
                      onChange={(val) => handleConstructionChange(item.id, 'concept', val)} 
                      onOtherChange={(val) => handleConstructionChange(item.id, 'concept_other', val)}
                      options={catalogoConceptoConstruccion}
                      disabled={viewMode}
                      placeholder="Seleccione concepto"
                    />
                  </td>
                  <td className="px-2 py-2 whitespace-nowrap">
                    <TableSelectField 
                      value={item.area_type} 
                      otherValue={item.area_type_other}
                      onChange={(val) => handleConstructionChange(item.id, 'area_type', val)} 
                      onOtherChange={(val) => handleConstructionChange(item.id, 'area_type_other', val)}
                      options={catalogoTipoArea}
                      disabled={viewMode}
                      placeholder="Seleccione tipo"
                    />
                  </td>
                  <td className="px-2 py-2 whitespace-nowrap"><TableInput type="number" step="0.01" min="0" value={item.m2} onChange={(e) => handleConstructionChange(item.id, 'm2', e.target.value)} disabled={viewMode} /></td>
                  <td className="px-2 py-2 whitespace-nowrap"><TableInput type="number" step="0.01" min="0" value={item.pu_reposicion} onChange={(e) => handleConstructionChange(item.id, 'pu_reposicion', e.target.value)} disabled={viewMode} /></td>
                  <td className="px-2 py-2 whitespace-nowrap text-right text-slate-800 dark:text-slate-200">{(parseFloat(item.valor_neto) || 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN' })}</td>
                  <td className="px-2 py-2 whitespace-nowrap"><TableInput type="number" step="0.01" min="0" max="100" value={(parseFloat(item.depreciation_percentage) * 100).toFixed(2)} onChange={(e) => handleConstructionChange(item.id, 'depreciation_percentage', e.target.value)} disabled={viewMode} /></td>
                  <td className="px-2 py-2 whitespace-nowrap text-right text-slate-800 dark:text-slate-200">{(parseFloat(item.factor_resultante) || 0).toFixed(2)}</td>
                  <td className="px-2 py-2 whitespace-nowrap text-right font-semibold text-slate-800 dark:text-slate-200">{(parseFloat(item.valor_parcial) || 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN' })}</td>
                  {!viewMode && (
                    <td className="px-2 py-2 whitespace-nowrap text-right text-sm font-medium">
                      <button onClick={() => handleRemoveConstructionItem(item.id)} className="text-red-600 hover:text-red-900 p-1 dark:text-red-400 dark:hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={8} className="px-2 py-2 text-right text-sm font-bold text-slate-700 dark:text-slate-300">Subtotal Construcciones:</td>
                <td className="px-2 py-2 text-right text-lg font-bold text-blue-600 dark:text-blue-400">
                  {subtotalConstructions.toLocaleString('es-MX', { style: 'currency', currency: 'MXN' })}
                </td>
                {!viewMode && <td></td>}
              </tr>
            </tfoot>
          </table>
        </div>
        {!viewMode && (
          <button onClick={handleAddConstructionItem} className="mt-4 flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition dark:bg-blue-800 dark:text-blue-200 dark:hover:bg-blue-700">
            <Plus className="w-4 h-4" /> Agregar Fila
          </button>
        )}
      </div>

      {/* c) INSTALACIONES ESPECIALIZADAS */}
      <div className="bg-white dark:bg-slate-800 rounded-lg p-6 shadow-sm border border-slate-200 dark:border-slate-700">
        <h4 className="text-md font-bold text-slate-900 dark:text-slate-100 mb-4">c) INSTALACIONES ESPECIALIZADAS</h4>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700 text-xs">
            <thead className="bg-slate-50 dark:bg-slate-700">
              <tr>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">No.</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Concepto</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">LOTE/Cant.</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">PU Reposic.</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Obs. %</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Edad %</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Factor</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Valor Neto</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Valor Parcial</th>
                {!viewMode && <th scope="col" className="relative px-2 py-2"><span className="sr-only">Acciones</span></th>}
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
              {installationItems.map((item, index) => (
                <tr key={item.id}>
                  <td className="px-2 py-2 whitespace-nowrap text-slate-800 dark:text-slate-200">{index + 1}</td>
                  <td className="px-2 py-2 whitespace-nowrap">
                    <TableSelectField 
                      value={item.concept} 
                      otherValue={item.concept_other}
                      onChange={(val) => handleInstallationChange(item.id, 'concept', val)} 
                      onOtherChange={(val) => handleInstallationChange(item.id, 'concept_other', val)}
                      options={catalogoConceptoInstalacion}
                      disabled={viewMode}
                      placeholder="Seleccione concepto"
                    />
                  </td>
                  <td className="px-2 py-2 whitespace-nowrap"><TableInput type="number" step="1" min="0" value={item.lote_or_quantity} onChange={(e) => handleInstallationChange(item.id, 'lote_or_quantity', e.target.value)} disabled={viewMode} /></td>
                  <td className="px-2 py-2 whitespace-nowrap"><TableInput type="number" step="0.01" min="0" value={item.pu_reposicion} onChange={(e) => handleInstallationChange(item.id, 'pu_reposicion', e.target.value)} disabled={viewMode} /></td>
                  <td className="px-2 py-2 whitespace-nowrap"><TableInput type="number" step="0.01" min="0" max="100" value={(parseFloat(item.factor_obsolescencia_percentage) * 100).toFixed(2)} onChange={(e) => handleInstallationChange(item.id, 'factor_obsolescencia_percentage', e.target.value)} disabled={viewMode} /></td>
                  <td className="px-2 py-2 whitespace-nowrap"><TableInput type="number" step="0.01" min="0" max="100" value={(parseFloat(item.factor_edad_conservacion_percentage) * 100).toFixed(2)} onChange={(e) => handleInstallationChange(item.id, 'factor_edad_conservacion_percentage', e.target.value)} disabled={viewMode} /></td>
                  <td className="px-2 py-2 whitespace-nowrap text-right text-slate-800 dark:text-slate-200">{(parseFloat(item.depreciation_multiplier) || 0).toFixed(2)}</td>
                  <td className="px-2 py-2 whitespace-nowrap text-right text-slate-800 dark:text-slate-200">{(parseFloat(item.valor_neto_reposicion) || 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN' })}</td>
                  <td className="px-2 py-2 whitespace-nowrap text-right font-semibold text-slate-800 dark:text-slate-200">{(parseFloat(item.valor_parcial) || 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN' })}</td>
                  {!viewMode && (
                    <td className="px-2 py-2 whitespace-nowrap text-right text-sm font-medium">
                      <button onClick={() => handleRemoveInstallationItem(item.id)} className="text-red-600 hover:text-red-900 p-1 dark:text-red-400 dark:hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={8} className="px-2 py-2 text-right text-sm font-bold text-slate-700 dark:text-slate-300">Subtotal Instalaciones:</td>
                <td className="px-2 py-2 text-right text-lg font-bold text-blue-600 dark:text-blue-400">
                  {subtotalInstallations.toLocaleString('es-MX', { style: 'currency', currency: 'MXN' })}
                </td>
                {!viewMode && <td></td>}
              </tr>
            </tfoot>
          </table>
        </div>
        {!viewMode && (
          <button onClick={handleAddInstallationItem} className="mt-4 flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition dark:bg-blue-800 dark:text-blue-200 dark:hover:bg-blue-700">
            <Plus className="w-4 h-4" /> Agregar Fila
          </button>
        )}
      </div>

      {/* d) OTROS BIENES DISTINTOS A LA TIERRA */}
      <div className="bg-white dark:bg-slate-800 rounded-lg p-6 shadow-sm border border-slate-200 dark:border-slate-700">
        <h4 className="text-md font-bold text-slate-900 dark:text-slate-100 mb-4">d) OTROS BIENES DISTINTOS A LA TIERRA</h4>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-700 text-xs">
            <thead className="bg-slate-50 dark:bg-slate-700">
              <tr>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">No.</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Concepto</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Cantidad</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">PU Reposic.</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Obs. %</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Edad %</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Factor</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Valor Neto</th>
                <th scope="col" className="px-2 py-2 text-left text-xs font-medium text-slate-500 dark:text-slate-300 uppercase">Valor Parcial</th>
                {!viewMode && <th scope="col" className="relative px-2 py-2"><span className="sr-only">Acciones</span></th>}
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-slate-800 divide-y divide-slate-200 dark:divide-slate-700">
              {otherAssetsItems.map((item, index) => (
                <tr key={item.id}>
                  <td className="px-2 py-2 whitespace-nowrap text-slate-800 dark:text-slate-200">{index + 1}</td>
                  <td className="px-2 py-2 whitespace-nowrap">
                    <TableSelectField 
                      value={item.concept} 
                      otherValue={item.concept_other}
                      onChange={(val) => handleOtherAssetChange(item.id, 'concept', val)} 
                      onOtherChange={(val) => handleOtherAssetChange(item.id, 'concept_other', val)}
                      options={catalogoOtrosBienes}
                      disabled={viewMode}
                      placeholder="Seleccione concepto"
                    />
                  </td>
                  <td className="px-2 py-2 whitespace-nowrap"><TableInput type="number" step="1" min="0" value={item.quantity} onChange={(e) => handleOtherAssetChange(item.id, 'quantity', e.target.value)} disabled={viewMode} /></td>
                  <td className="px-2 py-2 whitespace-nowrap"><TableInput type="number" step="0.01" min="0" value={item.pu_reposicion_nuevo} onChange={(e) => handleOtherAssetChange(item.id, 'pu_reposicion_nuevo', e.target.value)} disabled={viewMode} /></td>
                  <td className="px-2 py-2 whitespace-nowrap"><TableInput type="number" step="0.01" min="0" max="100" value={(parseFloat(item.factor_obsolescencia_percentage) * 100).toFixed(2)} onChange={(e) => handleOtherAssetChange(item.id, 'factor_obsolescencia_percentage', e.target.value)} disabled={viewMode} /></td>
                  <td className="px-2 py-2 whitespace-nowrap"><TableInput type="number" step="0.01" min="0" max="100" value={(parseFloat(item.factor_edad_conservacion_percentage) * 100).toFixed(2)} onChange={(e) => handleOtherAssetChange(item.id, 'factor_edad_conservacion_percentage', e.target.value)} disabled={viewMode} /></td>
                  <td className="px-2 py-2 whitespace-nowrap text-right text-slate-800 dark:text-slate-200">{(parseFloat(item.depreciation_multiplier) || 0).toFixed(2)}</td>
                  <td className="px-2 py-2 whitespace-nowrap text-right text-slate-800 dark:text-slate-200">{(parseFloat(item.valor_neto_reposicion) || 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN' })}</td>
                  <td className="px-2 py-2 whitespace-nowrap text-right font-semibold text-slate-800 dark:text-slate-200">{(parseFloat(item.valor_parcial) || 0).toLocaleString('es-MX', { style: 'currency', currency: 'MXN' })}</td>
                  {!viewMode && (
                    <td className="px-2 py-2 whitespace-nowrap text-right text-sm font-medium">
                      <button onClick={() => handleRemoveOtherAssetItem(item.id)} className="text-red-600 hover:text-red-900 p-1 dark:text-red-400 dark:hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={8} className="px-2 py-2 text-right text-sm font-bold text-slate-700 dark:text-slate-300">Subtotal Otros Bienes:</td>
                <td className="px-2 py-2 text-right text-lg font-bold text-blue-600 dark:text-blue-400">
                  {subtotalOtherAssets.toLocaleString('es-MX', { style: 'currency', currency: 'MXN' })}
                </td>
                {!viewMode && <td></td>}
              </tr>
            </tfoot>
          </table>
        </div>
        {!viewMode && (
          <button onClick={handleAddOtherAssetItem} className="mt-4 flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition dark:bg-blue-800 dark:text-blue-200 dark:hover:bg-blue-700">
            <Plus className="w-4 h-4" /> Agregar Fila
          </button>
        )}
      </div>

      {/* Final Summary */}
      <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-700 rounded-lg p-4 mt-6">
        <h4 className="flex justify-between items-center text-lg font-bold text-blue-800 dark:text-blue-200">
          <span>VALOR TOTAL POR ENFOQUE FÍSICO (a + b + c + d):</span>
          <span className="text-2xl">{totalPhysicalValue.toLocaleString('es-MX', { style: 'currency', currency: 'MXN' })}</span>
        </h4>
        <p className="text-sm text-blue-700 dark:text-blue-300 mt-2">
          <strong>Consideraciones:</strong> El valor de la tierra corresponde al obtenido mediante el método de mercado. 
          En edificación y demás instalaciones y otros elementos se consideran dentro del valor de la tierra.
        </p>
      </div>
    </div>
  );
}