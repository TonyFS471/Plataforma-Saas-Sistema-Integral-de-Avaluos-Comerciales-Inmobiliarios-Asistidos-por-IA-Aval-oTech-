import { useState } from 'react';
import { FileDown, Sparkles, Loader2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAppraisalFormContext } from './context/AppraisalFormContext';

export default function FinalReport({ viewMode }) {
  const { formData } = useAppraisalFormContext();
  const [generatingReport, setGeneratingReport] = useState(false);
  const [aiReport, setAiReport] = useState('');
  const [showAiReport, setShowAiReport] = useState(false);

  const generateAIReport = async () => {
    setGeneratingReport(true);
    try {
      // Obtener el access_token del usuario autenticado
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      if (sessionError || !session) {
        console.error('Error obteniendo sesión para generar informe:', sessionError);
        alert('No se pudo verificar tu sesión. Por favor, inicia sesión nuevamente.');
        return;
      }

      // Usar supabase.functions.invoke para manejar automáticamente la autenticación
      const { data, error } = await supabase.functions.invoke('generate-report', {
        body: { appraisalData: formData }
      });

      if (error) {
        console.error('Error al invocar generate-report:', error);
        alert('Error al generar el informe: ' + error.message);
        return;
      }

      if (data && data.report) {
        setAiReport(data.report);
        setShowAiReport(true);
      } else {
        alert('Error: No se recibió un informe válido de la IA');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error al generar el informe con IA: ' + error.message);
    } finally {
      setGeneratingReport(false);
    }
  };
  
  const downloadPDF = () => {
    // Crear el contenido HTML del informe
    const printContent = document.getElementById('informe-final-content').innerHTML;
    
    // Crear ventana nueva para impresión
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Informe de Avalúo - ${formData.appraisal_number}</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              line-height: 1.6;
              color: #333;
              max-width: 210mm;
              margin: 0 auto;
              padding: 20mm;
            }
            h1 {
              color: #1e40af;
              border-bottom: 3px solid #1e40af;
              padding-bottom: 10px;
              margin-bottom: 20px;
            }
            h2 {
              color: #1e40af;
              margin-top: 30px;
              margin-bottom: 15px;
              font-size: 18px;
            }
            h3 {
              color: #475569;
              margin-top: 20px;
              margin-bottom: 10px;
              font-size: 16px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin: 15px 0;
            }
            th, td {
              border: 1px solid #cbd5e1;
              padding: 8px 12px;
              text-align: left;
            }
            th {
              background-color: #f1f5f9;
              font-weight: bold;
            }
            .header-info {
              background-color: #eff6ff;
              padding: 15px;
              border-radius: 8px;
              margin-bottom: 20px;
            }
            .valor-final {
              background: linear-gradient(to right, #1e40af, #1e3a8a);
              color: white;
              padding: 20px;
              border-radius: 8px;
              text-align: center;
              margin: 30px 0;
            }
            .valor-final h2 {
              color: white;
              margin: 0;
              font-size: 32px;
            }
            .metodo-box {
              background-color: #f8fafc;
              border-left: 4px solid #3b82f6;
              padding: 15px;
              margin: 15px 0;
            }
            .photo-grid {
              display: grid;
              grid-template-columns: repeat(2, 1fr);
              gap: 15px;
              margin: 20px 0;
            }
            .photo-item {
              break-inside: avoid;
            }
            .photo-item img {
              max-width: 100%;
              border: 1px solid #cbd5e1;
              border-radius: 4px;
            }
            .photo-caption {
              font-size: 12px;
              color: #64748b;
              margin-top: 5px;
            }
            @media print {
              body {
                padding: 10mm;
              }
              .no-print {
                display: none;
              }
              .page-break {
                page-break-after: always;
              }
            }
          </style>
        </head>
        <body>
          ${printContent}
          <script>
            window.onload = function() {
              window.print();
              window.onafterprint = function() {
                window.close();
              };
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const formatCurrency = (value) => {
    return `$${(parseFloat(value) || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })} MXN`;
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('es-MX', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-2xl font-bold text-slate-900">Informe Final del Avalúo</h3>
        <div className="flex gap-3">
          <button
            onClick={generateAIReport}
            disabled={generatingReport}
            className="flex items-center gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-6 py-3 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {generatingReport ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Generando...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                Generar Informe con IA
              </>
            )}
          </button>
          <button
            onClick={downloadPDF}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition"
          >
            <FileDown className="w-5 h-5" />
            Descargar PDF
          </button>
        </div>
      </div>

      {/* Informe Generado con IA */}
      {showAiReport && aiReport && (
        <div className="bg-gradient-to-br from-purple-50 to-blue-50 border-2 border-purple-200 rounded-lg p-8 mb-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900">Informe Generado con Inteligencia Artificial</h3>
              <p className="text-sm text-slate-600">Análisis profesional completo del avalúo</p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <div className="prose max-w-none text-slate-700 whitespace-pre-line leading-relaxed">
              {aiReport}
            </div>
          </div>

          <div className="flex justify-end mt-6 gap-3">
            <button
              onClick={() => setShowAiReport(false)}
              className="px-6 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition"
            >
              Ocultar
            </button>
            <button
              onClick={() => {
                navigator.clipboard.writeText(aiReport);
                alert('Informe copiado al portapapeles');
              }}
              className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition"
            >
              Copiar Texto
            </button>
          </div>
        </div>
      )}

      {/* Contenido del informe */}
      <div id="informe-final-content" className="bg-white border border-slate-200 rounded-lg p-8">
        
        {/* Encabezado */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-blue-900 mb-2">INFORME DE AVALÚO</h1>
          <p className="text-lg text-slate-600">{formData.appraisal_number}</p>
          <p className="text-sm text-slate-500">Fecha: {formatDate(formData.appraisal_date)}</p>
        </div>

        {/* I. DATOS DEL INMUEBLE */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-900 pb-2 mb-4">
            I. IDENTIFICACIÓN DEL INMUEBLE
          </h2>
          <div className="header-info bg-blue-50 p-4 rounded-lg">
            <table>
              <tbody>
                <tr>
                  <th width="30%">Dirección:</th>
                  <td>{formData.property_address}</td>
                </tr>
                <tr>
                  <th>Colonia:</th>
                  <td>{formData.property_colony}</td>
                </tr>
                <tr>
                  <th>Municipio/Alcaldía:</th>
                  <td>{formData.property_municipality}</td>
                </tr>
                <tr>
                  <th>Estado:</th>
                  <td>{formData.property_state}</td>
                </tr>
                <tr>
                  <th>C.P.:</th>
                  <td>{formData.property_zip}</td>
                </tr>
                <tr>
                  <th>Tipo de Propiedad:</th>
                  <td>{formData.property_type?.replace(/_/g, ' ').toUpperCase()}</td>
                </tr>
                <tr>
                  <th>Solicitante:</th>
                  <td>{formData.client_name}</td>
                </tr>
                <tr>
                  <th>RFC:</th>
                  <td>{formData.client_rfc}</td>
                </tr>
                <tr>
                  <th>Propósito:</th>
                  <td>{formData.purpose?.replace(/_/g, ' ').toUpperCase()}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* II. DESCRIPCIÓN DEL TERRENO */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-900 pb-2 mb-4">
            II. DESCRIPCIÓN DEL TERRENO
          </h2>
          <table>
            <tbody>
              <tr>
                <th width="30%">Superficie:</th>
                <td>{formData.land_area} m²</td>
              </tr>
              <tr>
                <th>Tipo de Terreno:</th>
                <td>{formData.land_shape}</td>
              </tr>
              <tr>
                <th>Forma:</th>
                <td>{formData.land_shape}</td>
              </tr>
              <tr>
                <th>Topografía:</th>
                <td>{formData.land_topography}</td>
              </tr>
              <tr>
                <th>Frente:</th>
                <td>{formData.front_meters} m</td>
              </tr>
              <tr>
                <th>Fondo:</th>
                <td>{formData.depth_meters} m</td>
              </tr>
              <tr>
                <th>Tipo de Suelo:</th>
                <td>{formData.soil_type}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* III. DESCRIPCIÓN DE LA CONSTRUCCIÓN */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-900 pb-2 mb-4">
            III. DESCRIPCIÓN DE LA CONSTRUCCIÓN
          </h2>
          <table>
            <tbody>
              <tr>
                <th width="30%">Superficie Construida:</th>
                <td>{formData.construction_area} m²</td>
              </tr>
              <tr>
                <th>Tipo de Construcción:</th>
                <td>{formData.construction_type?.replace(/_/g, ' ').toUpperCase()}</td>
              </tr>
              <tr>
                <th>Niveles:</th>
                <td>{formData.number_of_levels}</td>
              </tr>
              <tr>
                <th>Antigüedad:</th>
                <td>{formData.construction_age} años</td>
              </tr>
              <tr>
                <th>Estado de Conservación:</th>
                <td>{formData.conservation_state?.toUpperCase()}</td>
              </tr>
              <tr>
                <th>Recámaras:</th>
                <td>{formData.bedrooms}</td>
              </tr>
              <tr>
                <th>Baños:</th>
                <td>{formData.bathrooms}</td>
              </tr>
              <tr>
                <th>Estacionamientos:</th>
                <td>{formData.parking_spaces}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* IV. ELEMENTOS CONSTRUCTIVOS */}
        <div className="mb-8 page-break">
          <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-900 pb-2 mb-4">
            IV. ELEMENTOS CONSTRUCTIVOS
          </h2>
          
          <h3 className="font-bold text-slate-800 mt-4">Obra Negra:</h3>
          <table>
            <tbody>
              <tr><th width="30%">Cimentación:</th><td>{formData.cimentacion} {formData.cimentacion_otro}</td></tr>
              <tr><th>Estructura:</th><td>{formData.estructura} {formData.estructura_otro}</td></tr>
              <tr><th>Muros:</th><td>{formData.muros} {formData.muros_otro}</td></tr>
              <tr><th>Entrepisos:</th><td>{formData.entrepisos} {formData.entrepisos_otro}</td></tr>
              <tr><th>Techos:</th><td>{formData.techos} {formData.techos_otro}</td></tr>
              <tr><th>Azoteas:</th><td>{formData.azoteas} {formData.azoteas_otro}</td></tr>
              <tr><th>Bardas/Cercas:</th><td>{formData.bardas_cercas} {formData.bardas_cercas_otro}</td></tr>
            </tbody>
          </table>

          <h3 className="font-bold text-slate-800 mt-4">Revestimientos y Acabados:</h3>
          <table>
            <tbody>
              <tr><th width="30%">Aplanados:</th><td>{formData.aplanados} {formData.aplanados_otro}</td></tr>
              <tr><th>Plafones:</th><td>{formData.plafones} {formData.plafones_otro}</td></tr>
              <tr><th>Lambrines:</th><td>{formData.lambrines} {formData.lambrines_otro}</td></tr>
              <tr><th>Pisos:</th><td>{formData.pisos} {formData.pisos_otro}</td></tr>
              <tr><th>Pintura:</th><td>{formData.pintura} {formData.pintura_otro}</td></tr>
            </tbody>
          </table>

          <h3 className="font-bold text-slate-800 mt-4">Carpintería:</h3>
          <table>
            <tbody>
              <tr><th width="30%">Puertas:</th><td>{formData.puertas} {formData.puertas_otro}</td></tr>
              <tr><th>Ventanas:</th><td>{formData.ventanas} {formData.ventanas_otro}</td></tr>
              <tr><th>Guardamoyas:</th><td>{formData.guardamoyas} {formData.guardamoyas_otro}</td></tr>
            </tbody>
          </table>
        </div>

        {/* V. INSTALACIONES */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-900 pb-2 mb-4">
            V. INSTALACIONES
          </h2>
          
          <h3 className="font-bold text-slate-800 mt-4">Instalación Hidráulica:</h3>
          <table>
            <tbody>
              <tr><th width="30%">Tubería/Equipo:</th><td>{formData.tuberia_equipo} {formData.tuberia_equipo_otro}</td></tr>
              <tr><th>Muebles Sanitarios:</th><td>{formData.muebles_sanitarios} {formData.muebles_sanitarios_otro}</td></tr>
              <tr><th>Muebles de Cocina:</th><td>{formData.muebles_cocina} {formData.muebles_cocina_otro}</td></tr>
            </tbody>
          </table>

          <h3 className="font-bold text-slate-800 mt-4">Instalación Sanitaria:</h3>
          <table>
            <tbody>
              <tr><th width="30%">Tubería:</th><td>{formData.sanitaria_tuberia} {formData.sanitaria_tuberia_otro}</td></tr>
              <tr><th>Registro:</th><td>{formData.sanitaria_registro} {formData.sanitaria_registro_otro}</td></tr>
            </tbody>
          </table>

          <h3 className="font-bold text-slate-800 mt-4">Instalación Eléctrica:</h3>
          <table>
            <tbody>
              <tr><th width="30%">Tipo:</th><td>{formData.instalaciones_electricas} {formData.instalaciones_electricas_otro}</td></tr>
              <tr><th>Estado:</th><td>{formData.electrica_estado?.toUpperCase()}</td></tr>
            </tbody>
          </table>

          <h3 className="font-bold text-slate-800 mt-4">Instalaciones Especiales:</h3>
          <table>
            <tbody>
              <tr><th width="30%">Gas:</th><td>{formData.gas_tipo} {formData.gas_tipo_otro}</td></tr>
              <tr><th>Ventanería Metálica:</th><td>{formData.puertas_ventaneria_metalica} {formData.puertas_ventaneria_metalica_otro}</td></tr>
              <tr><th>Vidrería:</th><td>{formData.vidrieria} {formData.vidrieria_otro}</td></tr>
              <tr><th>Especiales:</th><td>{formData.instalaciones_especiales} {formData.instalaciones_especiales_otro}</td></tr>
              <tr><th>Obras Complementarias:</th><td>{formData.obras_complementarias} {formData.obras_complementarias_otro}</td></tr>
            </tbody>
          </table>
        </div>

        {/* VI. MÉTODOS DE VALUACIÓN */}
        <div className="mb-8 page-break">
          <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-900 pb-2 mb-4">
            VI. MÉTODOS DE VALUACIÓN
          </h2>

          <div className="metodo-box">
            <h3 className="font-bold text-slate-800">A) Método Físico Directo</h3>
            <table className="mt-3">
              <tbody>
                <tr>
                  <th width="50%">Valor del Terreno ({formData.land_area} m²):</th>
                  <td className="text-right">{formatCurrency(formData.land_value_total)}</td>
                </tr>
                <tr>
                  <th>Valor de la Construcción ({formData.construction_area} m²):</th>
                  <td className="text-right">{formatCurrency(formData.construction_value_total)}</td>
                </tr>
                <tr>
                  <th>Depreciación ({formData.depreciation_percentage}%):</th>
                  <td className="text-right text-red-600">
                    -{formatCurrency((formData.construction_value_total || 0) * (parseFloat(formData.depreciation_percentage) / 100))}
                  </td>
                </tr>
                <tr className="font-bold bg-blue-50">
                  <th>VALOR POR MÉTODO FÍSICO DIRECTO:</th>
                  <td className="text-right text-blue-700 text-lg">{formatCurrency(formData.physical_total_value)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {formData.pre_real_value && (
            <div className="metodo-box mt-6">
              <h3 className="font-bold text-slate-800">B) Método PRE-REAL</h3>
              <table className="mt-3">
                <tbody>
                  <tr className="font-bold bg-green-50">
                    <th width="50%">VALOR POR MÉTODO PRE-REAL:</th>
                    <td className="text-right text-green-700 text-lg">{formatCurrency(formData.pre_real_value)}</td>
                  </tr>
                </tbody>
              </table>
              {formData.pre_real_observations && (
                <p className="text-sm text-slate-600 mt-2"><strong>Observaciones:</strong> {formData.pre_real_observations}</p>
              )}
            </div>
          )}

          <div className="metodo-box mt-6">
            <h3 className="font-bold text-slate-800">C) Método de Capitalización de Rentas</h3>
            <table className="mt-3">
              <tbody>
                <tr>
                  <th width="50%">Renta Mensual:</th>
                  <td className="text-right">{formatCurrency(formData.monthly_rent)}</td>
                </tr>
                <tr>
                  <th>Renta Anual:</th>
                  <td className="text-right">{formatCurrency(formData.annual_rent)}</td>
                </tr>
                <tr>
                  <th>Tasa de Capitalización:</th>
                  <td className="text-right">{formData.capitalization_rate}%</td>
                </tr>
                <tr className="font-bold bg-green-50">
                  <th>VALOR POR CAPITALIZACIÓN:</th>
                  <td className="text-right text-green-700 text-lg">{formatCurrency(formData.capitalization_value)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="metodo-box mt-6">
            <h3 className="font-bold text-slate-800">D) Método de Homologación (Comparación de Mercado)</h3>
            <table className="mt-3">
              <tbody>
                {formData.comparable_1_price && (
                  <>
                    <tr>
                      <th width="50%">Comparable 1:</th>
                      <td className="text-right">{formatCurrency(formData.comparable_1_price)}</td>
                    </tr>
                    {formData.comparable_1_address && (
                      <tr>
                        <td colSpan="2" className="text-xs text-slate-500">{formData.comparable_1_address}</td>
                      </tr>
                    )}
                  </>
                )}
                {formData.comparable_2_price && (
                  <>
                    <tr>
                      <th width="50%">Comparable 2:</th>
                      <td className="text-right">{formatCurrency(formData.comparable_2_price)}</td>
                    </tr>
                    {formData.comparable_2_address && (
                      <tr>
                        <td colSpan="2" className="text-xs text-slate-500">{formData.comparable_2_address}</td>
                      </tr>
                    )}
                  </>
                )}
                {formData.comparable_3_price && (
                  <>
                    <tr>
                      <th width="50%">Comparable 3:</th>
                      <td className="text-right">{formatCurrency(formData.comparable_3_price)}</td>
                    </tr>
                    {formData.comparable_3_address && (
                      <tr>
                        <td colSpan="2" className="text-xs text-slate-500">{formData.comparable_3_address}</td>
                      </tr>
                    )}
                  </>
                )}
                <tr className="font-bold bg-purple-50">
                  <th>VALOR POR HOMOLOGACIÓN:</th>
                  <td className="text-right text-purple-700 text-lg">{formatCurrency(formData.homologation_average)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* VII. REPORTE FOTOGRÁFICO */}
        {formData.photos && formData.photos.length > 0 && (
          <div className="mb-8 page-break">
            <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-900 pb-2 mb-4">
              VII. REPORTE FOTOGRÁFICO
            </h2>
            <div className="photo-grid">
              {formData.photos.map((photo, index) => (
                <div key={index} className="photo-item">
                  <img src={photo.url} alt={`Foto ${index + 1}`} />
                  <div className="photo-caption">
                    <p><strong>Categoría:</strong> {photo.category}</p>
                    {photo.ai_analysis?.estado_conservacion && (
                      <p><strong>Estado:</strong> {photo.ai_analysis.estado_conservacion}</p>
                    )}
                    {photo.notes && <p><strong>Notas:</strong> {photo.notes}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VIII. CONCLUSIÓN */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-900 pb-2 mb-4">
            VIII. CONCLUSIÓN DEL AVALÚO
          </h2>
          
          <div className="metodo-box">
            <h3 className="font-bold text-slate-800 mb-3">Resumen de Métodos:</h3>
            <table>
              <thead>
                <tr>
                  <th>Método</th>
                  <th className="text-right">Valor</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Físico Directo</td>
                  <td className="text-right">{formatCurrency(formData.physical_total_value)}</td>
                </tr>
                {formData.pre_real_value && (
                  <tr>
                    <td>PRE-REAL</td>
                    <td className="text-right">{formatCurrency(formData.pre_real_value)}</td>
                  </tr>
                )}
                <tr>
                  <td>Capitalización de Rentas</td>
                  <td className="text-right">{formatCurrency(formData.capitalization_value)}</td>
                </tr>
                <tr>
                  <td>Homologación</td>
                  <td className="text-right">{formatCurrency(formData.homologation_average)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <p className="mt-4 text-slate-700">
            <strong>Método Utilizado para Valor Final:</strong> {formData.final_method?.replace(/_/g, ' ').toUpperCase()}
          </p>

          <div className="valor-final">
            <p className="text-sm font-semibold mb-2">VALOR COMERCIAL FINAL DEL INMUEBLE</p>
            <h2>{formatCurrency(formData.final_value)}</h2>
            <p className="text-xs mt-2 opacity-90">
              {formData.final_value ? 
                `(${new Intl.NumberFormat('es-MX').format(parseFloat(formData.final_value))} PESOS ${(parseFloat(formData.final_value) % 1 * 100).toFixed(0).padStart(2, '0')}/100 M.N.)` 
                : ''
              }
            </p>
          </div>

          <div className="mt-6">
            <h3 className="font-bold text-slate-800 mb-2">Observaciones y Recomendaciones:</h3>
            <p className="text-slate-700 text-justify">{formData.observations}</p>
          </div>
        </div>

        {/* IX. DATOS DEL VALUADOR */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-blue-900 border-b-2 border-blue-900 pb-2 mb-4">
            IX. DATOS DEL VALUADOR
          </h2>
          <table>
            <tbody>
              <tr>
                <th width="30%">Nombre:</th>
                <td>{formData.valuator_name}</td>
              </tr>
              <tr>
                <th>Cédula Profesional:</th>
                <td>{formData.valuator_license}</td>
              </tr>
              <tr>
                <th>Correo Electrónico:</th>
                <td>{formData.valuator_email}</td>
              </tr>
              <tr>
                <th>Teléfono:</th>
                <td>{formData.valuator_phone}</td>
              </tr>
            </tbody>
          </table>
          
          <div className="mt-12 pt-6 border-t-2 border-slate-300 text-center">
            <p className="mb-8">_________________________________</p>
            <p className="font-bold">{formData.valuator_name}</p>
            <p className="text-sm text-slate-600">Valuador Profesional</p>
            <p className="text-sm text-slate-600">Cédula: {formData.valuator_license}</p>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-xs text-slate-500 mt-8 pt-4 border-t">
          <p>Este avalúo fue elaborado el {formatDate(formData.appraisal_date)}</p>
          <p>Documento generado por Sistema de Avalúos Profesionales</p>
        </div>
      </div>
    </div>
  );
}
