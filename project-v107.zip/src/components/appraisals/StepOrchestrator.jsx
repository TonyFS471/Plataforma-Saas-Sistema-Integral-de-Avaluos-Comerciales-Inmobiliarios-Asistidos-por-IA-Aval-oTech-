import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Save, FileText, ArrowLeft, ArrowRight } from 'lucide-react';

// Contexto
import { AppraisalFormProvider, useAppraisalFormContext } from './context/AppraisalFormContext';

// Componentes de pasos autónomos
import GeneralData from './GeneralData'; // Paso 1
import LocationData from './LocationData'; // Paso 2
import TerrainDescription from './TerrainDescription'; // Paso 3
import ConstructionDescription from './ConstructionDescription'; // Paso 4
import ConstructionElements from './ConstructionElements'; // Paso 5
import Installations from './Installations'; // Paso 6
import ConservationState from './ConservationState'; // Paso 7
import UrbanFactors from './UrbanFactors'; // Paso 8
import PhotoReport from './PhotoReport'; // Paso 9
import PhysicalMethod from './PhysicalMethod'; // Paso 10
import PreRealMethod from './PreRealMethod'; // Paso 11
import CapitalizationMethod from './CapitalizationMethod'; // Paso 12
import HomologationMethod from './HomologationMethod'; // Paso 13
import FinalReport from './FinalReport'; // Paso 14

// Componente interno que usa el contexto
const StepOrchestratorContent = ({ onClose }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const { formData, updateField, loading: contextLoading } = useAppraisalFormContext();

  const steps = [
    { num: 1, title: 'Datos Generales', component: 'general' },
    { num: 2, title: 'Ubicación', component: 'location' },
    { num: 3, title: 'Descripción del Terreno', component: 'land' },
    { num: 4, title: 'Descripción Construcción', component: 'construction' },
    { num: 5, title: 'Elementos Constructivos', component: 'elements' },
    { num: 6, title: 'Instalaciones', component: 'installations' },
    { num: 7, title: 'Estado de Conservación', component: 'conservation' },
    { num: 8, title: 'Factores Urbanísticos', component: 'urban' },
    { num: 9, title: 'Reporte Fotográfico', component: 'photo_report' }, // NUEVO PASO
    { num: 10, title: 'Físico Directo', component: 'physical' },
    { num: 11, title: 'PRE-REAL', component: 'prereal' },
    { num: 12, title: 'Capitalización', component: 'capitalization' },
    { num: 13, title: 'Homologación', component: 'homologation' },
    { num: 14, title: 'Informe Final', component: 'final' } // Ahora es el paso 14
  ];

  // Handlers para totales de métodos
  const handlePhysicalMethodTotal = async (total) => {
    updateField('physical_total_value', total);
  };

  const handlePreRealTotal = async (total, observations) => {
    updateField('pre_real_value', total);
    if (observations !== undefined) {
      updateField('pre_real_observations', observations);
    }
  };

  const renderStepContent = () => {
    const step = steps[currentStep - 1];
    const viewMode = false;

    // Mostrar spinner si el contexto está cargando
    if (contextLoading || !formData.id) {
      return (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      );
    }

    switch (step.component) {
      case 'general':
        return <GeneralData viewMode={viewMode} />;
      
      case 'location':
        return <LocationData viewMode={viewMode} />;
      
      case 'land':
        return <TerrainDescription viewMode={viewMode} />;
      
      case 'construction':
        return <ConstructionDescription viewMode={viewMode} />;
      
      case 'elements':
        return <ConstructionElements viewMode={viewMode} />;
      
      case 'installations':
        return <Installations viewMode={viewMode} />;
      
      case 'conservation':
        return <ConservationState viewMode={viewMode} />;
      
      case 'urban':
        return <UrbanFactors viewMode={viewMode} />;
      
      case 'photo_report':
        return <PhotoReport viewMode={viewMode} />;
      
      case 'physical':
        return (
          <PhysicalMethod 
            appraisalId={formData.id} 
            onPhysicalMethodTotalChange={handlePhysicalMethodTotal}
          />
        );
      
      case 'prereal':
        return (
          <PreRealMethod 
            appraisalId={formData.id} 
            onPreRealChange={handlePreRealTotal}
          />
        );
      
      case 'capitalization':
        return <CapitalizationMethod viewMode={viewMode} />;
      
      case 'homologation':
        return <HomologationMethod viewMode={viewMode} />;
      
      case 'final':
        return (
          <FinalReport 
            viewMode={viewMode}
          />
        );
      
      default:
        return (
          <div className="bg-white rounded-lg p-6">
            <h3 className="text-xl font-bold text-gray-800 mb-4">{step.title}</h3>
            <p className="text-gray-600">Este paso se está desarrollando...</p>
          </div>
        );
    }
  };

  if (contextLoading || !formData.appraisal_number) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">Editor de Avalúo</h2>
            <p className="text-gray-600">Avalúo #{formData.appraisal_number}</p>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
          >
            <ArrowLeft className="w-5 h-5 inline mr-2" />
            Volver
          </button>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
          <div 
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${(currentStep / steps.length) * 100}%` }}
          />
        </div>

        {/* Steps Navigation */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          {steps.map((step) => (
            <button
              key={step.num}
              onClick={() => setCurrentStep(step.num)}
              className={`px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
                currentStep === step.num
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {step.num}. {step.title}
            </button>
          ))}
        </div>
      </div>

      {/* Step Content */}
      <div className="mb-6">
        {renderStepContent()}
      </div>

      {/* Navigation Buttons */}
      <div className="bg-white rounded-lg shadow-md p-6 flex justify-between">
        <button
          onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
          disabled={currentStep === 1}
          className="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <ArrowLeft className="w-5 h-5 inline mr-2" />
          Anterior
        </button>

        <div className="text-gray-600 flex items-center">
          Paso {currentStep} de {steps.length}
        </div>

        <button
          onClick={() => setCurrentStep(Math.min(steps.length, currentStep + 1))}
          disabled={currentStep === steps.length}
          className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Siguiente
          <ArrowRight className="w-5 h-5 inline ml-2" />
        </button>
      </div>
    </div>
  );
};

// Componente principal completamente refactorizado con patrón Create/Edit
const StepOrchestrator = ({ appraisalIdToLoad = null, propertyIdToCreateOrFindDraft = null, onClose, user }) => {
  const [appraisalId, setAppraisalId] = useState(null);
  const [loadingId, setLoadingId] = useState(true);
  const [error, setError] = useState(null);

  // Lógica de inicialización: Modo Edit (cargar) vs Modo Create (buscar draft o crear)
  useEffect(() => {
    const initAppraisal = async () => {
      setLoadingId(true);
      setError(null);

      let currentAppraisalId = null;

      try {
        // MODO 1: Editar/Ver avalúo existente (tiene prioridad)
        if (appraisalIdToLoad) {
          console.log('[StepOrchestrator] Modo EDITAR: Cargando avalúo ID:', appraisalIdToLoad);
          currentAppraisalId = appraisalIdToLoad;
        } 
        // MODO 2: Crear nuevo avalúo o buscar draft para una propiedad
        else if (propertyIdToCreateOrFindDraft) {
          console.log('[StepOrchestrator] Modo CREAR: Buscando draft para propiedad:', propertyIdToCreateOrFindDraft);
          
          // Buscar TODOS los drafts existentes para esta propiedad (para detectar duplicados)
          const { data: allDrafts, error: fetchError } = await supabase
            .from('appraisals')
            .select('id, created_at')
            .eq('property_id', propertyIdToCreateOrFindDraft)
            .eq('status', 'draft')
            .order('created_at', { ascending: false });

          if (fetchError) {
            console.error('[StepOrchestrator] ❌ Error al buscar drafts - DETALLE COMPLETO:', JSON.stringify(fetchError, null, 2));
            throw new Error(`Error al buscar drafts: ${fetchError.message} (Código: ${fetchError.code})`);
          }

          console.log('[StepOrchestrator] 📋 Drafts encontrados:', allDrafts ? allDrafts.length : 0);

          let existingDraft = null;

          // Si hay múltiples drafts, eliminar los más antiguos y quedarse con el más reciente
          if (allDrafts && allDrafts.length > 1) {
            console.warn('[StepOrchestrator] ⚠️ MÚLTIPLES DRAFTS ENCONTRADOS:', allDrafts.length);
            console.log('[StepOrchestrator] 🧹 Limpiando drafts duplicados...');
            
            existingDraft = allDrafts[0]; // El más reciente (por el order)
            const draftsToDelete = allDrafts.slice(1).map(d => d.id);

            // Eliminar drafts antiguos en paralelo
            const { error: deleteError } = await supabase
              .from('appraisals')
              .delete()
              .in('id', draftsToDelete);

            if (deleteError) {
              console.error('[StepOrchestrator] ⚠️ Error al eliminar drafts antiguos:', deleteError);
            } else {
              console.log('[StepOrchestrator] ✅ Drafts antiguos eliminados:', draftsToDelete.length);
            }
          } else if (allDrafts && allDrafts.length === 1) {
            existingDraft = allDrafts[0];
          }

          if (existingDraft) {
            console.log('[StepOrchestrator] Draft encontrado:', existingDraft.id);
            currentAppraisalId = existingDraft.id;
          } else {
            console.log('[StepOrchestrator] No hay draft. Creando nuevo avalúo...');
            
            // ✅ VALIDAR que la propiedad existe en la base de datos ANTES de intentar el INSERT
            console.log('[StepOrchestrator] 🔍 Verificando existencia de property_id:', propertyIdToCreateOrFindDraft);
            
            const { data: propertyExists, error: propertyCheckError } = await supabase
              .from('properties')
              .select('id, address')
              .eq('id', propertyIdToCreateOrFindDraft)
              .maybeSingle();

            if (propertyCheckError) {
              console.error('[StepOrchestrator] ❌ Error al verificar propiedad:', propertyCheckError);
              throw new Error(`Error al verificar la propiedad: ${propertyCheckError.message}`);
            }

            if (!propertyExists) {
              console.error('[StepOrchestrator] ❌ La propiedad NO EXISTE en la base de datos');
              throw new Error(`La propiedad con ID ${propertyIdToCreateOrFindDraft} no existe en la base de datos. Por favor, actualiza la lista de propiedades.`);
            }

            console.log('[StepOrchestrator] ✅ Propiedad válida encontrada:', propertyExists.address);
            
            // Crear nuevo avalúo con valores por defecto y datos del usuario
            const newAppraisalData = {
              property_id: propertyIdToCreateOrFindDraft,
              status: 'draft',
              appraisal_number: `AV-${new Date().getFullYear()}${(new Date().getMonth() + 1).toString().padStart(2, '0')}${(new Date().getDate()).toString().padStart(2, '0')}-${Date.now().toString().slice(-4)}`,
              request_date: new Date().toISOString().split('T')[0],
              appraisal_date: new Date().toISOString().split('T')[0],
              // Datos del valuador desde el usuario logueado
              valuator_id: user?.id || null,
              valuator_name: user?.full_name || user?.name || 'Valuador por definir',
              valuator_license: user?.license_number || 'PENDIENTE',
              valuator_email: user?.email || 'pendiente@avaluotech.com',
              valuator_phone: user?.phone || '555-555-5555',
              // Datos de cliente (serán rellenados en pasos 1 y 2)
              client_name: 'Cliente por definir',
              purpose: 'Por definir',
              // Campos obligatorios de propiedad
              property_type: 'casa_media',
              property_address: 'Por definir',
              property_colony: 'Por definir',
              property_municipality: 'Por definir',
              property_state: 'Por definir',
              property_zip: '00000',
              land_area: 0.00,
              construction_area: 0.00,
              // Campos de zona urbana
              urban_zone_type: 'Mixta',
              street_type: 'Pavimentada',
              public_transport: 'No',
              water_service: 'No',
              drainage_service: 'No',
              electricity_service: 'No',
              street_lighting: 'No',
              // Campos de terreno
              land_shape: 'Regular',
              land_topography: 'Plana',
              front_meters: 0.00,
              depth_meters: 0.00,
              soil_type: 'Arcilloso',
              // Campos de construcción
              construction_type: 'Losa',
              construction_age: 0,
              conservation_state: 'bueno',
              number_of_levels: '1',
              bedrooms: 0,
              bathrooms: 0.0,
              parking_spaces: 0,
              // Instalaciones - EXPLÍCITAMENTE DEFINIDAS
              water_installation: 'No',
              drainage_installation: 'No',
              electricity_installation: 'No',
              gas_tipo: 'No',  // ✅ CRÍTICO: Usar gas_tipo, NO gas_installation
              // Factores de mercado
              market_demand: 'Regular',
              area_growth: 'Estable',
              // Valores finales
              physical_total_value: 0,
              pre_real_value: 0,
              final_method: 'Sin Definir',
              final_value: 0.00,
              observations: 'Avalúo en proceso de elaboración'
            };

            console.log('[StepOrchestrator] 📝 Datos del nuevo avalúo:', JSON.stringify(newAppraisalData, null, 2));

            const { data: newAppraisal, error: createError } = await supabase
              .from('appraisals')
              .insert(newAppraisalData)
              .select('id')
              .single();

            if (createError) {
              console.error('[StepOrchestrator] ❌ Error al crear avalúo - DETALLE COMPLETO:', JSON.stringify(createError, null, 2));
              console.error('[StepOrchestrator] ❌ Código de error:', createError.code);
              console.error('[StepOrchestrator] ❌ Mensaje:', createError.message);
              console.error('[StepOrchestrator] ❌ Detalles:', createError.details);
              console.error('[StepOrchestrator] ❌ Hint:', createError.hint);
              
              // Error específico para violación de clave foránea (código 23503)
              if (createError.code === '23503') {
                throw new Error(`❌ VIOLACIÓN DE CLAVE FORÁNEA: La propiedad seleccionada no existe en la base de datos. Refresca la lista de propiedades.`);
              }
              
              throw new Error(`Error al crear el avalúo: ${createError.message}. Código: ${createError.code}`);
            }
            
            console.log('[StepOrchestrator] Nuevo avalúo creado:', newAppraisal.id);
            currentAppraisalId = newAppraisal.id;
          }
        } 
        // MODO 3: Error - No se proporcionó ningún ID
        else {
          throw new Error('No se proporcionó un ID de avalúo para editar ni un ID de propiedad para crear uno nuevo.');
        }
      } catch (err) {
        console.error('[StepOrchestrator] ❌ Error fatal en inicialización - DETALLE COMPLETO:', JSON.stringify(err, null, 2));
        console.error('[StepOrchestrator] ❌ Mensaje:', err.message);
        console.error('[StepOrchestrator] ❌ Código:', err.code);
        console.error('[StepOrchestrator] ❌ Stack:', err.stack);
        
        // Crear mensaje de error descriptivo para el usuario
        let errorMessageForUI = 'Error desconocido al cargar o crear avalúo.';
        if (err && typeof err === 'object') {
          if (err.message) {
            errorMessageForUI = err.message;
          } else if (err.code) {
            errorMessageForUI = `Error de Base de Datos (${err.code}): ${err.details || err.message || 'Sin detalles adicionales'}`;
          } else {
            errorMessageForUI = `Error inesperado: ${JSON.stringify(err)}`;
          }
        } else if (typeof err === 'string') {
          errorMessageForUI = err;
        }
        
        setError(errorMessageForUI);
      }

      setAppraisalId(currentAppraisalId);
      setLoadingId(false);
    };

    // Solo ejecutar si no tenemos un appraisalId ya seteado
    if (!appraisalId || (appraisalIdToLoad && appraisalIdToLoad !== appraisalId)) {
      initAppraisal();
    }
  }, [appraisalIdToLoad, propertyIdToCreateOrFindDraft, user, appraisalId]);

  // Mostrar spinner mientras carga
  if (loadingId) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[500px]">
        <div className="animate-spin rounded-full h-16 w-16 border-4 border-indigo-600 border-t-transparent"></div>
        <p className="ml-4 text-slate-700 text-lg mt-4">Preparando avalúo...</p>
      </div>
    );
  }

  // Mostrar error si falla
  if (error || !appraisalId) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[500px] px-4">
        <div className="bg-red-50 border-2 border-red-200 rounded-xl p-8 max-w-md text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-4xl">⚠️</span>
          </div>
          <h3 className="text-xl font-bold text-red-800 mb-3">Error al cargar avalúo</h3>
          <p className="text-red-600 mb-6">{error || 'No se pudo obtener un ID de avalúo válido'}</p>
          <button 
            onClick={onClose}
            className="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 font-semibold transition-colors"
          >
            Volver a Avalúos
          </button>
        </div>
      </div>
    );
  }

  return (
    <AppraisalFormProvider appraisalId={appraisalId}>
      <StepOrchestratorContent onClose={onClose} />
    </AppraisalFormProvider>
  );
};

export default StepOrchestrator;
