import React from 'react';
import { useAppraisalFormContext } from './context/AppraisalFormContext';
import SelectField from '../common/SelectField';

export default function ConstructionDescription({ viewMode }) {
  const { formData, updateField } = useAppraisalFormContext();

  const constructionTypes = ['Losa', 'Vigueta y bovedilla', 'Lámina', 'Teja', 'Concreto'];
  const conservationStates = ['Excelente', 'Bueno', 'Regular', 'Malo', 'Ruinoso'];
  const levelOptions = ['1', '2', '3', '4', '5+'];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-slate-900 mb-4">Descripción de la Construcción</h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Tipo de Construcción */}
        <SelectField
          label="Tipo de Construcción"
          value={formData.construction_type || ''}
          onChange={(value) => updateField('construction_type', value)}
          options={constructionTypes}
          viewMode={viewMode}
        />

        {/* Estado de Conservación */}
        <SelectField
          label="Estado de Conservación"
          value={formData.conservation_state || ''}
          onChange={(value) => updateField('conservation_state', value)}
          options={conservationStates}
          viewMode={viewMode}
        />

        {/* Número de Niveles */}
        <SelectField
          label="Número de Niveles"
          value={formData.number_of_levels || ''}
          onChange={(value) => updateField('number_of_levels', value)}
          options={levelOptions}
          viewMode={viewMode}
        />

        {/* Antigüedad (años) */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Antigüedad (años)
          </label>
          {viewMode ? (
            <p className="text-gray-900">{formData.construction_age || 0} años</p>
          ) : (
            <input
              type="number"
              value={formData.construction_age || 0}
              onChange={(e) => updateField('construction_age', parseInt(e.target.value) || 0)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              min="0"
            />
          )}
        </div>

        {/* Superficie de Construcción */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Superficie de Construcción (m²)
          </label>
          {viewMode ? (
            <p className="text-gray-900">{formData.construction_area || 0} m²</p>
          ) : (
            <input
              type="number"
              value={formData.construction_area || 0}
              onChange={(e) => updateField('construction_area', parseFloat(e.target.value) || 0)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              min="0"
              step="0.01"
            />
          )}
        </div>

        {/* Recámaras */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Recámaras
          </label>
          {viewMode ? (
            <p className="text-gray-900">{formData.bedrooms || 0}</p>
          ) : (
            <input
              type="number"
              value={formData.bedrooms || 0}
              onChange={(e) => updateField('bedrooms', parseInt(e.target.value) || 0)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              min="0"
            />
          )}
        </div>

        {/* Baños */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Baños
          </label>
          {viewMode ? (
            <p className="text-gray-900">{formData.bathrooms || 0}</p>
          ) : (
            <input
              type="number"
              value={formData.bathrooms || 0}
              onChange={(e) => updateField('bathrooms', parseFloat(e.target.value) || 0)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              min="0"
              step="0.5"
            />
          )}
        </div>

        {/* Cajones de Estacionamiento */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Cajones de Estacionamiento
          </label>
          {viewMode ? (
            <p className="text-gray-900">{formData.parking_spaces || 0}</p>
          ) : (
            <input
              type="number"
              value={formData.parking_spaces || 0}
              onChange={(e) => updateField('parking_spaces', parseInt(e.target.value) || 0)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              min="0"
            />
          )}
        </div>
      </div>

      {/* Descripción Detallada */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Descripción Detallada de la Construcción
        </label>
        {viewMode ? (
          <p className="text-gray-900 whitespace-pre-line">{formData.construction_description || 'Sin descripción.'}</p>
        ) : (
          <textarea
            value={formData.construction_description || ''}
            onChange={(e) => updateField('construction_description', e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            rows="6"
            placeholder="Describe materiales, acabados, distribución de espacios, etc..."
          />
        )}
      </div>
    </div>
  );
}
