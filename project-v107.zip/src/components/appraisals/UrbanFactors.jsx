import React from 'react';
import { useAppraisalFormContext } from './context/AppraisalFormContext';
import SelectField from '../common/SelectField';
import YesNoDescriptionField from '../common/YesNoDescriptionField';

export default function UrbanFactors({ viewMode }) {
  const { formData, updateField } = useAppraisalFormContext();

  const zoneTypes = ['Residencial', 'Comercial', 'Industrial', 'Mixta', 'Rural'];
  const streetTypes = ['Pavimentada', 'Empedrada', 'Terracería', 'Adoquín'];
  const marketDemandOptions = ['Alta', 'Media', 'Regular', 'Baja'];
  const growthOptions = ['Alto crecimiento', 'Crecimiento moderado', 'Estable', 'Decrecimiento'];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-slate-900 mb-4">Factores Urbanísticos y de Entorno</h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Tipo de Zona */}
        <SelectField
          label="Tipo de Zona Urbana"
          value={formData.urban_zone_type || ''}
          onChange={(value) => updateField('urban_zone_type', value)}
          options={zoneTypes}
          viewMode={viewMode}
        />

        {/* Tipo de Calle */}
        <SelectField
          label="Tipo de Calle"
          value={formData.street_type || ''}
          onChange={(value) => updateField('street_type', value)}
          options={streetTypes}
          viewMode={viewMode}
        />

        {/* Demanda de Mercado */}
        <SelectField
          label="Demanda de Mercado"
          value={formData.market_demand || ''}
          onChange={(value) => updateField('market_demand', value)}
          options={marketDemandOptions}
          viewMode={viewMode}
        />

        {/* Crecimiento del Área */}
        <SelectField
          label="Crecimiento del Área"
          value={formData.area_growth || ''}
          onChange={(value) => updateField('area_growth', value)}
          options={growthOptions}
          viewMode={viewMode}
        />

        {/* Transporte Público */}
        <YesNoDescriptionField
          label="Transporte Público"
          yesNoValue={formData.public_transport || 'No'}
          descriptionValue={formData.public_transport_description || ''}
          onYesNoChange={(value) => updateField('public_transport', value)}
          onDescriptionChange={(value) => updateField('public_transport_description', value)}
          viewMode={viewMode}
          descriptionPlaceholder="Describe rutas, cercanía, frecuencia, etc."
        />

        {/* Alumbrado Público */}
        <YesNoDescriptionField
          label="Alumbrado Público"
          yesNoValue={formData.street_lighting || 'No'}
          descriptionValue={formData.street_lighting_description || ''}
          onYesNoChange={(value) => updateField('street_lighting', value)}
          onDescriptionChange={(value) => updateField('street_lighting_description', value)}
          viewMode={viewMode}
          descriptionPlaceholder="Describe el estado y cobertura del alumbrado"
        />
      </div>

      {/* Servicios Públicos */}
      <div className="border border-gray-200 rounded-lg p-4">
        <h4 className="font-semibold text-gray-800 mb-4">Servicios Públicos Disponibles</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Agua */}
          <YesNoDescriptionField
            label="Agua Potable"
            yesNoValue={formData.water_service || 'No'}
            descriptionValue={formData.water_service_description || ''}
            onYesNoChange={(value) => updateField('water_service', value)}
            onDescriptionChange={(value) => updateField('water_service_description', value)}
            viewMode={viewMode}
            descriptionPlaceholder="Fuente: municipal, pozo, pipa, etc."
          />

          {/* Drenaje */}
          <YesNoDescriptionField
            label="Drenaje"
            yesNoValue={formData.drainage_service || 'No'}
            descriptionValue={formData.drainage_service_description || ''}
            onYesNoChange={(value) => updateField('drainage_service', value)}
            onDescriptionChange={(value) => updateField('drainage_service_description', value)}
            viewMode={viewMode}
            descriptionPlaceholder="Tipo: municipal, fosa séptica, etc."
          />

          {/* Electricidad */}
          <YesNoDescriptionField
            label="Electricidad"
            yesNoValue={formData.electricity_service || 'No'}
            descriptionValue={formData.electricity_service_description || ''}
            onYesNoChange={(value) => updateField('electricity_service', value)}
            onDescriptionChange={(value) => updateField('electricity_service_description', value)}
            viewMode={viewMode}
            descriptionPlaceholder="Capacidad, voltaje, etc."
          />
        </div>
      </div>

      {/* Equipamiento Urbano Cercano */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Equipamiento Urbano Cercano
        </label>
        <p className="text-xs text-gray-500 mb-2">
          (Escuelas, hospitales, centros comerciales, parques, etc.)
        </p>
        {viewMode ? (
          <p className="text-gray-900 whitespace-pre-line">{formData.urban_equipment || 'Sin información.'}</p>
        ) : (
          <textarea
            value={formData.urban_equipment || ''}
            onChange={(e) => updateField('urban_equipment', e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            rows="4"
            placeholder="Describe el equipamiento urbano cercano y distancias aproximadas..."
          />
        )}
      </div>

      {/* Observaciones Urbanísticas */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Observaciones sobre Factores Urbanísticos
        </label>
        {viewMode ? (
          <p className="text-gray-900 whitespace-pre-line">{formData.urban_observations || 'Sin observaciones.'}</p>
        ) : (
          <textarea
            value={formData.urban_observations || ''}
            onChange={(e) => updateField('urban_observations', e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            rows="4"
            placeholder="Agrega observaciones sobre la ubicación, accesibilidad, plusvalía, etc..."
          />
        )}
      </div>
    </div>
  );
}
