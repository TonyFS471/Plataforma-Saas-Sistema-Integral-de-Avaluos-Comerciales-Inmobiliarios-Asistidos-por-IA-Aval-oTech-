import SelectField from '../common/SelectField';
import { useAppraisalFormContext } from './context/AppraisalFormContext';

export default function ConstructionElements({ viewMode }) {
  const { formData, updateField } = useAppraisalFormContext();

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-slate-900 mb-4">VI. Elementos de la Construcción</h3>
      
      {/* a) OBRA NEGRA */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-blue-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">a) OBRA NEGRA</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SelectField
            label="Cimentación"
            value={formData.cimentacion || ''}
            onChange={(val) => updateField('cimentacion', val)}
            otherValue={formData.cimentacion_otro || ''}
            onOtherChange={(val) => updateField('cimentacion_otro', val)}
            options={[
              'Mampostería de piedra',
              'Concreto ciclópeo',
              'Zapatas aisladas',
              'Zapatas corridas',
              'Losa de cimentación',
              'Pilotes'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Estructura"
            value={formData.estructura || ''}
            onChange={(val) => updateField('estructura', val)}
            otherValue={formData.estructura_otro || ''}
            onOtherChange={(val) => updateField('estructura_otro', val)}
            options={[
              'Adobe',
              'Madera',
              'Tabique o tabicón',
              'Block de concreto',
              'Concreto armado',
              'Acero estructural'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Muros"
            value={formData.muros || ''}
            onChange={(val) => updateField('muros', val)}
            otherValue={formData.muros_otro || ''}
            onOtherChange={(val) => updateField('muros_otro', val)}
            options={[
              'Adobe',
              'Madera',
              'Tabique o tabicón',
              'Block de concreto',
              'Panel W',
              'Concreto armado'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Entrepisos"
            value={formData.entrepisos || ''}
            onChange={(val) => updateField('entrepisos', val)}
            otherValue={formData.entrepisos_otro || ''}
            onOtherChange={(val) => updateField('entrepisos_otro', val)}
            options={[
              'Madera',
              'Vigueta y bovedilla',
              'Losa de concreto armado',
              'Losa reticular',
              'Losa postensada'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Techos"
            value={formData.techos || ''}
            onChange={(val) => updateField('techos', val)}
            otherValue={formData.techos_otro || ''}
            onOtherChange={(val) => updateField('techos_otro', val)}
            options={[
              'Madera',
              'Lámina de cartón',
              'Lámina metálica o de asbesto',
              'Vigueta y bovedilla',
              'Losa de concreto armado'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Azoteas"
            value={formData.azoteas || ''}
            onChange={(val) => updateField('azoteas', val)}
            otherValue={formData.azoteas_otro || ''}
            onOtherChange={(val) => updateField('azoteas_otro', val)}
            options={[
              'Sin impermeabilizar',
              'Impermeabilizante',
              'Enladrillado con impermeabilizante',
              'Adocreto'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Bardas/Cercas"
            value={formData.bardas_cercas || ''}
            onChange={(val) => updateField('bardas_cercas', val)}
            otherValue={formData.bardas_cercas_otro || ''}
            onOtherChange={(val) => updateField('bardas_cercas_otro', val)}
            options={[
              'Alambre de púas',
              'Malla ciclónica',
              'Madera',
              'Tabique o block sin acabado',
              'Tabique o block con acabado',
              'Concreto armado'
            ]}
            disabled={viewMode}
          />
        </div>
      </div>
      
      {/* b) REVESTIMIENTOS Y ACABADOS */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-green-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">b) REVESTIMIENTOS Y ACABADOS</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SelectField
            label="Aplanados"
            value={formData.aplanados || ''}
            onChange={(val) => updateField('aplanados', val)}
            otherValue={formData.aplanados_otro || ''}
            onOtherChange={(val) => updateField('aplanados_otro', val)}
            options={[
              'Sin recubrimiento',
              'Mortero-cemento',
              'Yeso',
              'Pasta'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Plafones"
            value={formData.plafones || ''}
            onChange={(val) => updateField('plafones', val)}
            otherValue={formData.plafones_otro || ''}
            onOtherChange={(val) => updateField('plafones_otro', val)}
            options={[
              'Sin plafón',
              'Yeso',
              'Escayola',
              'Madera',
              'Panel de yeso',
              'Aluminio'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Lambrines"
            value={formData.lambrines || ''}
            onChange={(val) => updateField('lambrines', val)}
            otherValue={formData.lambrines_otro || ''}
            onOtherChange={(val) => updateField('lambrines_otro', val)}
            options={[
              'Sin lambrín',
              'Azulejo de barro',
              'Azulejo cerámico económico',
              'Azulejo cerámico de calidad',
              'Loseta vinílica',
              'Mármol o granito'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Pisos"
            value={formData.pisos || ''}
            onChange={(val) => updateField('pisos', val)}
            otherValue={formData.pisos_otro || ''}
            onOtherChange={(val) => updateField('pisos_otro', val)}
            options={[
              'Tierra compactada',
              'Cemento pulido',
              'Loseta vinílica',
              'Loseta de barro',
              'Cerámica económica',
              'Cerámica de calidad',
              'Mármol o granito',
              'Madera',
              'Duela',
              'Parquet',
              'Alfombra',
              'Porcelanato'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Pintura"
            value={formData.pintura || ''}
            onChange={(val) => updateField('pintura', val)}
            otherValue={formData.pintura_otro || ''}
            onOtherChange={(val) => updateField('pintura_otro', val)}
            options={[
              'Cal',
              'Vinílica económica',
              'Vinílica de calidad',
              'Esmalte',
              'Texturizada',
              'Acabado especial'
            ]}
            disabled={viewMode}
          />
        </div>
      </div>
      
      {/* c) CARPINTERÍA */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-yellow-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">c) CARPINTERÍA</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SelectField
            label="Puertas"
            value={formData.puertas || ''}
            onChange={(val) => updateField('puertas', val)}
            otherValue={formData.puertas_otro || ''}
            onOtherChange={(val) => updateField('puertas_otro', val)}
            options={[
              'Madera económica',
              'Madera de calidad',
              'Metálica',
              'Tambor',
              'PVC',
              'Aluminio'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Ventanas"
            value={formData.ventanas || ''}
            onChange={(val) => updateField('ventanas', val)}
            otherValue={formData.ventanas_otro || ''}
            onOtherChange={(val) => updateField('ventanas_otro', val)}
            options={[
              'Madera económica',
              'Madera de calidad',
              'Metálica',
              'Aluminio económico',
              'Aluminio anodizado',
              'PVC'
            ]}
            disabled={viewMode}
          />
          
          <SelectField
            label="Guardamoyas"
            value={formData.guardamoyas || ''}
            onChange={(val) => updateField('guardamoyas', val)}
            otherValue={formData.guardamoyas_otro || ''}
            onOtherChange={(val) => updateField('guardamoyas_otro', val)}
            options={[
              'Sin guardamoyas',
              'Madera económica',
              'Madera de calidad',
              'Aluminio'
            ]}
            disabled={viewMode}
          />
        </div>
      </div>
      
      {/* d) ESTRUCTURAS METÁLICAS */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-red-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">d) ESTRUCTURAS METÁLICAS</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SelectField
            label="Estructuras Metálicas"
            value={formData.estructuras_metalicas || ''}
            onChange={(val) => updateField('estructuras_metalicas', val)}
            otherValue={formData.estructuras_metalicas_otro || ''}
            onOtherChange={(val) => updateField('estructuras_metalicas_otro', val)}
            options={[
              'Sin estructuras metálicas',
              'Herrería sencilla',
              'Herrería de calidad',
              'Estructura de acero',
              'Cancelería de aluminio',
              'Cancelería de acero inoxidable'
            ]}
            disabled={viewMode}
          />
        </div>
      </div>
      
      {/* e) OTROS ELEMENTOS */}
      <div className="bg-slate-50 rounded-lg p-4 border-l-4 border-purple-500">
        <h4 className="text-md font-bold text-slate-900 mb-4">e) OTROS ELEMENTOS</h4>
        
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">Observaciones Adicionales</label>
          <textarea
            value={formData.elementos_otros || ''}
            onChange={(e) => updateField('elementos_otros', e.target.value)}
            placeholder="Otros elementos constructivos relevantes..."
            rows="3"
            disabled={viewMode}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none resize-none disabled:bg-gray-100"
          />
        </div>
      </div>
    </div>
  );
}
