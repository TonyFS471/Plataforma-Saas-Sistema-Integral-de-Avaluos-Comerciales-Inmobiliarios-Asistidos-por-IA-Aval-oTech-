import React, { useState, useEffect } from 'react';
import { useAppraisalFormContext } from './context/AppraisalFormContext';
import { Scale, Plus, Trash } from 'lucide-react';

export default function HomologationMethod({ viewMode }) {
  const { formData, updateField } = useAppraisalFormContext();
  
  const [comparables, setComparables] = useState(formData.homologation_comparables || []);
  const [homologatedValue, setHomologatedValue] = useState(0);

  useEffect(() => {
    setComparables(formData.homologation_comparables || []);
    calculateHomologation();
  }, [formData.homologation_comparables]);

  const calculateHomologation = () => {
    if (comparables.length === 0) {
      setHomologatedValue(0);
      return;
    }

    const totalAdjusted = comparables.reduce((sum, comp) => {
      const pricePerM2 = comp.price / comp.area;
      const adjustedPrice = pricePerM2 * (1 + comp.adjustment / 100);
      return sum + adjustedPrice;
    }, 0);

    const avgPricePerM2 = totalAdjusted / comparables.length;
    const propertyArea = formData.construction_area || 0;
    const value = avgPricePerM2 * propertyArea;

    setHomologatedValue(value);
    updateField('homologation_value', value);
  };

  const addComparable = () => {
    const newComparable = {
      id: Date.now().toString(),
      address: '',
      price: 0,
      area: 0,
      adjustment: 0,
      notes: ''
    };
    const updated = [...comparables, newComparable];
    setComparables(updated);
    updateField('homologation_comparables', updated);
  };

  const updateComparable = (id, field, value) => {
    const updated = comparables.map(comp =>
      comp.id === id ? { ...comp, [field]: value } : comp
    );
    setComparables(updated);
    updateField('homologation_comparables', updated);
  };

  const deleteComparable = (id) => {
    const updated = comparables.filter(comp => comp.id !== id);
    setComparables(updated);
    updateField('homologation_comparables', updated);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('es-MX', {
      style: 'currency',
      currency: 'MXN',
      minimumFractionDigits: 2
    }).format(value);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-lg p-6">
        <h3 className="text-xl font-bold text-purple-900 mb-2 flex items-center gap-2">
          <Scale className="w-6 h-6" />
          Método de Homologación
        </h3>
        <p className="text-sm text-purple-700">
          Compara el inmueble con propiedades similares vendidas recientemente, ajustando diferencias.
        </p>
      </div>

      {/* Fórmula */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h4 className="font-semibold text-blue-900 mb-2">Fórmula:</h4>
        <p className="text-blue-800 font-mono text-sm mb-2">
          Valor = Precio Promedio Ajustado por m² × Superficie de Construcción
        </p>
        <p className="text-blue-700 text-xs">
          Precio Ajustado = (Precio de Venta / Área) × (1 + % Ajuste)
        </p>
      </div>

      {/* Comparables */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h4 className="text-lg font-semibold text-gray-800">Inmuebles Comparables</h4>
          {!viewMode && (
            <button
              onClick={addComparable}
              className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Agregar Comparable
            </button>
          )}
        </div>

        {comparables.length === 0 && (
          <div className="bg-gray-50 border border-dashed border-gray-300 rounded-lg p-8 text-center">
            <p className="text-gray-500">No hay comparables agregados.</p>
            {!viewMode && (
              <p className="text-sm text-gray-400 mt-2">
                Agrega al menos 3 inmuebles similares para aplicar este método.
              </p>
            )}
          </div>
        )}

        <div className="space-y-4">
          {comparables.map((comp, index) => (
            <div key={comp.id} className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
              <div className="flex justify-between items-start mb-3">
                <h5 className="font-semibold text-gray-800">Comparable #{index + 1}</h5>
                {!viewMode && (
                  <button
                    onClick={() => deleteComparable(comp.id)}
                    className="text-red-600 hover:text-red-700 transition"
                  >
                    <Trash className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Dirección */}
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Dirección</label>
                  {viewMode ? (
                    <p className="text-sm text-gray-900">{comp.address || 'N/A'}</p>
                  ) : (
                    <input
                      type="text"
                      value={comp.address}
                      onChange={(e) => updateComparable(comp.id, 'address', e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                      placeholder="Calle, colonia, ciudad..."
                    />
                  )}
                </div>

                {/* Precio de Venta */}
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Precio de Venta</label>
                  {viewMode ? (
                    <p className="text-sm text-gray-900 font-semibold">{formatCurrency(comp.price)}</p>
                  ) : (
                    <input
                      type="number"
                      value={comp.price}
                      onChange={(e) => updateComparable(comp.id, 'price', parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                      min="0"
                      step="1000"
                    />
                  )}
                </div>

                {/* Área */}
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Área (m²)</label>
                  {viewMode ? (
                    <p className="text-sm text-gray-900">{comp.area} m²</p>
                  ) : (
                    <input
                      type="number"
                      value={comp.area}
                      onChange={(e) => updateComparable(comp.id, 'area', parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                      min="0"
                      step="0.01"
                    />
                  )}
                </div>

                {/* Ajuste */}
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">
                    Ajuste (%) 
                    <span className="text-gray-400 ml-1">+ si es mejor, - si es peor</span>
                  </label>
                  {viewMode ? (
                    <p className="text-sm text-gray-900">{comp.adjustment > 0 ? '+' : ''}{comp.adjustment}%</p>
                  ) : (
                    <input
                      type="number"
                      value={comp.adjustment}
                      onChange={(e) => updateComparable(comp.id, 'adjustment', parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                      min="-50"
                      max="50"
                      step="1"
                    />
                  )}
                </div>

                {/* Notas */}
                <div className="md:col-span-2">
                  <label className="block text-xs font-medium text-gray-600 mb-1">Notas</label>
                  {viewMode ? (
                    <p className="text-sm text-gray-700">{comp.notes || 'Sin notas.'}</p>
                  ) : (
                    <textarea
                      value={comp.notes}
                      onChange={(e) => updateComparable(comp.id, 'notes', e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                      rows="2"
                      placeholder="Características, diferencias, razón del ajuste..."
                    />
                  )}
                </div>
              </div>

              {/* Precio por m² Ajustado */}
              {comp.area > 0 && (
                <div className="mt-3 pt-3 border-t border-gray-200">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Precio Original por m²:</span>
                    <span className="font-semibold">{formatCurrency(comp.price / comp.area)}</span>
                  </div>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-gray-600">Precio Ajustado por m²:</span>
                    <span className="font-semibold text-purple-600">
                      {formatCurrency((comp.price / comp.area) * (1 + comp.adjustment / 100))}
                    </span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Resultado */}
      {comparables.length > 0 && (
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
          <h4 className="font-semibold text-purple-900 mb-3">Valor Homologado</h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-700">Superficie del Inmueble:</span>
              <span className="font-semibold">{formData.construction_area || 0} m²</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-700">Precio Promedio Ajustado por m²:</span>
              <span className="font-semibold">
                {formatCurrency(comparables.length > 0 ? homologatedValue / (formData.construction_area || 1) : 0)}
              </span>
            </div>
            <div className="border-t-2 border-purple-400 pt-3 flex justify-between">
              <span className="text-gray-900 font-bold">Valor Total Homologado:</span>
              <span className="font-bold text-xl text-purple-600">{formatCurrency(homologatedValue)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Observaciones */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Observaciones del Método de Homologación
        </label>
        <p className="text-xs text-gray-500 mb-2">
          Explica los criterios de ajuste y las fuentes de los comparables.
        </p>
        {viewMode ? (
          <p className="text-gray-900 whitespace-pre-line">{formData.homologation_observations || 'Sin observaciones.'}</p>
        ) : (
          <textarea
            value={formData.homologation_observations || ''}
            onChange={(e) => updateField('homologation_observations', e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            rows="4"
            placeholder="Justifica los ajustes aplicados, diferencias entre comparables, fuentes de información..."
          />
        )}
      </div>
    </div>
  );
}
