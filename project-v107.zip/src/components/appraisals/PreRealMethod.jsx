import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';

export default function PreRealMethod({ appraisalId, formData, onPreRealChange, viewMode }) {
  const [preRealData, setPreRealData] = useState({
    factor_localizacion: 1.0,
    factor_demanda: 1.0,
    factor_oferta: 1.0,
    factor_entorno: 1.0,
    valor_mercado_referencia: 0,
    superficie_terreno: parseFloat(formData?.land_area) || 0,
    superficie_construccion: parseFloat(formData?.construction_area) || 0,
    valor_unitario_terreno: 0,
    valor_unitario_construccion: 0,
    observaciones: ''
  });

  const [loading, setLoading] = useState(false);

  // Cargar datos existentes si ya hay un avalúo guardado
  useEffect(() => {
    if (!appraisalId) return;

    const fetchPreRealData = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('pre_real_method')
          .select('*')
          .eq('appraisal_id', appraisalId)
          .maybeSingle();

        if (error && error.code !== 'PGRST116') throw error;

        if (data) {
          setPreRealData({
            factor_localizacion: parseFloat(data.factor_localizacion) || 1.0,
            factor_demanda: parseFloat(data.factor_demanda) || 1.0,
            factor_oferta: parseFloat(data.factor_oferta) || 1.0,
            factor_entorno: parseFloat(data.factor_entorno) || 1.0,
            valor_mercado_referencia: parseFloat(data.valor_mercado_referencia) || 0,
            superficie_terreno: parseFloat(data.superficie_terreno) || 0,
            superficie_construccion: parseFloat(data.superficie_construccion) || 0,
            valor_unitario_terreno: parseFloat(data.valor_unitario_terreno) || 0,
            valor_unitario_construccion: parseFloat(data.valor_unitario_construccion) || 0,
            observaciones: data.observaciones || ''
          });
        }
      } catch (error) {
        console.error('Error fetching PRE-REAL data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPreRealData();
  }, [appraisalId]);

  // ELIMINADO: useEffect que sincronizaba superficies
  // Causaba re-renders innecesarios y posibles bucles
  // Las superficies se manejan desde el estado local

  // Calcular valor total PRE-REAL
  const calculatePreRealValue = () => {
    const valorTerreno = preRealData.superficie_terreno * 
                        preRealData.valor_unitario_terreno * 
                        preRealData.factor_localizacion * 
                        preRealData.factor_entorno;

    const valorConstruccion = preRealData.superficie_construccion * 
                             preRealData.valor_unitario_construccion * 
                             preRealData.factor_demanda * 
                             preRealData.factor_oferta;

    return valorTerreno + valorConstruccion;
  };

  const valorTotal = calculatePreRealValue();

  // Guardar en base de datos y notificar al padre
  const handleChange = async (field, value) => {
    const parsedValue = parseFloat(value) || 0;
    const newData = { ...preRealData, [field]: parsedValue };
    setPreRealData(newData);

    if (!appraisalId) return;

    setLoading(true);
    try {
      // Verificar si existe registro
      const { data: existing } = await supabase
        .from('pre_real_method')
        .select('id')
        .eq('appraisal_id', appraisalId)
        .maybeSingle();

      const payload = {
        appraisal_id: appraisalId,
        [field]: parsedValue
      };

      if (existing) {
        await supabase
          .from('pre_real_method')
          .update(payload)
          .eq('id', existing.id);
      } else {
        await supabase
          .from('pre_real_method')
          .insert([{
            appraisal_id: appraisalId,
            ...preRealData,
            [field]: parsedValue
          }]);
      }

      // Calcular nuevo total con los datos actualizados
      const valorTerreno = newData.superficie_terreno * 
                          newData.valor_unitario_terreno * 
                          newData.factor_localizacion * 
                          newData.factor_entorno;

      const valorConstruccion = newData.superficie_construccion * 
                               newData.valor_unitario_construccion * 
                               newData.factor_demanda * 
                               newData.factor_oferta;

      const newTotal = valorTerreno + valorConstruccion;

      // Notificar al padre solo DESPUÉS de guardar exitosamente
      onPreRealChange(newTotal, newData.observaciones);
    } catch (error) {
      console.error('Error saving PRE-REAL data:', error);
    } finally {
      setLoading(false);
    }
  };

  // BUCLE INFINITO ELIMINADO: El useEffect que notificaba cambios al padre
  // cuando cambiaba valorTotal causaba un bucle infinito porque:
  // 1. onPreRealChange actualiza el contexto padre
  // 2. El contexto padre re-renderiza este componente
  // 3. valorTotal se recalcula y dispara este useEffect nuevamente
  // SOLUCIÓN: Notificar solo en handleChange después de guardar en DB

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-slate-900 mb-4">XII. Método PRE-REAL (Evaluación de Mercado Real)</h3>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
        <p className="text-sm text-blue-800">
          <strong>Método PRE-REAL:</strong> Determina el valor del inmueble considerando factores reales del mercado como localización, demanda, oferta y entorno. 
          Combina valores unitarios ajustados por factores de mercado específicos.
        </p>
      </div>

      {loading && <p className="text-center text-slate-600">Cargando datos...</p>}

      {/* Factores de Localización y Entorno (Terreno) */}
      <div className="bg-white border border-slate-200 rounded-lg p-6">
        <h4 className="text-md font-bold text-slate-900 mb-4">Factores del Terreno</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Superficie Terreno (m²) *</label>
            <input
              type="number"
              step="0.01"
              value={preRealData.superficie_terreno}
              onChange={(e) => handleChange('superficie_terreno', e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              disabled={viewMode}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Valor Unitario Terreno ($/m²) *</label>
            <input
              type="number"
              step="0.01"
              value={preRealData.valor_unitario_terreno}
              onChange={(e) => handleChange('valor_unitario_terreno', e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              disabled={viewMode}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mt-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Factor de Localización (0.5 - 1.5) *</label>
            <input
              type="number"
              step="0.01"
              min="0.5"
              max="1.5"
              value={preRealData.factor_localizacion}
              onChange={(e) => handleChange('factor_localizacion', e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              disabled={viewMode}
            />
            <p className="text-xs text-slate-600 mt-1">1.0 = Normal, &gt;1.0 = Premium, &lt;1.0 = Descuento</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Factor de Entorno (0.5 - 1.5) *</label>
            <input
              type="number"
              step="0.01"
              min="0.5"
              max="1.5"
              value={preRealData.factor_entorno}
              onChange={(e) => handleChange('factor_entorno', e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              disabled={viewMode}
            />
            <p className="text-xs text-slate-600 mt-1">Considera infraestructura y servicios del área</p>
          </div>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-3 mt-4">
          <div className="flex justify-between">
            <span className="font-semibold text-slate-700">Valor Terreno:</span>
            <span className="font-bold text-green-700">
              ${((preRealData.superficie_terreno * preRealData.valor_unitario_terreno * preRealData.factor_localizacion * preRealData.factor_entorno) || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
            </span>
          </div>
        </div>
      </div>

      {/* Factores de Demanda y Oferta (Construcción) */}
      <div className="bg-white border border-slate-200 rounded-lg p-6">
        <h4 className="text-md font-bold text-slate-900 mb-4">Factores de la Construcción</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Superficie Construcción (m²) *</label>
            <input
              type="number"
              step="0.01"
              value={preRealData.superficie_construccion}
              onChange={(e) => handleChange('superficie_construccion', e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              disabled={viewMode}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Valor Unitario Construcción ($/m²) *</label>
            <input
              type="number"
              step="0.01"
              value={preRealData.valor_unitario_construccion}
              onChange={(e) => handleChange('valor_unitario_construccion', e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              disabled={viewMode}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mt-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Factor de Demanda (0.5 - 1.5) *</label>
            <input
              type="number"
              step="0.01"
              min="0.5"
              max="1.5"
              value={preRealData.factor_demanda}
              onChange={(e) => handleChange('factor_demanda', e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              disabled={viewMode}
            />
            <p className="text-xs text-slate-600 mt-1">Alta demanda = &gt;1.0, Baja demanda = &lt;1.0</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Factor de Oferta (0.5 - 1.5) *</label>
            <input
              type="number"
              step="0.01"
              min="0.5"
              max="1.5"
              value={preRealData.factor_oferta}
              onChange={(e) => handleChange('factor_oferta', e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              disabled={viewMode}
            />
            <p className="text-xs text-slate-600 mt-1">Poca oferta = &gt;1.0, Mucha oferta = &lt;1.0</p>
          </div>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-3 mt-4">
          <div className="flex justify-between">
            <span className="font-semibold text-slate-700">Valor Construcción:</span>
            <span className="font-bold text-green-700">
              ${((preRealData.superficie_construccion * preRealData.valor_unitario_construccion * preRealData.factor_demanda * preRealData.factor_oferta) || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
            </span>
          </div>
        </div>
      </div>

      {/* Observaciones */}
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-2">Observaciones del Método PRE-REAL</label>
        <textarea
          value={preRealData.observaciones}
          onChange={(e) => {
            const newObs = e.target.value;
            setPreRealData(prev => ({ ...prev, observaciones: newObs }));
            onPreRealChange(valorTotal, newObs);
          }}
          placeholder="Consideraciones sobre factores de mercado, localización, demanda, oferta..."
          rows="4"
          className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none resize-none"
          disabled={viewMode}
        />
      </div>

      {/* Valor Total PRE-REAL */}
      <div className="bg-gradient-to-r from-green-600 to-green-800 text-white rounded-xl p-6 text-center">
        <p className="text-sm font-semibold mb-2">VALOR TOTAL POR MÉTODO PRE-REAL</p>
        <p className="text-4xl font-bold">${valorTotal.toLocaleString('es-MX', { minimumFractionDigits: 2 })} MXN</p>
        <p className="text-xs mt-2 opacity-90">Valor ajustado por factores reales de mercado</p>
      </div>
    </div>
  );
}