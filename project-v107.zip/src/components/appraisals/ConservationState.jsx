import React from 'react';
import { useAppraisalFormContext } from './context/AppraisalFormContext';
import SelectField from '../common/SelectField';
import YesNoDescriptionField from '../common/YesNoDescriptionField';

export default function ConservationState({ viewMode }) {
  const { formData, updateField } = useAppraisalFormContext();

  const conservationOptions = ['Excelente', 'Bueno', 'Regular', 'Malo', 'Ruinoso'];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-slate-900 mb-4">Estado de Conservación y Mantenimiento</h3>

      {/* Estado General */}
      <SelectField
        label="Estado General de Conservación"
        value={formData.conservation_state || ''}
        onChange={(value) => updateField('conservation_state', value)}
        options={conservationOptions}
        viewMode={viewMode}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Daños Estructurales */}
        <YesNoDescriptionField
          label="¿Presenta Daños Estructurales?"
          yesNoValue={formData.structural_damage || 'No'}
          descriptionValue={formData.structural_damage_description || ''}
          onYesNoChange={(value) => updateField('structural_damage', value)}
          onDescriptionChange={(value) => updateField('structural_damage_description', value)}
          viewMode={viewMode}
          descriptionPlaceholder="Describe los daños estructurales (grietas, hundimientos, etc.)"
        />

        {/* Humedad */}
        <YesNoDescriptionField
          label="¿Presenta Humedad?"
          yesNoValue={formData.humidity_damage || 'No'}
          descriptionValue={formData.humidity_damage_description || ''}
          onYesNoChange={(value) => updateField('humidity_damage', value)}
          onDescriptionChange={(value) => updateField('humidity_damage_description', value)}
          viewMode={viewMode}
          descriptionPlaceholder="Describe las zonas con humedad y posible causa"
        />

        {/* Fisuras */}
        <YesNoDescriptionField
          label="¿Presenta Fisuras?"
          yesNoValue={formData.cracks_damage || 'No'}
          descriptionValue={formData.cracks_damage_description || ''}
          onYesNoChange={(value) => updateField('cracks_damage', value)}
          onDescriptionChange={(value) => updateField('cracks_damage_description', value)}
          viewMode={viewMode}
          descriptionPlaceholder="Describe ubicación y severidad de fisuras"
        />

        {/* Deterioro de Acabados */}
        <YesNoDescriptionField
          label="¿Deterioro en Acabados?"
          yesNoValue={formData.finishes_damage || 'No'}
          descriptionValue={formData.finishes_damage_description || ''}
          onYesNoChange={(value) => updateField('finishes_damage', value)}
          onDescriptionChange={(value) => updateField('finishes_damage_description', value)}
          viewMode={viewMode}
          descriptionPlaceholder="Describe el estado de pisos, muros, techos, etc."
        />
      </div>

      {/* Mantenimiento Regular */}
      <YesNoDescriptionField
        label="¿Se realiza Mantenimiento Regular?"
        yesNoValue={formData.regular_maintenance || 'No'}
        descriptionValue={formData.maintenance_description || ''}
        onYesNoChange={(value) => updateField('regular_maintenance', value)}
        onDescriptionChange={(value) => updateField('maintenance_description', value)}
        viewMode={viewMode}
        descriptionPlaceholder="Describe el tipo y frecuencia del mantenimiento"
      />

      {/* Reparaciones Necesarias */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Reparaciones Necesarias
        </label>
        {viewMode ? (
          <p className="text-gray-900 whitespace-pre-line">{formData.required_repairs || 'Ninguna reparación identificada.'}</p>
        ) : (
          <textarea
            value={formData.required_repairs || ''}
            onChange={(e) => updateField('required_repairs', e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            rows="4"
            placeholder="Lista las reparaciones inmediatas o recomendadas..."
          />
        )}
      </div>

      {/* Observaciones Generales */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Observaciones sobre el Estado de Conservación
        </label>
        {viewMode ? (
          <p className="text-gray-900 whitespace-pre-line">{formData.conservation_observations || 'Sin observaciones adicionales.'}</p>
        ) : (
          <textarea
            value={formData.conservation_observations || ''}
            onChange={(e) => updateField('conservation_observations', e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            rows="4"
            placeholder="Agrega cualquier observación adicional sobre el estado del inmueble..."
          />
        )}
      </div>
    </div>
  );
}
