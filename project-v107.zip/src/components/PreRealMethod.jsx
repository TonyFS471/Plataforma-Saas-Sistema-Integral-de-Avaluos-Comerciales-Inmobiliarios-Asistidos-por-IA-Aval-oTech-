import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import {
  Calculator,
  Plus,
  Search,
  Edit2,
  Trash2,
  Save,
  X,
  CheckCircle,
  AlertTriangle,
  TrendingDown,
  FileText,
  DollarSign,
  Layers
} from 'lucide-react';

export default function PreRealMethod({ appraisalId }) {
  const [activeTab, setActiveTab] = useState('budget');
  const [budget, setBudget] = useState(null);
  const [budgetItems, setBudgetItems] = useState([]);
  const [concepts, setConcepts] = useState([]);
  const [damages, setDamages] = useState([]);
  const [damageTypes, setDamageTypes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [showAddItemModal, setShowAddItemModal] = useState(false);
  const [showDamageModal, setShowDamageModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);

  const categories = [
    'Todos',
    'Cimentación',
    'Estructura',
    'Albañilería',
    'Acabados',
    'Instalaciones',
    'Carpintería',
    'Herrería'
  ];

  useEffect(() => {
    loadData();
  }, [appraisalId]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Cargar o crear presupuesto
      let { data: budgetData } = await supabase
        .from('appraisal_budgets')
        .select('*')
        .eq('appraisal_id', appraisalId)
        .single();

      if (!budgetData) {
        const { data: newBudget } = await supabase
          .from('appraisal_budgets')
          .insert([{
            appraisal_id: appraisalId,
            total_construction_area: 0,
            total_budget_amount: 0,
            cost_per_sqm: 0,
            depreciated_value: 0,
            final_cost_per_sqm: 0
          }])
          .select()
          .single();
        budgetData = newBudget;
      }

      setBudget(budgetData);

      // Cargar partidas del presupuesto
      const { data: items } = await supabase
        .from('budget_items')
        .select('*')
        .eq('budget_id', budgetData.id)
        .order('main_category', { ascending: true });

      setBudgetItems(items || []);

      // Cargar catálogo de conceptos
      const { data: conceptsData } = await supabase
        .from('construction_concepts')
        .select('*')
        .eq('active', true)
        .order('main_category', { ascending: true });

      setConcepts(conceptsData || []);

      // Cargar daños
      const { data: damagesData } = await supabase
        .from('appraisal_damages')
        .select('*')
        .eq('appraisal_id', appraisalId);

      setDamages(damagesData || []);

      // Cargar tipos de daños
      const { data: damageTypesData } = await supabase
        .from('damage_types_catalog')
        .select('*')
        .eq('active', true);

      setDamageTypes(damageTypesData || []);

    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const addBudgetItem = async (concept, quantity) => {
    try {
      const subtotal = concept.unit_price * quantity;
      const { data } = await supabase
        .from('budget_items')
        .insert([{
          budget_id: budget.id,
          concept_id: concept.id,
          code: concept.code,
          description: concept.name,
          main_category: concept.main_category,
          sub_category: concept.sub_category,
          unit: concept.unit,
          quantity: quantity,
          unit_price: concept.unit_price,
          subtotal: subtotal,
          final_value: subtotal
        }])
        .select()
        .single();

      setBudgetItems([...budgetItems, data]);
      await updateBudgetTotals();
      setShowAddItemModal(false);
    } catch (error) {
      console.error('Error adding item:', error);
    }
  };

  const deleteBudgetItem = async (itemId) => {
    try {
      await supabase
        .from('budget_items')
        .delete()
        .eq('id', itemId);

      setBudgetItems(budgetItems.filter(item => item.id !== itemId));
      await updateBudgetTotals();
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  const addDamage = async (itemId, damageData) => {
    try {
      // Calcular demérito
      const severityCoef = damageData.severity_coefficient || 0;
      const extensionPct = damageData.extension_percentage || 0;
      const progressionFactor = damageData.progression_factor || 1;
      const impactFactor = damageData.impact_factor || 0;
      const repairabilityFactor = damageData.reparability_factor || 1;

      const calculatedDeduction = 
        (severityCoef * (extensionPct / 100) * progressionFactor * (1 + impactFactor) * repairabilityFactor) * 100;

      const { data } = await supabase
        .from('appraisal_damages')
        .insert([{
          appraisal_id: appraisalId,
          budget_item_id: itemId,
          ...damageData,
          calculated_deduction_percentage: calculatedDeduction,
          evaluation_date: new Date().toISOString()
        }])
        .select()
        .single();

      setDamages([...damages, data]);

      // Actualizar partida con demérito
      const item = budgetItems.find(i => i.id === itemId);
      const newDeduction = item.damage_deduction_percentage + calculatedDeduction;
      const newDeductionAmount = item.subtotal * (newDeduction / 100);
      const newFinalValue = item.subtotal - newDeductionAmount;

      await supabase
        .from('budget_items')
        .update({
          damage_deduction_percentage: newDeduction,
          damage_deduction_amount: newDeductionAmount,
          final_value: newFinalValue
        })
        .eq('id', itemId);

      await loadData();
      setShowDamageModal(false);
    } catch (error) {
      console.error('Error adding damage:', error);
    }
  };

  const updateBudgetTotals = async () => {
    const totalAmount = budgetItems.reduce((sum, item) => sum + parseFloat(item.final_value || 0), 0);
    const area = parseFloat(budget.total_construction_area || 0);
    const costPerSqm = area > 0 ? totalAmount / area : 0;

    await supabase
      .from('appraisal_budgets')
      .update({
        total_budget_amount: totalAmount,
        cost_per_sqm: costPerSqm,
        depreciated_value: totalAmount,
        final_cost_per_sqm: costPerSqm
      })
      .eq('id', budget.id);

    await loadData();
  };

  const filteredConcepts = concepts.filter(concept => {
    const matchesSearch = concept.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         concept.code.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'Todos' || concept.main_category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const groupedItems = budgetItems.reduce((acc, item) => {
    if (!acc[item.main_category]) {
      acc[item.main_category] = [];
    }
    acc[item.main_category].push(item);
    return acc;
  }, {});

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      {/* Header con Resumen */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl shadow-lg p-6 text-white">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold mb-2">Método PRE-REAL</h1>
            <p className="text-blue-100">Presupuesto Real por Partidas</p>
          </div>
          <Calculator className="w-16 h-16 opacity-50" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <Layers className="w-4 h-4" />
              <p className="text-sm text-blue-100">Área Total</p>
            </div>
            <p className="text-2xl font-bold">
              {parseFloat(budget?.total_construction_area || 0).toFixed(2)} m²
            </p>
          </div>

          <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <DollarSign className="w-4 h-4" />
              <p className="text-sm text-blue-100">Presupuesto Total</p>
            </div>
            <p className="text-2xl font-bold">
              ${parseFloat(budget?.total_budget_amount || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
            </p>
          </div>

          <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <Calculator className="w-4 h-4" />
              <p className="text-sm text-blue-100">Costo por m²</p>
            </div>
            <p className="text-2xl font-bold">
              ${parseFloat(budget?.cost_per_sqm || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
            </p>
          </div>

          <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-1">
              <TrendingDown className="w-4 h-4" />
              <p className="text-sm text-blue-100">Valor Depreciado</p>
            </div>
            <p className="text-2xl font-bold">
              ${parseFloat(budget?.depreciated_value || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-gray-200">
        <button
          onClick={() => setActiveTab('budget')}
          className={`px-6 py-3 font-medium transition-colors ${
            activeTab === 'budget'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-600 hover:text-blue-600'
          }`}
        >
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Presupuesto por Partidas
          </div>
        </button>
        <button
          onClick={() => setActiveTab('damages')}
          className={`px-6 py-3 font-medium transition-colors ${
            activeTab === 'damages'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-600 hover:text-blue-600'
          }`}
        >
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            Evaluación de Daños (SIED)
          </div>
        </button>
      </div>

      {/* Contenido de Tabs */}
      {activeTab === 'budget' && (
        <div className="space-y-6">
          {/* Configuración de Área */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold mb-4">Configuración del Presupuesto</h3>
            <div className="flex gap-4">
              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Área Total de Construcción (m²)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={budget?.total_construction_area || 0}
                  onChange={async (e) => {
                    const newArea = parseFloat(e.target.value) || 0;
                    await supabase
                      .from('appraisal_budgets')
                      .update({ total_construction_area: newArea })
                      .eq('id', budget.id);
                    await loadData();
                  }}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="flex items-end">
                <button
                  onClick={() => setShowAddItemModal(true)}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
                >
                  <Plus className="w-5 h-5" />
                  Agregar Partida
                </button>
              </div>
            </div>
          </div>

          {/* Tabla de Partidas */}
          {Object.keys(groupedItems).length === 0 ? (
            <div className="bg-white rounded-lg shadow-md p-12 text-center">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">
                No hay partidas en el presupuesto
              </h3>
              <p className="text-gray-500 mb-6">
                Comienza agregando partidas desde el catálogo de conceptos
              </p>
              <button
                onClick={() => setShowAddItemModal(true)}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Agregar Primera Partida
              </button>
            </div>
          ) : (
            Object.entries(groupedItems).map(([category, items]) => (
              <div key={category} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800">{category}</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Código</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Descripción</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Unidad</th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Cantidad</th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">P.U.</th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Subtotal</th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Demérito</th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Valor Final</th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Acciones</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {items.map((item) => (
                        <tr key={item.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 text-sm text-gray-900">{item.code}</td>
                          <td className="px-6 py-4 text-sm text-gray-900">{item.description}</td>
                          <td className="px-6 py-4 text-sm text-gray-600">{item.unit}</td>
                          <td className="px-6 py-4 text-sm text-right text-gray-900">
                            {parseFloat(item.quantity).toFixed(3)}
                          </td>
                          <td className="px-6 py-4 text-sm text-right text-gray-900">
                            ${parseFloat(item.unit_price).toFixed(2)}
                          </td>
                          <td className="px-6 py-4 text-sm text-right font-medium text-gray-900">
                            ${parseFloat(item.subtotal).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="px-6 py-4 text-sm text-right text-red-600">
                            {parseFloat(item.damage_deduction_percentage || 0).toFixed(2)}%
                          </td>
                          <td className="px-6 py-4 text-sm text-right font-bold text-green-600">
                            ${parseFloat(item.final_value).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="px-6 py-4 text-sm text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => {
                                  setSelectedItem(item);
                                  setShowDamageModal(true);
                                }}
                                className="text-orange-600 hover:text-orange-700"
                                title="Evaluar daño"
                              >
                                <AlertTriangle className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => deleteBudgetItem(item.id)}
                                className="text-red-600 hover:text-red-700"
                                title="Eliminar"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-gray-50 border-t-2 border-gray-300">
                      <tr>
                        <td colSpan="5" className="px-6 py-4 text-right font-semibold text-gray-700">
                          Subtotal {category}:
                        </td>
                        <td className="px-6 py-4 text-right font-bold text-gray-900">
                          ${items.reduce((sum, item) => sum + parseFloat(item.subtotal || 0), 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="px-6 py-4"></td>
                        <td className="px-6 py-4 text-right font-bold text-green-600">
                          ${items.reduce((sum, item) => sum + parseFloat(item.final_value || 0), 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="px-6 py-4"></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'damages' && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">Evaluación de Daños (SIED)</h3>
          <p className="text-gray-600 mb-6">
            Sistema Integral de Evaluación de Daños - Registra y evalúa daños específicos por elemento constructivo
          </p>
          
          {damages.length === 0 ? (
            <div className="text-center py-12">
              <AlertTriangle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">
                No hay daños registrados. Evalúa daños desde la tabla de presupuesto.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {damages.map((damage) => (
                <div key={damage.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h4 className="font-semibold text-gray-900">{damage.damage_name}</h4>
                      <p className="text-sm text-gray-600">{damage.system_category}</p>
                    </div>
                    <span className="px-3 py-1 bg-red-100 text-red-800 text-sm rounded-full">
                      {parseFloat(damage.calculated_deduction_percentage || 0).toFixed(2)}% demérito
                    </span>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Severidad:</span>
                      <span className="ml-2 font-medium">{damage.severity}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Extensión:</span>
                      <span className="ml-2 font-medium">{damage.extension}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Progresión:</span>
                      <span className="ml-2 font-medium">{damage.progression || 'N/A'}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Impacto:</span>
                      <span className="ml-2 font-medium">{damage.structural_impact || 'N/A'}</span>
                    </div>
                  </div>
                  {damage.notes && (
                    <p className="mt-3 text-sm text-gray-600 italic">{damage.notes}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Modal Agregar Partida */}
      {showAddItemModal && (
        <AddItemModal
          concepts={filteredConcepts}
          categories={categories}
          selectedCategory={selectedCategory}
          setSelectedCategory={setSelectedCategory}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          onAdd={addBudgetItem}
          onClose={() => setShowAddItemModal(false)}
        />
      )}

      {/* Modal Evaluar Daño */}
      {showDamageModal && selectedItem && (
        <DamageModal
          item={selectedItem}
          damageTypes={damageTypes}
          onAdd={(damageData) => addDamage(selectedItem.id, damageData)}
          onClose={() => {
            setShowDamageModal(false);
            setSelectedItem(null);
          }}
        />
      )}
    </div>
  );
}

// Modal para agregar partidas
function AddItemModal({ concepts, categories, selectedCategory, setSelectedCategory, searchTerm, setSearchTerm, onAdd, onClose }) {
  const [selectedConcept, setSelectedConcept] = useState(null);
  const [quantity, setQuantity] = useState(1);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4 flex items-center justify-between">
          <h3 className="text-xl font-bold text-white">Agregar Partida al Presupuesto</h3>
          <button
            onClick={onClose}
            className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 flex-1 overflow-y-auto">
          {!selectedConcept ? (
            <div className="space-y-4">
              {/* Búsqueda y Filtros */}
              <div className="flex gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="Buscar por nombre o código..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              {/* Lista de Conceptos */}
              <div className="grid grid-cols-1 gap-3 max-h-96 overflow-y-auto">
                {concepts.length === 0 ? (
                  <p className="text-center text-gray-500 py-8">
                    No hay conceptos disponibles. Contacta al administrador para agregar conceptos al catálogo.
                  </p>
                ) : (
                  concepts.map((concept) => (
                    <button
                      key={concept.id}
                      onClick={() => setSelectedConcept(concept)}
                      className="text-left p-4 border border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-mono bg-gray-100 px-2 py-1 rounded">
                              {concept.code}
                            </span>
                            <span className="text-xs text-gray-500">{concept.main_category}</span>
                          </div>
                          <h4 className="font-medium text-gray-900 mb-1">{concept.name}</h4>
                          <p className="text-sm text-gray-600">{concept.description}</p>
                        </div>
                        <div className="text-right ml-4">
                          <p className="text-lg font-bold text-blue-600">
                            ${parseFloat(concept.unit_price).toFixed(2)}
                          </p>
                          <p className="text-xs text-gray-500">{concept.unit}</p>
                        </div>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <button
                onClick={() => setSelectedConcept(null)}
                className="text-blue-600 hover:text-blue-700 flex items-center gap-2"
              >
                ← Regresar a catálogo
              </button>

              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-mono bg-white px-2 py-1 rounded border">
                    {selectedConcept.code}
                  </span>
                  <span className="text-xs text-gray-500">{selectedConcept.main_category}</span>
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">{selectedConcept.name}</h4>
                <p className="text-gray-600 mb-4">{selectedConcept.description}</p>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">Precio Unitario:</span>
                    <span className="ml-2 font-semibold text-blue-600">
                      ${parseFloat(selectedConcept.unit_price).toFixed(2)} / {selectedConcept.unit}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">Calidad:</span>
                    <span className="ml-2 font-medium">{selectedConcept.quality_level || 'N/A'}</span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Cantidad ({selectedConcept.unit})
                </label>
                <input
                  type="number"
                  step="0.001"
                  min="0"
                  value={quantity}
                  onChange={(e) => setQuantity(parseFloat(e.target.value) || 0)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                <div className="flex items-center justify-between text-lg">
                  <span className="font-medium text-gray-700">Subtotal:</span>
                  <span className="font-bold text-blue-600">
                    ${(selectedConcept.unit_price * quantity).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <button
                onClick={() => onAdd(selectedConcept, quantity)}
                className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Agregar al Presupuesto
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Modal para evaluar daños
function DamageModal({ item, damageTypes, onAdd, onClose }) {
  const [selectedDamageType, setSelectedDamageType] = useState(null);
  const [severity, setSeverity] = useState('');
  const [extension, setExtension] = useState('');
  const [progression, setProgression] = useState('');
  const [structuralImpact, setStructuralImpact] = useState('');
  const [reparability, setReparability] = useState('');
  const [notes, setNotes] = useState('');

  const categoryDamages = damageTypes.filter(dt => 
    dt.system_category.toLowerCase() === item.main_category.toLowerCase()
  );

  const handleSubmit = () => {
    if (!selectedDamageType || !severity || !extension) {
      alert('Por favor completa los campos obligatorios');
      return;
    }

    const damageData = {
      damage_type_id: selectedDamageType.id,
      system_category: selectedDamageType.system_category,
      damage_name: selectedDamageType.damage_name,
      severity,
      severity_coefficient: selectedDamageType.severity_levels[severity],
      extension,
      extension_percentage: selectedDamageType.extension_types[extension] * 100,
      progression: progression || null,
      progression_factor: progression ? selectedDamageType.progression_types[progression] : 1,
      structural_impact: structuralImpact || null,
      impact_factor: structuralImpact ? selectedDamageType.structural_impact[structuralImpact] : 0,
      reparability: reparability || null,
      reparability_factor: reparability ? selectedDamageType.reparability[reparability] : 1,
      notes
    };

    onAdd(damageData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="bg-gradient-to-r from-orange-600 to-orange-700 px-6 py-4 flex items-center justify-between">
          <h3 className="text-xl font-bold text-white">Evaluar Daño - {item.description}</h3>
          <button
            onClick={onClose}
            className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 flex-1 overflow-y-auto space-y-4">
          {/* Seleccionar Tipo de Daño */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tipo de Daño *
            </label>
            <select
              value={selectedDamageType?.id || ''}
              onChange={(e) => {
                const damageType = categoryDamages.find(dt => dt.id === parseInt(e.target.value));
                setSelectedDamageType(damageType);
              }}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
            >
              <option value="">Seleccionar daño...</option>
              {categoryDamages.length === 0 ? (
                <option disabled>No hay daños disponibles para esta categoría</option>
              ) : (
                categoryDamages.map(dt => (
                  <option key={dt.id} value={dt.id}>
                    {dt.damage_name}
                  </option>
                ))
              )}
            </select>
          </div>

          {selectedDamageType && (
            <>
              <div className="bg-gray-50 rounded-lg p-4 text-sm text-gray-600">
                {selectedDamageType.damage_description}
              </div>

              {/* Severidad */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Severidad *
                </label>
                <select
                  value={severity}
                  onChange={(e) => setSeverity(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                >
                  <option value="">Seleccionar...</option>
                  {Object.keys(selectedDamageType.severity_levels).map(key => (
                    <option key={key} value={key}>
                      {key.charAt(0).toUpperCase() + key.slice(1)} (coef: {selectedDamageType.severity_levels[key]})
                    </option>
                  ))}
                </select>
              </div>

              {/* Extensión */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Extensión *
                </label>
                <select
                  value={extension}
                  onChange={(e) => setExtension(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                >
                  <option value="">Seleccionar...</option>
                  {Object.keys(selectedDamageType.extension_types).map(key => (
                    <option key={key} value={key}>
                      {key.charAt(0).toUpperCase() + key.slice(1)} ({(selectedDamageType.extension_types[key] * 100).toFixed(0)}%)
                    </option>
                  ))}
                </select>
              </div>

              {/* Progresión */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Progresión
                </label>
                <select
                  value={progression}
                  onChange={(e) => setProgression(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                >
                  <option value="">Seleccionar...</option>
                  {Object.keys(selectedDamageType.progression_types).map(key => (
                    <option key={key} value={key}>
                      {key.charAt(0).toUpperCase() + key.slice(1)} (factor: {selectedDamageType.progression_types[key]})
                    </option>
                  ))}
                </select>
              </div>

              {/* Impacto Estructural */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Impacto Estructural
                </label>
                <select
                  value={structuralImpact}
                  onChange={(e) => setStructuralImpact(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                >
                  <option value="">Seleccionar...</option>
                  {Object.keys(selectedDamageType.structural_impact).map(key => (
                    <option key={key} value={key}>
                      {key.charAt(0).toUpperCase() + key.slice(1)} (factor: {selectedDamageType.structural_impact[key]})
                    </option>
                  ))}
                </select>
              </div>

              {/* Reparabilidad */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reparabilidad
                </label>
                <select
                  value={reparability}
                  onChange={(e) => setReparability(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                >
                  <option value="">Seleccionar...</option>
                  {Object.keys(selectedDamageType.reparability).map(key => (
                    <option key={key} value={key}>
                      {key.charAt(0).toUpperCase() + key.slice(1)} (factor: {selectedDamageType.reparability[key]})
                    </option>
                  ))}
                </select>
              </div>

              {/* Notas */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Notas Adicionales
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows="3"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                  placeholder="Observaciones sobre el daño..."
                />
              </div>

              <button
                onClick={handleSubmit}
                className="w-full px-6 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors flex items-center justify-center gap-2"
              >
                <CheckCircle className="w-5 h-5" />
                Registrar Daño
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
