import React, { useState, useEffect } from 'react';
import { CreditCard, CheckCircle, AlertCircle, Loader, Crown, Zap, ExternalLink } from 'lucide-react';
import { supabase } from '../../lib/supabase';

export default function SubscriptionManager({ user }) {
  const [loading, setLoading] = useState(true);
  const [userData, setUserData] = useState(null);
  const [currentPlan, setCurrentPlan] = useState(null);
  const [loadingPortal, setLoadingPortal] = useState(false);

  useEffect(() => {
    // Timeout de seguridad para evitar bucles infinitos
    const timeoutId = setTimeout(() => {
      if (loading) {
        console.error('Timeout: SubscriptionManager no pudo cargar datos');
        setLoading(false);
      }
    }, 10000); // 10 segundos máximo

    loadSubscriptionData();

    return () => clearTimeout(timeoutId);
  }, [user]);

  const loadSubscriptionData = async () => {
    if (!user?.id) {
      console.error('No user ID provided to SubscriptionManager');
      setLoading(false);
      return;
    }

    try {
      console.log('Loading subscription data for user:', user.id);
      
      // Cargar datos del usuario
      const { data: userDataResult, error: userError } = await supabase
        .from('users')
        .select('*')
        .eq('id', user.id)
        .single();

      if (userError) {
        console.error('Error loading user data:', userError);
        throw userError;
      }

      console.log('User data loaded:', userDataResult);
      setUserData(userDataResult);

      // Cargar datos del plan actual
      if (userDataResult?.subscription_status) {
        console.log('Loading plan data for:', userDataResult.subscription_status);
        
        const { data: planData, error: planError } = await supabase
          .from('subscription_plans')
          .select('*')
          .eq('id', userDataResult.subscription_status)
          .single();

        if (planError) {
          console.error('Error loading plan data:', planError);
        } else {
          console.log('Plan data loaded:', planData);
          setCurrentPlan(planData);
        }
      }
    } catch (error) {
      console.error('Error loading subscription data:', error);
    } finally {
      console.log('Subscription data loading finished');
      setLoading(false);
    }
  };

  const handleManageSubscription = async () => {
    setLoadingPortal(true);

    try {
      const response = await supabase.functions.invoke('stripe-customer-portal', {
        body: {
          customerId: userData.stripe_customer_id,
          userId: userData.id
        }
      });

      if (response.error) throw response.error;

      if (response.data?.url) {
        window.location.href = response.data.url;
      } else {
        throw new Error('No se pudo crear la sesión del portal');
      }
    } catch (error) {
      console.error('Error opening customer portal:', error);
      alert('Error al abrir el portal de gestión. Intenta de nuevo.');
    } finally {
      setLoadingPortal(false);
    }
  };

  const getPlanIcon = (status) => {
    switch (status) {
      case 'pro':
        return <Zap className="w-8 h-8" />;
      case 'enterprise':
        return <Crown className="w-8 h-8" />;
      default:
        return <CheckCircle className="w-8 h-8" />;
    }
  };

  const getPlanColor = (status) => {
    switch (status) {
      case 'pro':
        return 'from-indigo-600 to-purple-600';
      case 'enterprise':
        return 'from-purple-600 to-pink-600';
      default:
        return 'from-gray-600 to-gray-700';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader className="w-8 h-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  const usagePercentage = userData?.appraisals_limit === -1 
    ? 0 
    : (userData?.appraisals_count / userData?.appraisals_limit) * 100;

  return (
    <div className="space-y-6">
      {/* Current Plan Card */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className={`bg-gradient-to-r ${getPlanColor(userData?.subscription_status)} text-white p-6`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-white bg-opacity-20 p-3 rounded-lg">
                {getPlanIcon(userData?.subscription_status)}
              </div>
              <div>
                <p className="text-sm text-white text-opacity-80">Plan Actual</p>
                <h3 className="text-2xl font-bold">{currentPlan?.name || 'Cargando...'}</h3>
              </div>
            </div>
            {userData?.subscription_status !== 'free' && userData?.stripe_customer_id && (
              <button
                onClick={handleManageSubscription}
                disabled={loadingPortal}
                className="bg-white text-indigo-600 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition-all duration-200 flex items-center gap-2 disabled:opacity-50"
              >
                {loadingPortal ? (
                  <>
                    <Loader className="w-4 h-4 animate-spin" />
                    Cargando...
                  </>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4" />
                    Gestionar Suscripción
                    <ExternalLink className="w-4 h-4" />
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        <div className="p-6">
          {/* Price */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-3xl font-bold text-gray-900">
                ${currentPlan?.price?.toLocaleString() || '0'}
              </span>
              <span className="text-gray-600">{currentPlan?.currency || 'MXN'}</span>
              {currentPlan?.price > 0 && <span className="text-gray-600">/ mes</span>}
            </div>
            <p className="text-sm text-gray-600">{currentPlan?.description}</p>
          </div>

          {/* Usage Stats */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Avalúos este mes</span>
              <span className="text-sm font-bold text-gray-900">
                {userData?.appraisals_count} / {userData?.appraisals_limit === -1 ? '∞' : userData?.appraisals_limit}
              </span>
            </div>
            {userData?.appraisals_limit !== -1 && (
              <>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all duration-300 ${
                      usagePercentage >= 80 ? 'bg-red-600' : usagePercentage >= 50 ? 'bg-yellow-600' : 'bg-green-600'
                    }`}
                    style={{ width: `${Math.min(usagePercentage, 100)}%` }}
                  />
                </div>
                {usagePercentage >= 80 && (
                  <div className="mt-3 bg-yellow-50 border-l-4 border-yellow-400 p-3 rounded">
                    <div className="flex items-start">
                      <AlertCircle className="w-5 h-5 text-yellow-600 mr-2 flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-yellow-800">
                        {usagePercentage >= 100 
                          ? 'Has alcanzado tu límite mensual. Actualiza a un plan superior para crear más avalúos.'
                          : 'Te estás acercando al límite de tu plan. Considera actualizar para crear más avalúos.'}
                      </p>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Features */}
          <div>
            <h4 className="font-semibold text-gray-900 mb-3">Características incluidas:</h4>
            <ul className="space-y-2">
              {currentPlan?.features && Array.isArray(currentPlan.features) && currentPlan.features.map((feature, index) => (
                <li key={index} className="flex items-start">
                  <CheckCircle className="w-5 h-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-gray-700">{feature}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Upgrade Options */}
      {userData?.subscription_status === 'free' && (
        <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-200">
          <div className="flex items-start gap-4">
            <div className="bg-indigo-600 p-3 rounded-lg">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h4 className="font-bold text-gray-900 mb-2">
                Desbloquea todo el potencial de AvalúoTech
              </h4>
              <p className="text-sm text-gray-600 mb-4">
                Actualiza a un plan profesional y obtén avalúos ilimitados, exportación a PDF, soporte prioritario y mucho más.
              </p>
              <a
                href="/pricing"
                className="inline-block bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-2 rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all duration-200"
              >
                Ver Planes Disponibles
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Support */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h4 className="font-semibold text-gray-900 mb-3">¿Necesitas ayuda?</h4>
        <p className="text-sm text-gray-600 mb-4">
          Nuestro equipo de soporte está disponible para ayudarte con cualquier pregunta sobre tu suscripción.
        </p>
        <div className="flex flex-col sm:flex-row gap-3">
          <a
            href="mailto:soporte@avaluotech.com"
            className="text-center bg-gray-100 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-200 transition-all duration-200"
          >
            Contactar Soporte
          </a>
          <a
            href="#"
            className="text-center bg-gray-100 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-200 transition-all duration-200"
          >
            Ver Documentación
          </a>
        </div>
      </div>
    </div>
  );
}