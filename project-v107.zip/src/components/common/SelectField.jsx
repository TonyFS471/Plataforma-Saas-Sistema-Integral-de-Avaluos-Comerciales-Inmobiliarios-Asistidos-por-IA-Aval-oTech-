import React from 'react';

export default function SelectField({ 
  label, 
  name, 
  value, 
  onChange, 
  options, 
  otherValue, 
  onOtherChange, 
  viewMode, 
  required = false 
}) {
  const isOtherSelected = value === 'Otra (especificar)';

  return (
    <div>
      <label htmlFor={name} className="block text-sm font-medium text-slate-700 mb-2">
        {label} {required && '*'}
      </label>
      {viewMode ? (
        <p className="w-full px-4 py-2 border border-slate-300 rounded-lg bg-gray-100 text-gray-700">
          {value || 'No especificado'} {isOtherSelected && otherValue ? `: ${otherValue}` : ''}
        </p>
      ) : (
        <>
          <select
            id={name}
            name={name}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
            required={required}
          >
            <option value="">Seleccionar...</option>
            {options.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
            <option value="Otra (especificar)">Otra (especificar)</option>
          </select>
          {isOtherSelected && (
            <input
              type="text"
              name={`${name}_otro`}
              value={otherValue}
              onChange={(e) => onOtherChange(e.target.value)}
              placeholder="Especificar..."
              className="mt-2 w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              required
            />
          )}
        </>
      )}
    </div>
  );
}
