import React from 'react';

export default function YesNoDescriptionField({ 
  label, 
  presenteKey, 
  descriptionKey, 
  formData = {}, 
  handleInputChange, 
  viewMode, 
  required = false 
}) {
  // Obtener valores con fallback seguros
  const presenteValue = formData?.[presenteKey] ?? false;
  const descriptionValue = formData?.[descriptionKey] ?? '';

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-slate-700 mb-2">
        {label} {required && '*'}
      </label>
      {viewMode ? (
        <>
          <p className="w-full px-4 py-2 border border-slate-300 rounded-lg bg-gray-100 text-gray-700">
            {presenteValue ? 'Sí' : 'No'}
          </p>
          {presenteValue && descriptionValue && (
            <p className="w-full px-4 py-2 border border-slate-300 rounded-lg bg-gray-100 text-gray-700 mt-2 whitespace-pre-line">
              Estado: {descriptionValue}
            </p>
          )}
        </>
      ) : (
        <>
          <div className="flex items-center gap-4">
            <label className="inline-flex items-center cursor-pointer">
              <input
                type="radio"
                name={presenteKey || 'default'}
                value="true"
                checked={presenteValue === true}
                onChange={() => handleInputChange?.(presenteKey, true)}
                className="form-radio text-blue-600"
              />
              <span className="ml-2 text-slate-700">Sí</span>
            </label>
            <label className="inline-flex items-center cursor-pointer">
              <input
                type="radio"
                name={presenteKey || 'default'}
                value="false"
                checked={presenteValue === false}
                onChange={() => handleInputChange?.(presenteKey, false)}
                className="form-radio text-blue-600"
              />
              <span className="ml-2 text-slate-700">No</span>
            </label>
          </div>
          {presenteValue && (
            <textarea
              value={descriptionValue}
              onChange={(e) => handleInputChange?.(descriptionKey, e.target.value)}
              placeholder="Describa el estado o características de los elementos..."
              rows="2"
              className="mt-2 w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none resize-none"
              required={required}
            />
          )}
        </>
      )}
    </div>
  );
}
