import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Plus, Eye, Edit, Trash2, RefreshCw } from 'lucide-react';
import StepOrchestrator from './appraisals/StepOrchestrator';

export default function Appraisals({ user, onUpdate }) {
  const [appraisals, setAppraisals] = useState([]);
  const [properties, setProperties] = useState([]);
  const [refreshing, setRefreshing] = useState(false); // Estado para botón de refrescar
  // Estados separados para modo crear vs editar (SOLUCIÓN AL PROBLEMA)
  const [selectedPropertyForNew, setSelectedPropertyForNew] = useState(''); // ID para crear nuevo avalúo
  const [appraisalIdForEditor, setAppraisalIdForEditor] = useState(null); // ID del avalúo a editar/ver
  const [showEditor, setShowEditor] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setRefreshing(true);
    const [appData, propData] = await Promise.all([
      supabase.from('appraisals').select('*, properties(address)').order('created_at', { ascending: false }),
      supabase.from('properties').select('*').order('address')
    ]);
    setAppraisals(appData.data || []);
    setProperties(propData.data || []);
    setRefreshing(false);
  };

  const refreshProperties = async () => {
    setRefreshing(true);
    const { data } = await supabase.from('properties').select('*').order('address');
    setProperties(data || []);
    setRefreshing(false);
  };

  const deleteAppraisal = async (id) => {
    if (!confirm('¿Estás seguro de eliminar este avalúo?')) return;
    await supabase.from('appraisals').delete().eq('id', id);
    await loadData();
    onUpdate();
  };

  const statusColors = {
    draft: 'bg-gray-100 text-gray-800',
    in_progress: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
    approved: 'bg-purple-100 text-purple-800',
    rejected: 'bg-red-100 text-red-800'
  };

  const statusLabels = {
    draft: 'Borrador',
    in_progress: 'En Proceso',
    completed: 'Completado',
    approved: 'Aprobado',
    rejected: 'Rechazado'
  };

  // Si hay editor abierto, mostrar solo el editor
  if (showEditor) {
    return (
      <StepOrchestrator 
        appraisalIdToLoad={appraisalIdForEditor} // Pasa ID de avalúo a editar (null si es nuevo)
        propertyIdToCreateOrFindDraft={selectedPropertyForNew} // Pasa ID de propiedad para crear nuevo
        user={user} // Datos del usuario para pre-llenar información del valuador
        onClose={() => {
          setShowEditor(false);
          setAppraisalIdForEditor(null);
          setSelectedPropertyForNew('');
          loadData();
          onUpdate();
        }}
      />
    );
  }

  // Vista principal de lista de avalúos
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Avalúos Profesionales</h2>
        
        <div className="flex gap-3">
          <div className="flex gap-2">
            <select
              value={selectedPropertyForNew}
              onChange={(e) => setSelectedPropertyForNew(e.target.value)}
              className="px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              disabled={refreshing}
            >
              <option value="">Seleccionar Propiedad</option>
              {properties.map(prop => (
                <option key={prop.id} value={prop.id}>{prop.address}</option>
              ))}
            </select>
            
            <button
              onClick={refreshProperties}
              disabled={refreshing}
              className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-2 rounded-lg flex items-center gap-2 transition disabled:opacity-50"
              title="Refrescar lista de propiedades"
            >
              <RefreshCw className={`w-5 h-5 ${refreshing ? 'animate-spin' : ''}`} />
            </button>
          </div>
          
          <button
            onClick={() => {
              if (!selectedPropertyForNew) {
                alert('Por favor selecciona una propiedad primero para crear un avalúo.');
                return;
              }
              // VALIDACIÓN DE LÍMITE DE AVALÚOS
              if (user.appraisals_limit !== -1 && user.monthly_appraisals_count >= user.appraisals_limit) {
                alert(`Has alcanzado tu límite de ${user.appraisals_limit} avalúos este mes. Para crear más, por favor actualiza tu plan en la sección Suscripción.`);
                return;
              }
              setAppraisalIdForEditor(null); // Asegura modo creación
              setShowEditor(true);
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition"
          >
            <Plus className="w-5 h-5" />
            Nuevo Avalúo
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {appraisals.map((appraisal) => (
          <div key={appraisal.id} className="bg-white border border-slate-200 rounded-lg p-6 hover:shadow-lg transition">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-lg font-bold text-slate-900">{appraisal.appraisal_number}</h3>
                  <span className={`text-xs font-semibold px-3 py-1 rounded-full ${statusColors[appraisal.status]}`}>
                    {statusLabels[appraisal.status]}
                  </span>
                </div>
                <p className="text-sm text-slate-600 mb-1"><strong>Cliente:</strong> {appraisal.client_name}</p>
                <p className="text-sm text-slate-600 mb-1"><strong>Dirección:</strong> {appraisal.properties?.address || 'Sin dirección'}</p>
                <p className="text-sm text-slate-600"><strong>Fecha:</strong> {new Date(appraisal.appraisal_date).toLocaleDateString('es-MX')}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-blue-600">
                  ${(appraisal.final_value || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-slate-500 mb-3">Valor Final</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      if (!appraisal.id) {
                        alert('Error: ID de avalúo no encontrado. No se puede ver.');
                        return;
                      }
                      setAppraisalIdForEditor(appraisal.id); // Modo edición/vista
                      setSelectedPropertyForNew(''); // Limpia selección de propiedad
                      setShowEditor(true);
                    }}
                    className="bg-blue-100 hover:bg-blue-200 text-blue-700 p-2 rounded-lg transition"
                    title="Ver detalles"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      if (!appraisal.id) {
                        alert('Error: ID de avalúo no encontrado. No se puede editar.');
                        return;
                      }
                      setAppraisalIdForEditor(appraisal.id); // Modo edición
                      setSelectedPropertyForNew(''); // Limpia selección
                      setShowEditor(true);
                    }}
                    className="bg-green-100 hover:bg-green-200 text-green-700 p-2 rounded-lg transition"
                    title="Editar"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  {user.role === 'admin' && (
                    <button
                      onClick={() => deleteAppraisal(appraisal.id)}
                      className="bg-red-100 hover:bg-red-200 text-red-700 p-2 rounded-lg transition"
                      title="Eliminar"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
        
        {appraisals.length === 0 && (
          <div className="text-center py-12 bg-white rounded-lg border-2 border-dashed border-slate-300">
            <p className="text-slate-500 text-lg">No hay avalúos registrados</p>
            <p className="text-slate-400 text-sm mt-2">Selecciona una propiedad y haz clic en "Nuevo Avalúo" para comenzar</p>
          </div>
        )}
      </div>
    </div>
  );
}
