import { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { Bot, Send, Lightbulb, Calculator, Search } from 'lucide-react';

export default function AIAssistant({ user }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    setMessages([
      {
        role: 'assistant',
        content: `¡Hola ${user.full_name}! 👋 Soy tu asistente IA especializado en valuación inmobiliaria comercial.\n\n**Puedo ayudarte con:**\n\n🏗️ **Materiales y Conceptos:**\n• Precios actuales de 70+ materiales de construcción\n• 103 conceptos constructivos con costos por m²\n• Especificaciones técnicas y vida útil\n\n📊 **Métodos de Valuación:**\n• Físico Directo (Valor de Reposición Nuevo)\n• Comparativo de Mercado (Homologación)\n• Capitalización de Rentas\n• Residual\n• PRE-REAL (Presupuesto de Elementos Reales)\n\n🔧 **Cálculos Especializados:**\n• Depreciación Ross-Heidecke\n• Sistema SIED de evaluación de daños\n• Factores de homologación\n• Tasas de capitalización\n\n📚 **Normatividad Mexicana:**\n• INDAABIN (Instituto de Administración de Bienes)\n• SHF (Sociedad Hipotecaria Federal)\n• Lineamientos bancarios\n• INEGI, BANXICO, factores de mercado\n\n¿En qué puedo ayudarte hoy?`
      }
    ]);
  }, [user]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    try {
      // Construir historial de conversación para contexto
      const conversationHistory = messages.slice(-6).map(msg => ({
        role: msg.role,
        content: msg.content
      }));

      // Llamar a la Edge Function usando supabase.functions.invoke
      const { data, error } = await supabase.functions.invoke('ai-valuation-assistant', {
        body: {
          message: userMessage,
          userId: user.id,
          appraisalId: null,
          conversationHistory
        }
      });

      if (error) {
        console.error('Error al llamar Edge Function:', error);
        throw new Error(error.message || 'Error al procesar la consulta');
      }
      
      if (data.error) {
        throw new Error(data.error);
      }

      const aiResponse = data.response;
      const stats = {
        knowledge: data.knowledgeUsed || 0,
        materials: data.materialsFound || 0,
        concepts: data.conceptsFound || 0
      };

      // Agregar badge con estadísticas si hay contexto relevante
      let fullResponse = aiResponse;
      if (stats.knowledge > 0 || stats.materials > 0 || stats.concepts > 0) {
        fullResponse += `\n\n📚 *Consulté: ${stats.knowledge} artículos, ${stats.materials} materiales, ${stats.concepts} conceptos*`;
      }
      
      setMessages((prev) => [...prev, { role: 'assistant', content: fullResponse }]);

    } catch (error) {
      console.error('Error:', error);
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Lo siento, hubo un error procesando tu consulta. Por favor intenta de nuevo.' }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const quickActions = [
    { icon: Calculator, label: 'Depreciación Ross-Heidecke', query: '¿Cómo calculo la depreciación usando el método Ross-Heidecke?' },
    { icon: Search, label: 'Precio cemento y varillas', query: '¿Cuál es el precio actual del cemento y las varillas de acero?' },
    { icon: Lightbulb, label: 'Método PRE-REAL', query: 'Explícame cómo funciona el método PRE-REAL para avalúos' }
  ];

  return (
    <div className="flex flex-col h-[600px] bg-white rounded-xl shadow-md overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-4 text-white">
        <div className="flex items-center gap-3">
          <div className="bg-white/20 p-2 rounded-lg backdrop-blur">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-lg">Asistente IA</h3>
            <p className="text-sm text-blue-100">Especialista en Avalúos Comerciales</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-xl px-4 py-3 ${
                msg.role === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 text-slate-900'
              }`}
            >
              <p className="text-sm whitespace-pre-line">{msg.content}</p>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-slate-100 rounded-xl px-4 py-3">
              <div className="flex gap-2">
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Actions */}
      {messages.length === 1 && (
        <div className="px-4 pb-4 space-y-2">
          <p className="text-xs text-slate-500 font-medium mb-2">Acciones rápidas:</p>
          <div className="grid grid-cols-3 gap-2">
            {quickActions.map((action, idx) => {
              const Icon = action.icon;
              return (
                <button
                  key={idx}
                  onClick={() => {
                    setInput(action.query);
                  }}
                  className="flex flex-col items-center gap-2 p-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition text-center"
                >
                  <Icon className="w-5 h-5 text-blue-600" />
                  <span className="text-xs text-slate-700">{action.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="border-t border-slate-200 p-4">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Pregunta sobre materiales, métodos de valuación..."
            className="flex-1 px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
            disabled={loading}
          />
          <button
            onClick={handleSend}
            disabled={loading || !input.trim()}
            className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-lg transition disabled:opacity-50"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}