import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { supabase } from './lib/supabase';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Register from './components/auth/Register';
import AuthCallback from './components/auth/AuthCallback';
import PricingPlans from './components/pricing/PricingPlans';
import PaymentSuccess from './components/pricing/PaymentSuccess';
import StripeSetup from './components/setup/StripeSetup';

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let mounted = true;

    const initAuth = async () => {
      try {
        console.log('[App] Iniciando autenticación...');

        // Obtener sesión
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('[App] Error en getSession:', error);
          if (mounted) setLoading(false);
          return;
        }

        console.log('[App] Sesión obtenida:', session ? 'Sí' : 'No');
        
        // Si hay sesión, crear usuario temporal INMEDIATAMENTE
        if (session?.user && mounted) {
          const tempUser = {
            id: session.user.id,
            auth_id: session.user.id,
            email: session.user.email,
            full_name: session.user.user_metadata?.full_name || 'Usuario',
            role: 'perito',
            subscription_status: 'active',
            _isTemporary: true
          };
          
          setUser(tempUser);
          console.log('[App] ✅ Usuario temporal cargado:', tempUser.email);
        }
        
        // CARGAR LA APP INMEDIATAMENTE
        if (mounted) {
          setLoading(false);
          console.log('[App] ✅ App cargada - Obteniendo datos reales en segundo plano');
        }
        
        // Cargar datos REALES del usuario EN SEGUNDO PLANO
        if (session?.user && mounted) {
          loadUserData(session.user.id);
        }
      } catch (error) {
        console.error('[App] Error crítico:', error);
        if (mounted) setLoading(false);
      }
    };

    initAuth();
    
    // Escuchar cambios en la autenticación
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('[App] Auth event:', event);
      
      if (!mounted) return;
      
      // Solo procesar eventos específicos
      if (event === 'SIGNED_IN' && session?.user) {
        loadUserData(session.user.id);
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
      }
      // Ignorar TOKEN_REFRESHED y INITIAL_SESSION para evitar re-renders
    });

    return () => {
      mounted = false;
      authListener?.subscription?.unsubscribe();
    };
  }, []);

  const loadUserData = async (authId) => {
    try {
      console.log('[App] 🔄 Consultando usuario real con auth_id:', authId);
      
      const { data: userData, error } = await supabase
        .from('users')
        .select('*')
        .eq('auth_id', authId)
        .single();

      if (error) {
        console.error('[App] ❌ Error cargando usuario:', error);
        // Mantener el usuario temporal si falla
        return;
      }

      if (userData) {
        console.log('[App] ✅ Usuario real cargado:', userData.email);
        setUser(userData); // Reemplazar usuario temporal con el real
      } else {
        console.warn('[App] ⚠️ Usuario no encontrado en BD');
      }
    } catch (error) {
      console.error('[App] ❌ Error en loadUserData:', error);
      // Mantener el usuario temporal si hay error
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-50 to-pink-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando...</p>
          <p className="text-gray-400 text-sm mt-2">Conectando con el servidor...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-100 via-orange-50 to-pink-100 flex items-center justify-center">
        <div className="text-center bg-white p-8 rounded-lg shadow-lg max-w-md">
          <div className="text-red-500 text-5xl mb-4">⚠️</div>
          <h2 className="text-xl font-bold text-gray-800 mb-2">Error de Conexión</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <button 
            onClick={() => window.location.reload()} 
            className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition"
          >
            Recargar Página
          </button>
          <p className="text-gray-400 text-sm mt-4">
            Si el problema persiste, verifica tu conexión a internet.
          </p>
        </div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        {/* Rutas públicas */}
        <Route path="/login" element={!user ? <Login /> : <Navigate to="/dashboard" />} />
        <Route path="/register" element={!user ? <Register /> : <Navigate to="/dashboard" />} />
        <Route path="/auth/callback" element={<AuthCallback />} />
        <Route path="/pricing" element={<PricingPlans />} />
        <Route path="/payment-success" element={user ? <PaymentSuccess /> : <Navigate to="/login" />} />
        <Route path="/setup/stripe" element={<StripeSetup />} />
        
        {/* Rutas protegidas */}
        <Route path="/dashboard" element={user ? <Dashboard user={user} onLogout={handleLogout} /> : <Navigate to="/login" />} />
        
        {/* Ruta por defecto */}
        <Route path="/" element={<Navigate to={user ? "/dashboard" : "/login"} />} />
      </Routes>
    </BrowserRouter>
  );
}